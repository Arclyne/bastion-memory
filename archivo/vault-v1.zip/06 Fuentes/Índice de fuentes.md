---
tags: [indice, fuente]
---
# Índice de fuentes
Volver a [[00 Inicio]]

Copias de los documentos originales. No se editan; lo que se decide sobre ellos va en las notas de la bóveda.

- `estandar-v2.4.txt` — texto completo del Estándar de Codificación v2.4 (sacado del PDF con `pdftotext -layout`). Por secciones: [[Índice del estándar v2.4]].
- [[reglas-v2.4]] — una línea por regla (91 reglas).
- [[journal-revision-v2.4]] — journal de la revisión del código contra el estándar (10–11 nov 2026). Ordenado por partes en [[Índice de la revisión v2.4]].
