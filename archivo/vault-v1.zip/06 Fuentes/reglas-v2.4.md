# Índice de reglas del Estándar v2.4

Generado del PDF `Estandar v2.4.pdf` con `pdftotext -layout`. Una línea por regla: número, título y primera oración de su enunciado. El texto completo, con ejemplos, está en `estandar-v2.4.txt`.
Total: 91 reglas.


## 1. Introducción

- **1.3.1** todo el contenido del programa en inglés — Todo elemento que forme parte del programa se escribe en inglés: clases, interfaces, métodos, propiedades, eventos, variables, constantes, parámetros genéricos, espacios de nombres, comentarios, documentación XML, mensajes de excepción, mensajes de bitácora, elementos de la base de datos (tablas, columnas, restricciones, procedimientos almacenados)

## 2. Reglas de Nombrado

- **2.1.1** camelCase y nombres descriptivos — Variables locales y parámetros en camelCase.
- **2.1.2** nombres de colecciones en plural — Toda colección (arreglo, lista, diccionario o cualquier IEnumerable<T>)
- **2.1.3** una declaración por línea — No se declara más de una variable en la misma sentencia, aunque compartan tipo (McConnell, 2004).
- **2.1.4** prefijos interrogativos para variables booleanas — Toda variable bool se nombra como una pregunta cerrada, con uno de los prefijos is, are, has, can o should (Martin, 2008).
- **2.2.1** PascalCase y verbo descriptivo — El nombre de un método se escribe en PascalCase y comienza con un verbo o frase verbal (Microsoft, 2025c).
- **2.2.2** máximo de parámetros — Un método no recibe más de tres parámetros; con más datos de entrada, se encapsulan en un DTO.
- **2.2.3** métodos booleanos como pregunta — Un método que devuelve bool y expresa una pregunta se nombra con uno de los prefijos Is, Are, Has, Can o Should (Martin, 2008).
- **2.3.1** PascalCase para constantes — Toda constante (de campo o local, incluidas private e internal)
- **2.3.2** const frente a static readonly — Un valor conocido en tiempo de compilación se declara const.
- **2.4.1** PascalCase y sustantivo singular — El nombre de una clase se escribe en PascalCase y es un sustantivo o frase nominal en singular (Cwalina & Abrams, 2008).
- **2.4.2** sin prefijos ni abreviaturas poco claras — Sin prefijos que indiquen que un tipo es una clase (CTile, ClsPlayer)
- **2.5.1** prefijo I — Toda interfaz se escribe en PascalCase con prefijo I, seguido de un sustantivo, frase nominal o adjetivo que describa la capacidad o rol (Cwalina & Abrams, 2008).
- **2.5.2** correspondencia entre interfaz e implementación estándar — Cuando una clase es la implementación estándar de una interfaz, su nombre coincide exactamente con el de la interfaz, sin el prefijo I (Cwalina & Abrams, 2008).
- **2.6.1** prefijo de guion bajo — Todo campo private o internal no constante, sea de instancia o estático, se escribe en camelCase con guion bajo inicial (_campo).
- **2.6.2** misma convención para campos estáticos — Un campo static privado o interno conserva el prefijo de guion bajo y no agrega marcadores relacionados con su almacenamiento.
- **2.6.3** momento de inicialización de un campo — Todo campo queda inicializado antes de que la instancia esté disponible para su uso.
- **2.7.1** excepción sin nombre en catch — Prohibido asignar un nombre genérico (ex, ignored)
- **2.7.2** descarte _ en expresiones lambda — Un parámetro de lambda se nombra con el descarte _ únicamente cuando no participa en el cuerpo de la expresión: comunica de forma explícita al resto del equipo que ese valor es irrelevante para la operación y evita que el analizador de estilo señale un parámetro sin usar (Microsoft, 2025b).
- **2.8.1** mutabilidad como criterio de elección — Entidades cuyo estado cambia durante la partida se declaran class.
- **2.9.1** identidad mediante clave de negocio — La identidad de una entidad se define mediante su clave de negocio (business key).
- **2.10.1** enumeradores y constantes en lugar de literales — Prohibido usar valores numéricos o cadenas literales directamente en la lógica del juego; todo valor con significado en el dominio se gestiona mediante enum o constante de clase (Martin, 2008).
- **2.11.1** PascalCase y acceso mínimo necesario — Las propiedades se nombran en PascalCase con un sustantivo, frase nominal o adjetivo.
- **2.11.2** modificación controlada con private set — Cuando una propiedad cambia durante la partida, se mantiene el get público y se restringe el set al menor nivel necesario.
- **2.11.3** propiedad totalmente mutable en objetos de datos — Cuando la clase solo transporta datos y no protege ninguna invariante de dominio — una configuración, un objeto de transferencia (DTO)
- **2.11.4** cuerpo de expresión solo en catálogos de diccionario — El cuerpo de expresión (=>)
- **2.12.1** verbo y tiempo verbal — Los eventos se nombran en PascalCase con un verbo o frase verbal.
- **2.12.2** EventHandler y EventArgs — Se utiliza EventHandler<TEventArgs> para eventos con datos.
- **2.13.1** prefijo T y nombre descriptivo — Un único parámetro completamente genérico puede llamarse T.
- **2.14.1** sufijos definidos por .NET — Se aplican los sufijos establecidos por las guías de diseño de .NET: Attribute para atributos, EventArgs para datos de eventos, EventHandler para delegados de eventos, Callback para otros delegados, Exception para excepciones, Dictionary para diccionarios y Collection para colecciones personalizadas (Microsoft, 2023c).
- **2.14.2** sufijos arquitectónicos del proyecto — Para expresar una responsabilidad arquitectónica real, el proyecto adopta los sufijos Service, Repository, Controller, Factory, Provider, Validator, View, ViewModel, Store y Client.
- **2.14.3** nombre de la clase base al final de la clase derivada — Una clase que hereda de una clase base de .NET o de un framework termina con el nombre de esa clase base, como ArgumentOutOfRangeException, que hereda de Exception (Microsoft, 2023c).
- **2.15.1** singular, o plural con [Flags] — Una enumeración se nombra en PascalCase con un sustantivo en singular.
- **2.15.2** valor None en las enumeraciones de indicadores — Una enumeración de indicadores lleva el atributo [Flags], usa potencias de dos para sus valores y nombra None a su valor cero, que significa que ningún indicador está activo (Microsoft, 2023f).

## 3. Estilo de Codificación

- **3.1.1** cuatro espacios por nivel — Se adopta la configuración predeterminada de formato de C#: cada nivel de indentación usa cuatro espacios, el ancho de tabulación es cuatro y no se insertan caracteres de tabulación.
- **3.2.1** espacio entre palabra reservada y paréntesis, y línea en blanco entre — Un espacio entre palabra reservada (if, for, while, switch)
- **3.3.1** estilo Allman — Llave de apertura y cierre en su propia línea, alineadas con el bloque que delimitan.
- **3.4.1** solo cuando el tipo es evidente — Se usa var solo cuando el tipo es evidente en el lado derecho de la asignación.
- **3.5.1** cómo continuar una instrucción en varias líneas — El estándar no fija una longitud máxima de línea.
- **3.6.1** un atributo por línea, encima del elemento — Cada atributo se escribe entre sus propios corchetes y en su propia línea, encima del elemento al que se aplica.
- **3.7.1** inicializador de objeto al crear un control de Gum — Un control de Gum que se crea con new, como StackPanel, Panel, Label o Button, se declara con var (Sección 3.4)

## 4. Complejidad

- **4.1.1** máximo tres niveles de anidamiento — No se anidan más de tres niveles de estructuras de control por método.
- **4.2.1** cláusula de guarda con retorno anticipado — Todo método descarta primero, con return anticipado, los casos que no requieren procesar el resto de la lógica.
- **4.3.1** llaves obligatorias en todo bloque — Llaves {} obligatorias en toda estructura de control, incluso con una única instrucción; regla IDE0011 (Microsoft, 2023e).
- **4.3.2** rama default obligatoria en switch — Todo switch incluye una rama default explícita, y esa rama atiende solo los valores no contemplados: lanza ArgumentOutOfRangeException cuando el valor llegó como argumento, o InvalidOperationException cuando proviene del estado del objeto (McConnell, 2004).
- **4.4.1** principio DRY — Principio DRY (Don’t Repeat Yourself ): prohibido duplicar un bloque de código; si la lógica se repite en dos o más métodos, se extrae a un método privado reutilizable.
- **4.4.2** una sola definición para cada dato — DRY también aplica a los datos: un valor que representa un mismo conocimiento (el largo máximo de un correo, el tamaño de un hash, un margen de pantalla compartido)
- **4.5.1** solo para seleccionar un valor simple — El operador condicional ?: se usa cuando una condición sencilla selecciona entre dos valores sin efectos secundarios: ni la condición ni sus ramas llaman a un método que modifique estado.
- **4.6.1** máximo de 10 por método — La complejidad ciclomática de cada método es como máximo 10.
- **4.7.1** patrón de tipo en lugar de as con comprobación de nulo — Para comprobar el tipo de un valor y usarlo convertido se emplea el patrón is Tipo nombre, o is not Tipo nombre cuando forma parte de una cláusula de guarda (Sección 4.2).

## 5. Prácticas de Programación Funcional

- **5.1.1** solo para operaciones concisas de una línea — Las lambdas (=>)
- **5.1.2** contextos en los que se prohíbe una expresión lambda — Se prohíbe la expresión lambda en tres contextos: la suscripción a un evento que deba cancelarse, la asignación sobre el estado capturado y la lambda escrita dentro de otra lambda.
- **5.2.1** grupo de método sobre lambda de reenvío — Si una lambda solo reenvía sus argumentos a otro método, se usa el grupo de método (el nombre directamente)
- **5.3.1** un operador por línea y materialización aparte — En LINQ a objetos, una consulta que devuelve una secuencia se guarda en una variable IEnumerable<T> con nombre en plural (Sección 2.1.2)

## 6. Estructura de Archivos

- **6.1** un tipo de nivel superior por archivo — Cada archivo contiene exactamente un tipo de nivel superior: clase, interfaz, record, struct, enum o delegate.
- **6.2** orden de los elementos dentro de la clase — Orden fijo dentro de una clase: constantes, campos estáticos, campos de instancia, constructores, propiedades estáticas, propiedades de instancia, eventos, métodos y, al final, tipos anidados privados (McConnell, 2004).
- **6.3** orden y continuidad de directivas using — Las directivas using se colocan fuera del espacio de nombres en un único bloque sin líneas en blanco.
- **6.4** agrupación mediante espacios de nombres — Todo tipo pertenece a un espacio de nombres que coincide con la carpeta en la que está el archivo, a partir de la carpeta raíz del proyecto, y que refleja la responsabilidad del archivo.

## 7. Documentación XML

- **7.1.1** etiqueta summary en la interfaz del servicio — La interfaz pública de un servicio lleva una etiqueta <summary> en inglés que describe su responsabilidad.
- **7.1.2** inheritdoc en la implementación — La clase que implementa la interfaz de un servicio no repite la documentación: coloca <inheritdoc/> sobre la clase y sobre cada miembro que implementa la interfaz.
- **7.2.1** orden de las etiquetas param, returns y exception — Cada miembro de la interfaz de un servicio se documenta en inglés con las etiquetas en este orden: <summary>, una etiqueta <param> por cada parámetro, <returns> si devuelve un valor y <exception> por cada excepción documentada.
- **7.2.2** qué excepciones se documentan — Se documenta con <exception> toda excepción que el método deja salir hacia quien lo llama, incluidos los fallos de red que el servicio envía al cliente (por ejemplo, FaultException<TDetail>).
- **7.3.1** el compilador exige la documentación de los servicios — Todo proyecto que contiene un servicio activa GenerateDocumentationFile en su .csproj.

## 8. Comentarios Internos

- **8.1.1** explicar el porqué en inglés — El código debe ser autoexplicativo por su nombrado.
- **8.1.2** referencias a reglas y requisitos — Un comentario puede expresar su porqué citando el número de una regla de este estándar o el identificador de un requisito del proyecto (caso de uso, regla de negocio o decisión de diseño).
- **8.2.1** preferir comentarios de línea breves — Se usa un comentario de línea con // para una explicación breve y excepcional.
- **8.2.2** comentarios en scripts SQL — Un script SQL admite un único comentario de bloque como encabezado, que describe el propósito del script.
- **8.3.1** TODO y FIXME solo en ramas de trabajo — TODO identifica trabajo planificado y FIXME un defecto conocido que requiere correc- ción.

## 9. Manejo de Errores y Excepciones

- **9.1.1** variable de excepción nombrada ex — Toda variable de excepción que sí se utiliza en el bloque catch se nombra ex.
- **9.1.2** orden de las cláusulas catch — Varias cláusulas catch en un mismo try se ordenan del tipo más derivado al menos derivado (Microsoft, 2025a).
- **9.2.1** preservar la excepción original como causa — Cuando una excepción se traduce a otro tipo porque la capa actual puede aportar contexto útil, se conserva la excepción original como innerException.
- **9.2.2** throw; en lugar de throw ex; — Al relanzar la misma excepción capturada, se usa throw; sin especificar la variable (Microsoft, 2026a).
- **9.3.1** prohibido capturar o lanzar Exception genérica — Prohibido lanzar directamente System.Exception u otro tipo genérico de excepción base, o capturarlo en un bloque catch; siempre se usa el tipo más específico.
- **9.3.2** preferir excepciones predefinidas — Se usa una excepción predefinida cuando expresa correctamente el error.
- **9.4.1** referencias anulables y validación de argumentos — El proyecto habilita referencias anulables con <Nullable>enable</Nullable>.
- **9.4.2** valor alternativo con ?? cuando una expresión puede ser nula — Cuando una expresión puede ser null y existe un valor alternativo válido para ese caso, el resultado se obtiene con el operador ?? en una sola expresión.
- **9.5.1** la clase dueña de un recurso lo libera — Todo objeto IDisposable creado y usado dentro de un mismo método se declara con using.
- **9.5.2** cerrar un canal WCF con Close y Abort — Un canal o cliente WCF no se libera con using ni con una llamada directa a Close dentro de Dispose.
- **9.6.1** constructores de una excepción propia — Una excepción propia hereda de Exception, se declara sealed, termina en Exception (Sección 2.14.1), fija su mensaje en inglés dentro del constructor y expone sus datos mediante propiedades de solo lectura.
- **9.7.1** un manejador async void no deja escapar excepciones — async void se usa únicamente en manejadores de eventos.

## 10. Inyección de Dependencias

- **10.1.1** inyección por constructor y dependencia de abstracciones — Toda clase que dependa de un servicio externo recibe esa dependencia por constructor, declarada mediante una interfaz o una clase abstracta, en lugar de instanciarla dentro de la propia clase.
- **10.2.1** los servicios se construyen solo en la raíz de composición — Los servicios externos se crean con new o se registran en el contenedor únicamente en la raíz de composición: el punto de arranque de cada aplicación, como Program, las clases de registro de servicios del servidor o el método de inicialización del juego en el cliente.
- **10.3.1** prohibido pedir servicios al contenedor — Prohibido obtener una dependencia llamando a GetService o GetRequiredService dentro de una clase; la dependencia se declara en el constructor.
- **10.4.1** el tiempo se obtiene de un TimeProvider inyectado — Prohibido leer el reloj del sistema con DateTime.Now, DateTime.UtcNow o DateTimeOffset.UtcNow fuera de la raíz de composición.

## 11. Bitácoras

- **11.1.1** elección del nivel según la severidad del evento — Cada mensaje se registra mediante el método de log4net que corresponde a su severidad, de menor a mayor (Apache Software Foundation, s.
- **11.2.1** prohibido Console.WriteLine como bitácora — Prohibido Console.WriteLine, Console.Error.WriteLine o Debug.Print para re- gistrar eventos del juego; todo registro pasa por el colaborador de registro del proyecto (McConnell, 2004).
- **11.3.1** acción, contexto y excepción separada — Todo mensaje comienza con una oración breve en inglés que identifica la acción o el resultado.

## 12. Pruebas Unitarias

- **12.1.1** prefijo Test — Una clase de prueba se nombra igual que la clase examinada, con el prefijo Test (Osherove, 2013).
- **12.2.1** patrón método-estado-comportamiento esperado — Nombre en tres partes, en PascalCase separadas por guion bajo: método bajo prueba, estado evaluado, comportamiento esperado (Osherove, 2013).
- **12.3.1** separar Arrange, Act y Assert con líneas en blanco — Tres bloques consecutivos — preparación, ejecución, verificación — separados solo por una línea en blanco, sin comentarios que los etiqueten (Osherove, 2013).
- **12.3.2** una única aserción por prueba — El bloque de verificación contiene una única llamada de aserción, como ExpectEqual (Osherove, 2013).
