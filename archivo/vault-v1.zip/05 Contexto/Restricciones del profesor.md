---
tags: [contexto, restriccion]
---
# Restricciones del profesor
Volver a [[Índice de contexto]]

No negociables:
- C#
- Conexión TCP, sin WebSockets
- SQL Server
- Multijugador en línea
- Segundo factor de autenticación (2FA)
- Moderación de chat
- 14 semanas con incrementos auditables semanales
