---
tags: [contexto]
---
# Ubicaciones
Volver a [[Índice de contexto]]

- Carpeta del proyecto: `~/Desktop/proyecto_bastion` (documentos de contexto y repo `bastion_game`).
- Requisitos: `requisitos-bastion` (LaTeX).
- Arquitectura: `bastion_game_sad`.
- Repositorio: `github.com/Arclyne/bastion`.
- Carpeta `context/` de tu amigo (fuera del repo): journal, reglas y hooks; ver [[Índice de la revisión v2.4]].
- Esta bóveda: `~/bastion`.
