---
tags: [indice, contexto]
---
# Índice de contexto
Volver a [[00 Inicio]]

- [[Proyecto]] — qué es Bastión
- [[Restricciones del profesor]] — lo que no es negociable
- [[Equipo]] — quién participa
- [[Modelo de datos]] — entidades y reglas
- [[Ubicaciones]] — dónde vive cada cosa
- [[Pendientes por decidir]] — lo que falta decidir
