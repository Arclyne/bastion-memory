---
tags: [contexto, pendiente]
---
# Pendientes por decidir
Volver a [[Índice de contexto]]

Propuestas del equipo aún sin decidir. Al decidir una, crear su DEC y quitarla de aquí.
- [ ] IA rival
- [ ] Conexión LAN
- [ ] Mecanismo del segundo factor
- [ ] Validación por correo
