---
tags: [contexto]
---
# Proyecto
Volver a [[Índice de contexto]]

- Bastión: videojuego de estrategia por turnos en C#, adaptación digital inspirada en Quoridor.
- Proyecto de clase de la Licenciatura en Ingeniería de Software.
- Público: 8 años o más. Idiomas: español e inglés (distribución internacional).
- Estilo: [[DEC-001 Estilo visual 3D low-poly]].
- El primer entregable fue H1 (análisis de contexto y drivers).
