---
tags: [contexto]
---
# Modelo de datos
Volver a [[Índice de contexto]] · Notación: [[Diagramas]]

Entidades: Usuario, Estadísticas, Baneo, Reporte, Partida.

Sin entidad Skin: las skins salieron del alcance ([[DEC-006 Skins fuera del alcance]]).

Reglas:
- Partida: 2 o 4 jugadores ([[DEC-004 Partidas de 2 o 4 jugadores]]).
- Estadísticas: globales por usuario (1:1).
- Reporte: doble rol (reportante y reportado).
- Baneo: se aplica al Usuario.
