---
tags: [indice, bitacora]
---
# Índice de bitácora
Volver a [[00 Inicio]] · Nueva: [[Plantilla de bitácora]]

Más reciente arriba.

- [[2026-11-17 Revisión de los PRs 22 a 29]]
- [[2026-11-12 Mover el peón (CU-13)]]
- [[2026-11-11 Estándar v2.4 y revisión de tu amigo]]
- [[2026-11-11 Corrección de skins]]
- [[2026-11-11 Creación de la bóveda]]
