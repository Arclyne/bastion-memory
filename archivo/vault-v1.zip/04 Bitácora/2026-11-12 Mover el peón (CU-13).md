---
tags: [bitacora]
fecha: 2026-11-12
---
# 2026-11-12 Mover el peón (CU-13)
Volver a [[Índice de bitácora]]

**Qué se hizo:** paso 1 de la jugabilidad 1 vs 1, en la rama `feature/pawn-move`, en tres fases aprobadas una por una:
- **Fase A, dominio** (`fde88a4`): `Board`, `PawnMovePolicy` (pasos ortogonales, salto recto y diagonal), `Move` con su mapeo de EF a `dbo.Move`, y `Match.MovePawn`, que revisa el turno, el número de jugada y la casilla, descuenta el reloj y termina la partida por meta con 2 jugadores.
- **Fase B, servidor** (`05f8c4f`): `IMatchService.MovePawn` con sus faltas, `PawnMoveService`, el guardado de la jugada en una transacción y la notificación `PawnMovedNotification` a los dos jugadores.
- **Fase C, cliente** (`4888608`):
  - `IMatchClient.MovePawn` y el evento `PawnMoved`;
  - `MatchPlayViewModel`, que se crea en la pantalla VS para no perder jugadas;
  - elegir la casilla con un rayo 3D y resaltar las casillas alcanzables;
  - el texto del turno y la fila del turno cambian en vivo, y se avisa quién ganó.
- **Prueba en pantalla:** dos clientes con `pedro_peon` y `ana_modera` en Clasificatoria Clásico. La partida 5004 guardó 9 jugadas alternadas en `dbo.Move`. No se probaron en pantalla el salto ni la llegada a la meta; las pruebas automáticas sí los cubren.

**Decisiones:** [[DEC-008 Jugabilidad primero en 1 vs 1]], [[DEC-009 MovePawn sin resultado y rechazos como faltas]], [[DEC-010 Un solo canal de notificaciones para la partida]], [[DEC-011 El borde del tablero permite el salto diagonal]].
**Errores:** [[ERR-002 Suponer el comportamiento de Gum por su documentación]] (repetición con `VisualOver`), [[ERR-003 Contraseñas semilla expuestas en la salida de una herramienta]] (repetición), [[ERR-005 Clientes abiertos sin la huella SHA-256 del servidor]].
**Pendientes conocidos:**
- una partida terminada responde `MatchNotJoinedFault`;
- una jugada duplicada choca con la llave primaria y vuelve como error del servidor;
- el reloj del primer turno incluye la cuenta atrás de la pantalla VS y el redondeo de `StartedAt` (`DATETIME2(0)`), que va con el paso 3;
- la partida 5004 quedó en curso en la base.

**Siguiente paso:** proponer el paso 2, colocar un muro (CU-14).
