---
tags: [bitacora]
fecha: 2026-11-17
---
# 2026-11-17 Revisión de los PRs 22 a 29
Volver a [[Índice de bitácora]]

**Qué se hizo:** se leyeron los 8 PRs abiertos de poijn23 (#22 a #29), apilados uno sobre otro desde `main` `6dfb198` (#21). En total son 340 commits y 384 archivos (+6 883 / −4 520). Nada se fusionó ni se comentó en GitHub.
- #22 a #27: la segunda a la séptima pasada contra el [[Índice del estándar v2.4|estándar v2.4]]. Traen correcciones reales (#24 y #25 quitan dos caídas del host; #22 evita confirmar un muro dos veces; #25 acepta acentos en los nicknames) mezcladas con renombres y movimientos de orden.
- #28 (sin retornos `null`, `Lookup<T>`) y #29 (sin parámetros `out`) no los pide el estándar: el ejemplo correcto de la 9.4.1 devuelve `Player?` y la 2.2.3 permite `Try...`. El #29 deshace la [[Interpretaciones del estándar|R-06]] (`TryGetActiveLockEnd` con `out`) sin una R nueva.
- Hay cambios que se contradicen entre pasadas: #24 agrega `out` a `TryOpen` y #29 lo quita; #26 cambia un texto del log y #27 lo regresa.
- El #28 cambia el contrato WCF (`FindOwnRoom` → `OwnRoomResult`). En el #28 y el #29 los commits intermedios no compilan.
- No se pudo compilar ni correr las pruebas desde la sesión porque NuGet está bloqueado. Los commits no tienen comentarios ni rastros de IA.

**Decisiones:** ninguna; queda para el usuario qué hacer con #28 y #29.
**Errores:** ninguno.
**Siguiente paso:** el usuario decide si fusiona #22–#27, y si acepta #28 y #29 (con una R nueva que reemplace la R-06) o los cierra.
