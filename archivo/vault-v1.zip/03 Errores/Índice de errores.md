---
tags: [indice, error]
---
# Índice de errores
Volver a [[00 Inicio]] · Nuevo: [[Plantilla de error]]

Errores cometidos y la regla para no repetirlos. Revisar antes de cada tarea.

| ID | Error | Prevención |
|---|---|---|
| [[ERR-001 Skins en el modelo de datos]] | Se cargaron las skins como parte del modelo aunque ya no eran requisito | La bóveda manda sobre información vieja; confirmar alcance antes de cargar datos antiguos |
| [[ERR-002 Suponer el comportamiento de Gum por su documentación]] | Suponer el comportamiento de Gum por su documentación | ver la nota |
| [[ERR-003 Contraseñas semilla expuestas en la salida de una herramienta]] | Contraseñas semilla expuestas en la salida de una herramienta | ver la nota |
| [[ERR-004 Errores transitorios de SQL Server se escapaban de la traducción]] | Errores transitorios de SQL Server se escapaban de la traducción | ver la nota |
| [[ERR-005 Clientes abiertos sin la huella SHA-256 del servidor]] | Clientes abiertos sin la huella SHA-256 del certificado del servidor | exportar `BASTION_SERVER_THUMBPRINT` (SHA-256) y leer el registro del cliente |
