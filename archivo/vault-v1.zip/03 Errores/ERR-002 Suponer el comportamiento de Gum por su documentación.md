---
tags: [error]
fecha: 2026-11-11
fuente: journal de revisión v2.4
---
# ERR-002 Suponer el comportamiento de Gum por su documentación
Volver a [[Índice de errores]] · Fuente: [[journal-revision-v2.4]]

Texto del journal:

- **L0 falla:** con D1 sin el refresco, el selector arranca con «Selected Item», la interfaz sale en inglés y la
  preferencia se guarda como `en-US`. Con D1 y el refresco de antes, todo sale como en `HEAD`. El refresco sí hace
  falta, y la documentación de Gum no lo anticipaba.
- **Se aplicó L1 (sin commit):**
  - `ILanguageService.LanguageChanged`, que `LanguageService.ApplyLanguage` lanza después de cambiar el idioma de Gum;
  - `LanguagePicker(ILanguageService, width, height)` se suscribe con grupo de método y conserva `RefreshListItems`;
  - `LoginView(LoginViewModel, ILanguageService)` guarda `_languages`; `CreateHeader` y `CreateLanguagePicker` dejan de
    ser estáticos;
  - `ScreenNavigator.ShowLogin` le pasa `_languages`.

## Repetición (2026-11-12, clic sobre el tablero 3D)
- **Qué pasó:** `BastionGame` descartaba el clic si `Cursor.VisualOver` no era nulo, suponiendo que solo los controles quedan debajo del cursor. En la prueba real, sobre el tablero Gum informaba un `InteractiveGue` sin nombre, y a veces la vista `MatchView`. Ningún clic llegaba al tablero.
- **Cómo se vio:** un registro temporal de cada clic (posición, `VisualOver`, `FormsControlAsObject`, casilla calculada). El rayo 3D sí daba la casilla correcta.
- **Cómo se corrigió:** el clic se descarta solo si `VisualOver.FormsControlAsObject` es un `FrameworkElement` que no sea un `ScreenView` (`BastionGame.IsOverGumControl`).
- **Sin comprobar:** en la misma prueba, los clics sobre el chat dieron `VisualOver` nulo. No se vio un caso de botón que bloqueara el clic, ni la causa de un clic repetido en cada frame cerca del chat.
