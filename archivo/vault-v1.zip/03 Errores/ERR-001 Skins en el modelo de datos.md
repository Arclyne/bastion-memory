---
tags: [error]
fecha: 2026-11-11
---
# ERR-001 Skins en el modelo de datos
Volver a [[Índice de errores]]

**Qué pasó:** al crear la bóveda, Claude cargó las skins como entidad del [[Modelo de datos]] (inventario N:M más una equipada) y como motivo de [[DEC-001 Estilo visual 3D low-poly]].
**Por qué pasó:** se usó información de etapas tempranas del proyecto sin confirmar si seguía vigente. Las skins habían pasado a deseable y luego salieron del alcance.
**Cómo se corrigió:** se quitó Skin del modelo de datos, se actualizó DEC-001 y se registró [[DEC-006 Skins fuera del alcance]].
**Regla para no repetirlo:** la bóveda manda sobre la información anterior. Antes de registrar o usar algo antiguo que no esté en la bóveda, confirmarlo con el usuario.
