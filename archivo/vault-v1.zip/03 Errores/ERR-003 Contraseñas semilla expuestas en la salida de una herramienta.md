---
tags: [error]
fecha: 2026-11-11
fuente: journal de revisión v2.4
---
# ERR-003 Contraseñas semilla expuestas en la salida de una herramienta
Volver a [[Índice de errores]] · Fuente: [[journal-revision-v2.4]]

Texto del journal:

  - Las contraseñas semilla pasan por el portapapeles con `scratchpad/tools/seed_password_to_clipboard.ps1`, que no
    las imprime, y luego se vacía el portapapeles.
  - **Incidente:** al leer el bloque de comentarios del script semilla, la máscara no las tapó y salieron en la salida
    de una herramienta. No se repitieron en los mensajes.

## Repetición (2026-11-12)
- **Qué pasó:** al buscar los usuarios de prueba, se filtraron los comentarios de `database/03_insert_test_data.sql` excluyendo las líneas con «pass», «contra», «clave» o «pwd». Las líneas de la lista de cuentas solo tienen el nickname y la contraseña, así que el filtro no las tapó y salieron en la salida de una herramienta. No se repitieron en los mensajes.
- **Prevención:** no leer ni filtrar el bloque de comentarios del script semilla. Los nicknames se sacan de la base (`dbo.Account`), y las contraseñas las consulta el usuario en el archivo o con el script del portapapeles.
