---
tags: [error]
fecha: 2026-11-12
---
# ERR-005 Clientes abiertos sin la huella SHA-256 del servidor
Volver a [[Índice de errores]]

**Qué pasó:** en la prueba de pantalla de CU-13, Claude abrió los clientes con `dotnet run` sin `BASTION_SERVER_THUMBPRINT`, y después con la huella SHA-1 del certificado. Los clientes rechazaron el certificado y mostraron "Se perdió la conexión" al iniciar sesión.
**Por qué pasó:** se supuso que el cliente confiaba en el servidor local sin configurar nada. `ThumbprintX509CertificateValidator` compara la huella **SHA-256**, y una huella vacía nunca es de confianza.
**Cómo se corrigió:** se sacó la huella SHA-256 de `~/.bastion/bastion-server.crt` (`openssl x509 -noout -fingerprint -sha256`, sin los dos puntos) y se abrieron los clientes con esa variable. La huella es pública, no un secreto.
**Regla para no repetirlo:** antes de abrir un cliente fuera de Rider, exportar `BASTION_SERVER_THUMBPRINT` con la huella SHA-256 del certificado del servidor. Si el inicio de sesión dice "Se perdió la conexión", leer `bin/Debug/net10.0/logs/client.log` del cliente antes de suponer que el servidor está apagado.
**Relacionado:** [[ERR-003 Contraseñas semilla expuestas en la salida de una herramienta]] (la misma prueba).
