---
tags: [error]
fecha: 2026-11-11
fuente: journal de revisión v2.4
---
# ERR-004 Errores transitorios de SQL Server se escapaban de la traducción
Volver a [[Índice de errores]] · Fuente: [[journal-revision-v2.4]]

Texto del journal:

**Hallazgo nuevo (de la prueba de falla, se pregunta):**
- Contra una base que no existe, los dos repositorios dejan salir una `InvalidOperationException` que envuelve la
  `SqlException` ("likely due to a transient failure… EnableRetryOnFailure").
- La estrategia de ejecución de SQL Server envuelve así los errores transitorios cuando no hay reintentos, y la
  aplicación usa `UseSqlServer` sin `EnableRetryOnFailure`.
- Ese tipo no es `DbUpdateException` ni `DbException`, así que no se traduce y no lo atrapa ningún
  `catch (…RepositoryException)`.
- Es anterior a la D, porque los `catch` eran los mismos. La D deja un solo lugar donde corregirlo.

Se probaron estrategias de EF contra fallas reales, sin tocar la base:

| Falla | Por defecto | `NonRetryingExecutionStrategy` | `EnableRetryOnFailure(2, 1 s)` |
| --- | --- | --- | --- |
| Base que no existe (transitoria) | `InvalidOperationException` ← `SqlException` (se escapa) | `MatchRepositoryException` ← `SqlException` | `RetryLimitExceededException` (hereda de `Exception`, se escapa) |
| Puerto cerrado (no transitoria) | `MatchRepositoryException` | `MatchRepositoryException` | — |

**Consecuencias de que se escape:**
- `RankedMatchCreator` solo atrapa `MatchRepositoryException`. `MatchmakingDispatcher` no atrapa nada, y
  `MatchmakingBackgroundService.ExecuteAsync` tampoco. En .NET, una excepción en un `BackgroundService` detiene el host
  por defecto, y no hay `HostOptions` configuradas: **se cae el servidor**.
- `Host` no tiene `IErrorHandler`. En un servicio WCF, la excepción llega a CoreWCF como falla genérica, y en un canal
  con sesión el canal queda en `Faulted`.

Propuestas que se dieron al usuario:
- **A.** Un `catch` con filtro en el traductor.
- **B.** Reintentos de EF.
- **C.** Dejarlo pendiente.
- **D.** `NonRetryingExecutionStrategy` en `AdaptersRegistration`: corrige la causa en la raíz de composición y ya cubre
  también `UnitOfWork` y los 13 `catch (DbException|DbUpdateException)` de `Host`. **Recomendada.**
- **E.** Reintentos limitados más `RetryLimitExceededException`.
- **F.** Desenvolver la cadena en el traductor.
- **G.** `IErrorHandler` como escudo de excepciones en `Host`, complementaria.
- **H.** Comprobar la conexión al arrancar (fail fast), complementaria.
- **Descartadas:** atrapar en cada servicio de `Host`, `BackgroundServiceExceptionBehavior.Ignore` y agregar Polly.
