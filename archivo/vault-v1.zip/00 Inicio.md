---
tags: [indice]
---
# Bastión — Inicio

Punto de entrada de la bóveda. Todo se encuentra desde aquí en máximo dos saltos.

> [!important] Antes de trabajar
> Lee [[00 Instrucciones para Claude]]. Define qué consultar antes de actuar y qué registrar al terminar.

## Índices
| Sección                                                        | Qué contiene                                                           |
| -------------------------------------------------------------- | ---------------------------------------------------------------------- |
| [[01 Estándar/Índice del estándar\|Estándar]]                  | Cómo se escribe código, commits, documentos y diagramas                |
| [[02 Decisiones/Índice de decisiones\|Decisiones]]             | Decisiones ya tomadas; no se reabren sin motivo                        |
| [[03 Errores/Índice de errores\|Errores]]                      | Errores cometidos y cómo evitarlos                                     |
| [[04 Bitácora/Índice de bitácora\|Bitácora]]                   | Qué se hizo y cuándo                                                   |
| [[05 Contexto/Índice de contexto\|Contexto]]                   | Qué es el proyecto, restricciones, equipo, modelo de datos, pendientes |
| [[07 Revisión v2.4/Índice de la revisión v2.4\|Revisión v2.4]] | Journal de la revisión del código, ordenado                            |
| [[06 Fuentes/Índice de fuentes\|Fuentes]]                      | Documentos originales: estándar en texto, reglas, journal de revisión  |
| [[99 Plantillas/Índice de plantillas\|Plantillas]]             | Plantillas para notas nuevas                                           |

## Accesos rápidos
- [[05 Contexto/Restricciones del profesor]]
- [[05 Contexto/Pendientes por decidir]]
- [[01 Estándar/Estándar v2.4/Índice del estándar v2.4|Estándar v2.4]]
- [[01 Estándar/Interpretaciones del estándar]]
- [[07 Revisión v2.4/Índice de la revisión v2.4|Revisión v2.4 de tu amigo]]
- [[01 Estándar/Código]]
