---
tags: [instrucciones]
---
# Instrucciones para Claude

Reglas obligatorias para cualquier sesión que trabaje en Bastión.

## Antes de actuar
1. Abrir [[00 Inicio]].
2. Revisar [[02 Decisiones/Índice de decisiones]]: si la tarea toca algo ya decidido, seguir la decisión. Si parece necesario cambiarla, proponerlo al usuario; nunca cambiarla en silencio.
3. Revisar [[03 Errores/Índice de errores]]: si la tarea se parece a un error registrado, aplicar su prevención.
4. Aplicar [[01 Estándar/Índice del estándar]] a todo lo que se produzca. Para código: leer la sección del [[Índice del estándar v2.4|estándar v2.4]] que aplica y sus [[Interpretaciones del estándar|interpretaciones R]]; si una regla es dudosa y no hay R, preguntar al usuario y registrar la respuesta como R nueva.
5. Revisar la última entrada de [[04 Bitácora/Índice de bitácora]] para saber dónde se quedó el trabajo.

## Al terminar
1. Agregar una entrada a la bitácora con [[99 Plantillas/Plantilla de bitácora]] y enlazarla en su índice.
2. Si se tomó una decisión, crear una nota con [[99 Plantillas/Plantilla de decisión]] y enlazarla en el índice de decisiones.
3. Si se cometió o descubrió un error, crear una nota con [[99 Plantillas/Plantilla de error]] y enlazarla en el índice de errores.
4. Si se resolvió un pendiente, quitarlo de [[05 Contexto/Pendientes por decidir]] y enlazar la decisión.

## Reglas de la bóveda
- Toda nota nueva debe enlazarse desde su índice; no hay notas huérfanas.
- Nombres de notas: decisiones `DEC-NNN Título`, errores `ERR-NNN Título`, bitácora `AAAA-MM-DD Título`.
- Una decisión se marca `reemplazada` y se enlaza a la nueva; no se borra.
- Lo que dice la bóveda manda sobre cualquier información anterior de Claude (memoria o conversaciones viejas). Si algo viejo no aparece en la bóveda, confirmarlo con el usuario antes de usarlo o registrarlo (ver [[ERR-001 Skins en el modelo de datos]]).
- Solo se registra lo que el usuario dijo o aprobó. Lo que Claude propone y no se aprobó no es una decisión.
- Notas en español; código e identificadores en inglés.

## Restricciones del usuario
- Explicaciones en español.
- Ver [[01 Estándar/Código]] y [[01 Estándar/Git]] para las reglas de código y commits.
