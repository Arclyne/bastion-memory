---
tags: [revision-v2-4]
---
# Lecturas abiertas del estándar
Volver a [[Índice de la revisión v2.4]]

Interpretaciones que el estándar no fija y que se preguntan al usuario la primera vez que aparecen en un archivo.
La respuesta pasa a la tabla de decisiones de reglas.

| Id | Regla | Duda |
| --- | --- | --- |
| L-01 | 3.4.1 | IDE0007 toma `ToList()`/`ToX()` como tipo evidente y pide `var`; la letra de la 3.4.1 pide el tipo explícito. |
| L-02 | 2.2.2, 9.4.1 | ¿El constructor primario de un record posicional cuenta para el límite de tres parámetros y para `ThrowIfNull`? |
| L-03 | 2.9.1 | ¿Toda entidad debe redefinir `Equals` con su clave de negocio? |
| L-04 | 2.11.4 | ¿Una navegación de EF Core con `=>` entra en la excepción de framework? |
| L-05 | 1.3.1 | Recursos y mallas de los modelos 3D en español (vienen de `requisitos-bastion/modelos-3d`). |
| L-06 | 12.2.1 | ¿Una prueba puede nombrarse por el evento que dispara un manejador privado? |
| L-07 | 12.3.2 | Ayudantes de prueba que esconden un `Assert`. |
| L-08 | 10.3.1 | `GetRequiredService` en un singleton que no crea CoreWCF. |
| L-09 | Pasada 4 | ¿Un miembro que solo usan las pruebas cuenta como usado? |
| L-10 | 2.6.3 | La regla dice «campo»: ¿también obliga a inicializar en su declaración las propiedades autoimplementadas cuyo valor no depende del constructor? |
| L-11 | 9.4.1, R-11 | ¿Un record posicional sin parámetros de referencia (nada que comprobar) también pasa a constructor explícito? |
| L-12 | 2.8.1, R-01 | ¿Una entidad de EF inmutable (catálogo de solo lectura) se declara `record`, como pide la 2.8.1 para los valores inmutables, aunque un record redefina `Equals`? |
| L-13 | R-04, R-12 | ¿Un `return` con una sola llamada LINQ y una lambda de una línea (`FirstOrDefault(x => …)`) cuenta como «una sola llamada», o va en una variable como las cadenas? |
| L-14 | R-04 | ¿La R-04 (un paso por línea: casts, aritmética y llamadas en variables) vale también para las asignaciones, o solo para los `return`? |
| L-15 | R-05 | ¿Una condición que mezcla `&&` y `||` con paréntesis sigue siendo «corta» para devolverla en el `return`? |
| L-16 | 2.11.4 | ¿Una propiedad que solo expone un campo como solo lectura (`Members => _members`) fuera de EF va con bloque `get`, como método o se queda con `=>`? |
| L-17 | R-04, 9.4.2 | ¿`return llamada() ?? throw new X();` cuenta como «una sola llamada» con su alternativa, o va `if (x is null) throw …; return x;`? |
