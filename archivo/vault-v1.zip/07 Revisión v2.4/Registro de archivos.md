---
tags: [revision-v2-4]
---
# Registro de archivos
Volver a [[Índice de la revisión v2.4]]

| # | Archivo | Estado | Hallazgos | Commit |
| --- | --- | --- | --- | --- |
| — | Cierre de Application: `GenerateDocumentationFile` y CS1591 en `I*Service.cs` (R-27) | Commit `7171c56` | 7.3.1 | `7171c56` |
| — | Vocabulario «Login» en los archivos 1, 2 y 5 | Commit `c406863` | R-10 | `c406863` |
| 1 | `src/Bastion.Domain/Accounts/Account.cs` | Cerrado, commit `38a940d` | 1 incumplimiento (2.6.3), 3 lecturas (2.9.1, 2.1.2, 2.6.3), 2 repeticiones, 3 nombres, 5 miembros sin uso en producción | — |
| 2 | `src/Bastion.Domain/Accounts/AccountRules.cs` (ahora `AccountPolicy.cs`) | Cerrado, commit `2a09e60` | 2 incumplimientos (2.4.1, 4.4.2), 1 lectura (R-05), 1 repetición, 4 nombres, 3 métodos solo usados por pruebas | — |
| 3 | `src/Bastion.Domain/Accounts/AccountStatus.cs` | Cerrado sin cambios | 0 | — |
| 4 | `src/Bastion.Domain/Accounts/AccountType.cs` | Cerrado sin cambios | 0 | — |
| 5 | `src/Bastion.Domain/Accounts/LockoutPolicy.cs` | Cerrado, commit `a48853e` | 1 incumplimiento (R-04), 3 nombres | `a48853e` |
| 6 | `src/Bastion.Domain/Auditing/AccessAttempt.cs` | Cerrado, commit `36d0280` | 1 lectura (L-02 → R-11) | `36d0280` |
| 7 | `src/Bastion.Domain/Auditing/AccessLog.cs` | Cerrado sin cambios | 0 | — |
| 8 | `src/Bastion.Domain/Auditing/AccessLogResult.cs` | Cerrado sin cambios | 0 (vocabulario resuelto con R-10) | — |
| 9 | `src/Bastion.Domain/Chat/ChatRules.cs` (ahora `ChatPolicy.cs`) | Cerrado, commit `47be2f3` | 2 incumplimientos (2.4.1, R-04), 3 nombres, 1 constante de más | `47be2f3` |
| 10 | `src/Bastion.Domain/Chat/ChatWordFilter.cs` | Cerrado, commit `014dc0c` | 2 incumplimientos (2.2.3, R-04), 1 lectura (2.2.1), 1 repetición, 4 nombres | — |
| 11 | `src/Bastion.Domain/Chat/MatchChatSubmission.cs` | Cerrado, commit `a7cb6dd` | R-11 | `a7cb6dd` |
| 12 | `src/Bastion.Domain/Chat/Message.cs` | Cerrado, commit `7a17d55` | 1 incumplimiento (R-04), 1 lectura (R-14), 1 nombre, 1 miembro solo de pruebas (R-15) | `7a17d55` |
| 13 | `src/Bastion.Domain/Chat/MessageChannel.cs` | Cerrado sin cambios | 0 (valores de la base) | — |
| 14 | `src/Bastion.Domain/Chat/MessageParticipants.cs` | Cerrado sin cambios | 1 lectura (L-11 → R-16) | — |
| 15 | `src/Bastion.Domain/Friends/FriendCodeRules.cs` (ahora `FriendCodePolicy.cs`) | Cerrado, commit `b97c92c` | 3 incumplimientos (2.4.1, R-08, R-04), 2 nombres | `b97c92c` |
| 16 | `src/Bastion.Domain/Friends/FriendRequest.cs` | Cerrado, commit `22f7502` | 1 incumplimiento (2.11.4 → R-17), 1 repetición entre entidades (R-18) | `22f7502` |
| 17 | `src/Bastion.Domain/Friends/Friendship.cs` | Cerrado, commit `5e23ebe` | 2 nombres, 1 método solo de pruebas (quitado) | `5e23ebe` |
| 18 | `src/Bastion.Domain/Friends/FriendshipRules.cs` (ahora `FriendshipPolicy.cs`) | Cerrado, commit `7b5fb83` | 1 incumplimiento (2.4.1) | `7b5fb83` |
| 19 | `src/Bastion.Domain/GameModes/GameMode.cs` | Cerrado sin cambios | 1 lectura (L-12 → R-19), 1 nombre (se queda) | — |
| 20 | `src/Bastion.Domain/GameModes/GameModeCode.cs` | Cerrado sin cambios | 0 | — |
| 21 | `src/Bastion.Domain/Matches/BoardCoordinates.cs` | Cerrado sin cambios | 0 (R-16) | — |
| 22 | `src/Bastion.Domain/Matches/BoardLayout.cs` | Cerrado, commit `dd8ffb3` | 1 incumplimiento (R-04), 1 nombre | `dd8ffb3` |
| 23 | `src/Bastion.Domain/Matches/Match.cs` | Cerrado, commits `6227c25` y `78c7011` (R-23) | 2 incumplimientos (9.4.1, 5.3.1), 2 lecturas (L-04, L-13), 1 repetición, 2 nombres | — |
| 24 | `src/Bastion.Domain/Matches/MatchEndReason.cs` | Cerrado sin cambios | 0 (valores de la base) | — |
| 25 | `src/Bastion.Domain/Matches/MatchEntrant.cs` | Cerrado sin cambios | 0 (R-16) | — |
| 26 | `src/Bastion.Domain/Matches/MatchFormat.cs` | Cerrado, commit `78c7011` | R-11 | `78c7011` |
| 27 | `src/Bastion.Domain/Matches/MatchStatus.cs` | Cerrado sin cambios | 1 valor sin uso (se queda, CU-18 RN-11) | — |
| 28 | `src/Bastion.Domain/Matches/MatchType.cs` | Cerrado sin cambios | 0 | — |
| 29 | `src/Bastion.Domain/Matches/Participation.cs` | Cerrado, commit `78c7011` | 1 incumplimiento (R-04), 1 lectura (L-14 → R-23) | `78c7011` |
| 30 | `src/Bastion.Domain/Matches/ParticipationResult.cs` | Cerrado sin cambios | 0 (valores de la base) | — |
| 31 | `src/Bastion.Domain/Matches/PawnSymbol.cs` | Cerrado sin cambios | 0 | — |
| 32 | `src/Bastion.Domain/Matchmaking/MatchSearch.cs` | Cerrado, commit `a3463d8` | 1 incumplimiento (R-04 ×3), 2 nombres | `a3463d8` |
| 33 | `src/Bastion.Domain/Matchmaking/MatchmakingRules.cs` (ahora `MatchmakingPolicy.cs`) | Cerrado, commit `a3463d8` | 1 incumplimiento (2.4.1), 1 acceso de más | `a3463d8` |
| 34 | `src/Bastion.Domain/Matchmaking/SearchStatus.cs` | Cerrado sin cambios | 0 | — |
| 35 | `src/Bastion.Domain/Moderation/BannedWord.cs` | Cerrado sin cambios | 0 | — |
| 36 | `src/Bastion.Domain/Moderation/BannedWordScope.cs` | Cerrado sin cambios | 0 (valores de la base) | — |
| 37 | `src/Bastion.Domain/Moderation/Sanction.cs` | Cerrado, commit `3288d60` | 1 incumplimiento (2.11.4), 1 lectura (L-15), 1 nombre, 2 miembros solo de pruebas | — |
| 38 | `src/Bastion.Domain/Moderation/SanctionScope.cs` | Cerrado sin cambios | 0 (valores de la base) | — |
| 39–47 | `src/Bastion.Domain/Rooms/*` (45 sin cambios) | Cerrado, commit `28d73c2` | 5.2.1, R-04, R-07, R-11 ×3, R-17 ×2, 2.4.1, 1 repetición, 3 nombres, 2 accesos | `28d73c2` |
| 48–52 | `Sessions/*`, `Statistics/ModeStatistic.cs`, `Text/TextPattern.cs` | Cerrado, commit `cd96587` (48 y 50; el resto sin cambios) | R-11, 2.8.1 | `cd96587` |
| 53–59 | `src/Bastion.Server.Application/Accounts/*` | Cerrado, commit `31547fb` (54 y 57 sin cambios) | 7.1.1/7.2, 7.1.2, 7.3.1, 2.8.1, R-14, R-10 ×3, 1 nombre, 2 repeticiones | — |
| 60 | `src/Bastion.Server.Application/Auditing/IAccessLogRepository.cs` | Cerrado sin cambios | 0 | — |
| 61–81 | `src/Bastion.Server.Application/Chat/*` | Cerrado, commit `2bb2c4f` | 10.1.1, 5.3.1 ×3, R-14 ×4, R-11 ×4, R-27, 3 nombres, 1 repetición | — |
| 82–84 | `src/Bastion.Server.Application/Common/*` | Cerrado sin cambios | 0 | — |
| 85–108 | `src/Bastion.Server.Application/Friends/*` | Cerrado, commit `d486e69` | 5.3.1 ×5, 5.1.1, R-04, R-11 ×8, R-27 ×3, 4 repeticiones, 2 nombres, 1 lectura, 1 espacio de nombres | — |
| 109–115 | `src/Bastion.Server.Application/Matches/*` | Cerrado, commit `8e57acb` | 7.2.2, 5.3.1, R-11 | `8e57acb` |
| 116–134 | `src/Bastion.Server.Application/Matchmaking/*` | Cerrado, commit `fa4b91d` | 5.3.1 ×2, R-14, R-11 ×4, 1 repetición con el catálogo (se queda) | `fa4b91d` |
| 135–136 | `src/Bastion.Server.Application/Moderation/*` | Cerrado sin cambios | 0 | — |
| 137–148 | `src/Bastion.Server.Application/PrivateChat/*` (+ `PrivateChatChannel` nuevo) | Cerrado, commit `85ffd48` | 10.1.1 con 2.2.2, 5.1.1, 5.3.1, R-14, R-04, R-11 ×6, R-27, 1 nombre, L-01 | `85ffd48` |
| 149–174 | `src/Bastion.Server.Application/Rooms/*` | Cerrado, commit `1fd9813` | 9.4.1 ×5, R-09, 5.3.1 ×5, R-04 ×4, R-14, R-17, R-23, R-11 ×2, 2 repeticiones, 1 memoria | `1fd9813` |
| 175–182 | `src/Bastion.Server.Application/Security/*`, `Sessions/*` | Cerrado, commit `d4b645e` (175 y 178) | 2.8.1 ×2 | `d4b645e` |
| 183–200 | `src/Bastion.Server.Adapters/` registro, contexto, configuraciones, convertidor (+ `EnumColumnMapping` nuevo) | Cerrado, commit `12b9ebe` | 9.4.1 ×8, R-25, 4.4.2 ×2, 1 repetición (×14) | `12b9ebe` |
| 215–217 | `src/Bastion.Server.Host/Accounts/*`, `Common/CallerAddress.cs` | Cerrado, commit `81757eb` | 6.3 ×2, 7.1.2, R-14, R-40, R-41 | `81757eb` |
| 218–219 | `src/Bastion.Server.Host/Chat/*` (+ `Common/ContractArray`, `Common/FaultExceptionFactory`) | Cerrado, commit `83ee729` | R-42, R-43, R-44, 1 nombre | `83ee729` |
| 220–222 | `src/Bastion.Server.Host/Friends/*` | Cerrado, commit `0f43b0f` | 7.1.2, R-42 ×4, R-43, R-14 ×3, R-44, R-45, R-46, R-47, 1 repetición, 6 nombres | `0f43b0f` |
| 223–224 | `src/Bastion.Server.Host/Matches/*` | Cerrado, commit `e03286a` | R-43, R-44, R-45 (precisada), 11.3.1 (contexto de la bitácora), 1 texto, 1 nombre | `e03286a` |
| 225–227 | `src/Bastion.Server.Host/Matchmaking/*` (+ `Application/Matchmaking/IMatchmakingDispatcher` nuevo) | Cerrado, commit `8a231a1` | R-42, R-43, R-14, R-47, R-44, R-45, R-48, R-49, R-50, R-51, 2 nombres | `8a231a1` |
| 228–229 | `src/Bastion.Server.Host/PrivateChat/*` | Cerrado, commit `c5c0a5e` | 7.1.2, R-44, R-45, R-04, R-28, R-42 ×2, R-14 ×2, R-48, 3.4.1, R-51 (corregida), 3 nombres, 1 texto | `c5c0a5e` |
| 230 | `src/Bastion.Server.Host/Program.cs` | Cerrado, commit `edd69af` | 11.1.1 (R-52), 11.3.1, 9.4.1, 2.10.1 | `edd69af` |
| 231–233 | `src/Bastion.Server.Host/Rooms/*` (`RoomBackgroundService` → `RoomCleanupService`) | Cerrado, commit `e8d9d4c` | R-43, R-42, R-14 ×5, R-23, R-47, R-44, R-45, R-50, R-28, 4.2.1, R-53, R-54, 3 nombres | `e8d9d4c` |
| 234–235 | `src/Bastion.Server.Host/ServerCertificate.cs`, `ServiceRegistration.cs` (y `Program.cs`) | Cerrado (rama `review-standard-v2.4-host`), commit `08f2766` | R-14, 11.3.1, 9.4.2, 4.4.2 (R-55), 4.4.1, 5.2.1, 2 nombres | `08f2766` |
| 236–239 | `src/Bastion.Server.Host/Sessions/*` (+ 2 interfaces, guardas compartidas en 6 servicios) | Cerrado (rama `review-standard-v2.4-host`), commit `ebb0e3b` | R-44, R-45, R-43, R-23, 10.1.1 (R-49), 4.4.1 ×2 (R-56), R-47, 4 nombres | `ebb0e3b` |
| 240–246 | `src/Bastion.Contracts/Accounts/*` (+ `Host/Accounts/AccountService`) | Cerrado (rama `review-standard-v2.4-host`), commit `2a59451` | 7.1.1 (R-27), 9.4.1, R-44 | `2a59451` |
| 247–253 | `src/Bastion.Contracts/Chat/*` (+ el renombre en 8 archivos más) | Cerrado (rama `review-standard-v2.4-host`), commit `1326770` | Pasada 4 (`MessageId`, R-57), pasada 3 (`ConnectedPlayerCount`) | `1326770` |
| 254–264 | `src/Bastion.Contracts/Friends/*` (+ el renombre en 8 archivos más) | Cerrado (rama `review-standard-v2.4-host`), commit `43e62a0` | 7.1.1 (R-27), 2.1.2 | `43e62a0` |
| 265–266 | `src/Bastion.Contracts/Matches/*` | Cerrado (rama `review-standard-v2.4-host`), commit `40e3763` | 7.2, 7.2.2, R-41 | `40e3763` |
| 267–269 | `src/Bastion.Contracts/Matchmaking/*` | Cerrado (rama `review-standard-v2.4-host`), commit `3878797` | R-41, 7.2.2, 7.2 | `3878797` |
| 270–286 | `src/Bastion.Contracts/Notifications/*` (+ `<inheritdoc/>` en `NotificationCallback`) | Cerrado (rama `review-standard-v2.4-host`), commit `ac2a8b4` | 7.1.1, 7.1.2 | `ac2a8b4` |
| 287–290 | `src/Bastion.Contracts/PrivateChat/*` | Cerrado (rama `review-standard-v2.4-host`), commit `9e3f09c` | 7.1.1 (R-27) | `9e3f09c` |
| 291–297 | `src/Bastion.Contracts/Rooms/*` (+ 2 traductores) | Cerrado (rama `review-standard-v2.4-host`), commit `ab66fbb` | 7.2, 7.2.2, pasada 3 (`InvalidOptions`) | `ab66fbb` |
| 298–300 | `src/Bastion.Contracts/ServiceEndpoints.cs`, `Sessions/*` (+ `GenerateDocumentationFile`) | Cerrado (rama `review-standard-v2.4-host`), commits `6d689a1` y `ab0c785` | 9.4.1, R-04, R-41, R-27 | `6d689a1`, `ab0c785` |
| 301–310 | `src/Bastion.Client.Networking/Accounts/*` (+ canales inyectados en los 7 clientes) | Cerrado (rama `review-standard-v2.4-host`), commits `e83e6d3` y `c54aba2` | R-10, R-41, R-14, 6.4, pasada 2, 10.1.1 | `e83e6d3`, `c54aba2` |
| 311–317 | `src/Bastion.Client.Networking/Channels/*` (+ `ServiceEndpoints` y `Program` del servidor) | Cerrado (rama `review-standard-v2.4-host`), commit `5382eac` | R-14, R-04 ×3, R-28, R-58 (puertos registrados), 2.14.3 | `5382eac` |
| 318–327 | `src/Bastion.Client.Networking/Chat/*` | Cerrado (rama `review-standard-v2.4-host`), commit `542c757` | R-11 ×3, R-14 ×4, 5.3.1, R-47 | `542c757` |
| 328–341 | `src/Bastion.Client.Networking/Friends/*` | Cerrado (rama `review-standard-v2.4-host`), commit `bae09c1` | R-11 ×6, R-14, 5.3.1 ×3, R-47, 5.1.1, 4.4.1 | `bae09c1` |
| 342–344 | `src/Bastion.Client.Networking/Matches/*` | Cerrado sin cambios | — | — |
| 345–349 | `src/Bastion.Client.Networking/Matchmaking/*` | Cerrado (rama `review-standard-v2.4-host`), commit `19ac951` | R-14, R-47 | `19ac951` |
| 350–366 | `src/Bastion.Client.Networking/Notifications/*` (+ `SessionChannelFactory`, `ServerConnection`, `INotificationCallback`) | Cerrado (rama `review-standard-v2.4-host`), commit `fb4c3ec` | R-48 ×8, R-14, 5.3.1, R-47, R-23 ×2, 10.1.1, 9.4.1 (R-50), pasada 2 | `fb4c3ec` |
| 367–373 | `src/Bastion.Client.Networking/PrivateChat/*` (+ piezas compartidas en `Chat` y `Friends`) | Cerrado (rama `review-standard-v2.4-host`), commit `4bfb855` | R-11 ×4, R-14, 5.3.1 ×2, 5.1.1, R-47, 4.4.1 ×2 | `4bfb855` |
| 374–383 | `src/Bastion.Client.Networking/Rooms/*` | Cerrado (rama `review-standard-v2.4-host`), commit `84e8f0d` | R-54, R-48, R-14, 5.3.1, R-04 ×2, R-45, R-47, R-09 | `84e8f0d` |
| 384–385 | `src/Bastion.Client.Networking/ServerConnection.cs`, `Sessions/InvalidSessionException.cs` | Cerrado (rama `review-standard-v2.4-host`), commit `031592a` | D-06 | `031592a` |
| 386–387 | `src/Bastion.Client/BastionGame.cs`, `Program.cs` | Cerrado (rama `review-standard-v2.4-host`), commit `32cbc25` | 6.3, D-06, R-47, R-52, pasada 3 | `32cbc25` |
| 388–392 | `src/Bastion.Client/Controls/*` (+ D1: `ScreenView`, `Platform`, `ScreenNavigator`, 4 pantallas, portapapeles, `ILanguageService`) | Cerrado (rama `review-standard-v2.4-host`), commit `eb9d572` | 3.3.1 ×2, R-23 ×2, 2.10.1, 10.1.1 (D1 + L1), 4.4.1, probado en el juego | `eb9d572` |
| 393–398 | `src/Bastion.Client/Localization/*` (`SupportedLanguages` → `LanguageCatalog`) | Cerrado (rama `review-standard-v2.4-host`), commit `e3f891a` | R-27, R-11, R-04, R-23, R-47, 2.11.4 ×2, 2.4.1, 2.1.2, 2 nombres | `e3f891a` |
| 399–404 | `src/Bastion.Client/Screens/*.cs` (+ los 4 de D1) | Cerrado (rama `review-standard-v2.4-host`), commit `12338cd` | 9.4.1 ×5, R-23 ×4, 2.10.1, 4.2.1, pasada 3 (`UiThread.Run` se queda) | `12338cd` |
