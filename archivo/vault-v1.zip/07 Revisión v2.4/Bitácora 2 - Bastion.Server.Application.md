---
tags: [revision-v2-4]
---
# Bitácora 2 - Bastion.Server.Application
Volver a [[Índice de la revisión v2.4]]

### 53 a 59. `Accounts` (2026-11-10)

- **53. `AccountRestrictedException.cs`**: 9.6.1 cumple (sealed, mensaje en inglés en el constructor, datos de solo
  lectura, un solo constructor porque lleva datos). **R-10:** el mensaje dice «cannot sign in» → «cannot log in».
  Pasada 2 (se pregunta): `LoginService` pasa `0` minutos tres veces (`Pending`, `Suspended`, `Banned`), un literal
  que significa «sin bloqueo».
- **54. `AccountRestriction.cs`** (`Locked`, `Pending`, `Suspended`, `Banned`): cumple y se usan todos. **Cerrado sin
  cambios.**
- **55. `IAccountRepository.cs`**: puerto de las cuentas; no es un servicio, así que no lleva documentación XML (7.1.1).
  Los seis métodos se usan. Pasada 3 (se pregunta): `FindByIdentifier(identifier)` junto a `FindById(accountId)`;
  «identifier» puede leerse como el Id, y es el apodo o el correo (`AccountPolicy.IsValidLoginIdentifier`). Nota:
  `PlayerIdentity` vive en `Friends`, pero la usan cuentas y chat (se ve en `Friends`).
- **56. `ILoginService.cs`**: es un servicio (`I…Service`) **sin documentación XML** → **7.1.1, 7.2.1 y 7.2.2
  (incumplimiento):** `<summary>` de la interfaz y de `LogIn`, `<param>` de `attempt` y `password`, `<returns>` y
  `<exception>` de `ArgumentNullException`, `InvalidCredentialsException` y `AccountRestrictedException`, como en
  `IMatchSearchService`. Los fallos al guardar salen como excepciones de EF (`UnitOfWork.SaveChanges` no las
  traduce, a diferencia de `MatchStoreException`), y la capa de aplicación no puede nombrarlas: se ve en `UnitOfWork`.
  **R-10:** devuelve `SignedInPlayer` → `LoggedInPlayer`.
  - **7.3.1 (incumplimiento de la solución):** `Directory.Build.props` pone `GenerateDocumentationFile` en `false` para
    todo, que es el ejemplo incorrecto de la regla. Se pregunta cuándo activarlo.
- **57. `InvalidCredentialsException.cs`**: sin datos → los tres constructores estándar (9.6.1, CA1032). **Cerrado sin
  cambios.**
- **58. `LoginService.cs`**: CU-01. Cumple §1–§6, §9 (guardas, `default` con `InvalidOperationException` porque el
  estado viene del objeto), §10 (inyección por constructor) y §11 (Info si entra, Warn si no; mensaje con
  `Clave=valor`).
  - **7.1.2 (incumplimiento):** falta `<inheritdoc/>` en la clase y en `LogIn`.
  - **R-14:** `return new AccountRestrictedException(AccountRestriction.Locked, account.GetRemainingLockMinutes(now));`
    lleva una llamada en un argumento → la cuenta de minutos va antes en una variable.
  - **R-10:** el mensaje de bitácora «Sign-in attempt processed» → «Login attempt processed».
  - Pasada 2 (se pregunta): en `AdmitByAccountStatus`, los casos `Pending`, `Suspended` y `Banned` repiten
    `throw Reject(new AccessLog(…), new AccountRestrictedException(…, 0));`.
- **59. `SignedInPlayer.cs`**: **R-10** → `LoggedInPlayer`. Es una clase inmutable que no es de EF → **2.8.1:**
  `sealed record` con el mismo constructor (R-11).

**Decisiones del usuario (53 a 59):** la 7.3.1 se activa **al terminar la capa**: cada servicio se documenta al revisar su
archivo, y al cerrar Application se pone `GenerateDocumentationFile` en su `.csproj`, con CS1591 como error en
`I*Service.cs` y apagado en lo demás (**R-27**). `FindByIdentifier` → `FindByLoginIdentifier` (parámetro
`loginIdentifier`). `AccountRestrictedException` gana un constructor sin minutos que encadena `: this(restriction,
NoLockMinutes)`. El `switch` de `AdmitByAccountStatus` se queda. Se aplicaron la documentación de `ILoginService` (7.1.1,
7.2.1, 7.2.2), `<inheritdoc/>` en `LoginService` (7.1.2), la R-10 (`LoggedInPlayer` y los mensajes «log in»), la 2.8.1 y la
R-14. Cambian `AccountRepository`, `AccountService`, `LoginTranslator`, `FakeAccountRepository` y `TestLoginService`.
Compila el servidor (carpeta aparte) y pasan 158 + 220 pruebas. Commit `31547fb`, sin push.

### 60. `Auditing/IAccessLogRepository.cs` (2026-11-10)

Puerto con `Add(AccessLog)`. Cumple; lo usa `LoginService`. **Cerrado sin cambios.**

### 61 a 81. `Chat` (2026-11-10)

Chat del lobby (en memoria, CU-20 sin canal propio todavía) y chat de partida (se guarda). En orden alfabético:
- **61. `ChatChannelForbiddenException`**: sin datos → tres constructores estándar (9.6.1). **Sin cambios.**
- **62. `ChatCooldown`**: espera de 3 s por jugador. Cumple §4 (2 niveles). Pasada 3 (se pregunta): la misma acción se llama
  `TryClaimTurn` (aquí, en `ILobbyChatRoom` y en `IPrivateChatRoom`) y `TryStartCooldown` (`IMatchChatRelay`); en un juego
  por turnos, «turn» se confunde con el turno de la partida (`_lastTurnByAccountId`, `lastTurn`).
- **63. `ChatHistoryEntry`**, **64. `ChatLine`**, **76. `LobbyChatHistory`** y **81. `PostedChatLine`**: records
  posicionales con referencias → **R-11**.
- **65. `ChatMessageRejectedException`**: dos constructores con datos (9.6.1). **Sin cambios.**
- **66. `ChatModerator`**: valida el largo, el silencio y las palabras prohibidas (CU-20 RN-01, RN-03, RN-05). **5.3.1:**
  `FindMute` encadena `.ToList()` (y su `var` no tenía tipo evidente, L-01) → secuencia con nombre y `new List<Sanction>(…)`.
- **67. `ChatMute`**: record solo de valores (R-16). **R-14:** `return new ChatMute(true, sanctions.Max(…));` lleva una
  llamada en un argumento → variable antes.
- **68. `ChatRejection`**, **69. `IChatBroadcaster`**, **73. `IMatchChatNotifier`**, **74. `IMatchChatRelay`** (salvo el
  nombre de la pregunta de la 62) y **75. `IMatchChatService`** (ya documentada): cumplen. **Sin cambios.**
- **70. `IChatModerator`**: no es un servicio (`I…Moderator`), sin documentación. Pasada 3 (se pregunta): `Screen` en un
  juego se lee como «pantalla»; el método valida el mensaje, lo recorta y lo devuelve.
- **71. `ILobbyChatRoom`**: Pasada 4 (se pregunta, anotado en el archivo 9): `ListRecent(int count)`; la sala ya guarda
  solo `MaximumRecentMessages` y el único llamador de producción pide justo eso.
- **72. `ILobbyChatService`**: servicio sin documentación → **R-27** (7.1.1, 7.2.1, 7.2.2).
- **77. `LobbyChatRoom`**: **5.3.1:** `ListRecent` encadena `.ToList()` dentro del `lock`.
- **78. `LobbyChatService`**: **10.1.1 (incumplimiento):** crea `new ChatModerator(unitOfWork)` dentro del constructor, en
  lugar de recibir `IChatModerator` como `MatchChatService` (la raíz de composición ya registra `IChatModerator`).
  `PrivateChatService` hace lo mismo (se ve en su revisión). **5.3.1:** `OpenLobbyChat` encadena `.Select(…).ToList()`.
  **R-14:** `return _chatRoom.Post(new ChatLine(…));` y `return new LobbyChatHistory(entries, _chatRoom.CountListeners(),
  _moderator.FindMute(…));` llevan llamadas en los argumentos. **7.1.2:** `<inheritdoc/>`.
- **79. `MatchChatRelay`**: cumple (salvo el nombre de la 62). **Sin cambios.**
- **80. `MatchChatService`**: documentado con `<inheritdoc/>`. **R-14:** `return _matchChatRelay.Post(…, new ChatLine(…), …);`.
- Pasada 2 (se pregunta): «moderar + esperar + `TooFast`» se repite en `LobbyChatService`, `MatchChatService` y
  `PrivateChatService`, cada uno con sus comprobaciones antes (participación, amistad).

**Decisiones del usuario (61 a 81):** `TryClaimTurn` → `TryStartCooldown` en todas las salas, con campos
`_lastMessageAtByAccountId`/`lastMessageAt` y `_cooldownLock`; `Screen` → `ScreenMessage`; `ListRecent()` sin parámetro
(la sala devuelve `new List<PostedChatLine>(_history)`); la repetición se queda en cada servicio. Se aplicaron la
10.1.1 (`LobbyChatService` recibe `IChatModerator`), la 5.3.1 ×3, la R-14 ×4, la R-11 ×4 y la R-27 (documentación de
`ILobbyChatService` e `<inheritdoc/>`). También cambian `IPrivateChatRoom`, `PrivateChatRoom` y `PrivateChatService`
(solo los renombres; su `new ChatModerator` se ve en `PrivateChat`) y tres archivos de pruebas (dos nombres de prueba
`TryClaimTurn_…` → `TryStartCooldown_…`, y `…_FirstTurn_…` → `…_FirstMessage_…`). Se quitó el `using System.Linq` que
dejó de usarse en `LobbyChatRoom`. Compila el servidor (carpeta aparte) y pasan 158 + 220 pruebas. Commit `2bb2c4f`,
sin push.

### 82 a 84. `Common` (2026-11-10)

`IPlayerActivity` (tres preguntas `Has`/`Is`), `IUnitOfWork` (los repositorios y `SaveChanges`) y `PlayerActivity` (reúne
el notificador, la cola y el registro de salas; tres parámetros). Cumplen y se usan. **Cerrados sin cambios.**

### 85 a 108. `Friends` (2026-11-10)

CU-21, CU-22, CU-24 y la presencia de amigos. En orden alfabético:
- **Records con referencias → R-11 (8):** `FriendPresenceChange` (87), `FriendRequestBoard` (91), `FriendRequestSummary` (94),
  `FriendRoster` (95), `FriendStatus` (96), `FriendSummary` (97), `PlayerIdentity` (107), `PlayerSearchResult` (108).
  Ninguno se copia con `with`.
- **Enumeraciones** `FriendPresence` (86), `FriendRelationship` (89), `FriendRequestOutcome` (92), `FriendshipRejection` (99):
  cumplen. `FriendshipRejectedException` (98): 9.6.1 con datos. **Sin cambios.**
- **Puertos** `IFriendNotifier` (101), `IFriendRequestRepository` (103), `IFriendshipRepository` (105), `IPlayerPresence`
  (106): cumplen, se usan. **Sin cambios.**
- **Servicios sin documentación → R-27:** `IFriendListService` (100), `IFriendPresenceService` (102),
  `IFriendRequestService` (104), con `<inheritdoc/>` en sus implementaciones.
- **85. `FriendListService`**: **5.3.1:** `ListFriends` encadena `.Select().OrderBy().ToList()`. Pasada 3 (se pregunta):
  en `RemoveFriend`, `if (friend is null || !_unitOfWork.Friendships.Remove(…))` borra dentro de la condición.
- **88. `FriendPresenceService`**: cumple (solo la R-27).
- **90. `FriendRelationshipResolver`**: **5.1.1 (incumplimiento):** la lambda de `FirstOrDefault` ocupa dos líneas →
  ayudante privado `Involves(request, accountId)`. **R-04:** `return request.IsSentBy(…) ? … : …;` → `if` y `return`.
- **93. `FriendRequestService`**: **5.3.1 ×4** (`SearchPlayers`, `ListFriendRequests` dos veces, `CreateRelationshipResolver`).
  Pasada 2 (se pregunta): en `ListFriendRequests` el filtro `ExpiresAt > now` se repite dos veces; `RejectFriendRequest`
  y `CancelFriendRequest` son iguales salvo quién es el solicitante; normalizar, validar y buscar por código se repite en
  `FindPlayerByCode`, `FindPlayers` y `PrivateChatService.FindPartner`; «verificar la sesión y buscar la identidad o
  `InvalidSessionException`» se repite en `FriendListService`, `VerifyPlayer` y `PrivateChatService`. Pasada 3 (se
  pregunta): `FindPendingRequest` también **borra** la solicitud caducada, y el nombre no lo dice.
  **Lectura L-17:** `return … ?? throw new …;` (`VerifyPlayer`, `FindPlayerByCode`).
- **107. `PlayerIdentity`** (6.4, se pregunta): vive en `Friends`, pero es la identidad pública de una cuenta y la usan
  cuentas, chat privado, el Host y los adaptadores.
- Nota para `Sessions`: `ConnectedPlayer` es una clase inmutable → 2.8.1 (`record`).

**Decisiones del usuario (85 a 108):**
- Nueva clase estática **`FriendCodeLookup.FindPlayer(accounts, enteredCode)`** en `Friends`. Normaliza, valida y busca,
  y devuelve `null` si el código no es válido o no tiene dueño. La usan `FindPlayerByCode`, `FindPlayers` y
  `PrivateChatService.FindPartner`.
- Dos ayudantes privados en `FriendRequestService`: `ListUnexpired(requests, now)` y
  `RemoveRequest(requesterAccountId, recipientAccountId, now)`.
- `return x ?? throw new X();` se admite (**R-28**).
- `PlayerIdentity` se mueve a `Accounts` (6.4).
- **`ISessionVerifier.VerifyIdentity`**, que devuelve `PlayerIdentity` desde la misma cuenta que lee `Verify`
  (privado `FindSessionAccount`). La usan `FriendListService.ListFriends`, `SendFriendRequest` y
  `AcceptFriendRequest`; `PrivateChatService` la adopta en su revisión.
- `FindPendingRequest` → `FindPendingRequestAndRemoveExpired`.
- `RemoveFriend` separa el borrado en `bool isRemoved`.

Se aplicaron la R-11 ×8, la R-27 ×3 (más `<inheritdoc/>`), la 5.3.1 ×5, la 5.1.1 (ayudante `Involves`) y la R-04 en
`FriendRelationshipResolver`. Los `using Bastion.Server.Application.Accounts` se agregaron en orden con un script
(`scratchpad/tools/add_using.py`). Se quitaron los `using …Friends` que quedaron sin uso y el `using Bastion.Domain.Friends`
de `PrivateChatService`. `FakeSessionVerifier` gana `Add(token, PlayerIdentity)` y `VerifyIdentity`, y las pruebas de
`FriendListService` y `FriendRequestService` registran la identidad en el verificador. Compila el servidor (carpeta
aparte) y pasan 158 + 220 pruebas. Commit `d486e69`, sin push.

### 109 a 115. `Matches` (2026-11-10)

- **109. `AbandonmentNotice`** (`record (string AbandoningNickname, bool IsMatchOver)`): **R-11**.
- **110. `IMatchAbandonmentService`**: ya documentada, pero **7.2.2 (incumplimiento):** faltaba
  `<exception cref="ArgumentNullException">` del `sessionToken`, que el método deja salir.
- **111. `IMatchEndNotifier`**, **112. `IMatchStore`** (sus ocho métodos se usan), **114. `MatchNotJoinedException`**
  (tres constructores estándar) y **115. `MatchStoreException`**: cumplen. El cuarto constructor
  `MatchStoreException(Exception)` lo usa `MatchStore` y fija el mensaje en inglés (9.6.1). **Sin cambios.**
- **113. `MatchAbandonmentService`**: documentado y con `<inheritdoc/>`; bitácora Warn/Info con `Clave=valor`.
  **5.3.1:** `new List<int>(recipientAccountIds)` se materializaba dentro de los argumentos de la llamada → en su propia
  instrucción.

Cerrados sin preguntas. Compila el servidor (carpeta aparte) y pasan 220 pruebas de aplicación. Commit `8e57acb`, sin
push.

### 116 a 134. `Matchmaking` (2026-11-10)

CU-09 (cola clasificatoria, emparejamiento y aviso de presencia). En orden alfabético:
- **Records con referencias → R-11:** `CreatedMatch` (116), `CreatedMatchParticipant` (117), `MatchPairing` (124),
  `QueueReview` (130). `PresenceRequest` (129) solo tiene valores (R-16). **Sin cambios.**
- **Cumplen, sin cambios:** `IMatchSearchService` (118, ya documentada con sus excepciones), `IMatchmakingNotifier` (119),
  `IMatchmakingPlayerVerifier` (120), `IMatchmakingQueue` (121), `IRankedMatchCreator` (122: patrón Try con
  `[NotNullWhen(true)]` en el `out` de referencia, como `Dictionary.TryGetValue`; la R-06 descartó atributos para el
  `DateTime` de `Account`, que es otro caso), `ITurnOrderShuffler` (123, genérico `TPlayer`, 2.13.1), `MatchSearchService`
  (125), `MatchmakingDispatcher` (126), `MatchmakingPlayerVerifier` (127), `SearchEndReason` (132), `SearchRejectedException`
  (133) y `SearchRejection` (134).
- **128. `MatchmakingQueue`**: lo anotado en el archivo 32: el resultado de `StartPresenceCheck` va en
  `DateTime presenceDeadline`. `TakePairings` cumple la 5.3.1 (un operador por línea y `new List`). Pasada 2 (se
  pregunta, candidato anotado): `MatchmakingPolicy.PlayersPerMatch = 2` es el `PlayerCount` de `CLASSIC` en el catálogo.
- **131. `RankedMatchCreator`**: **5.3.1 ×2:** `string.Join(…, pairing.Players.Select(…))` pasa la consulta sin guardarla, y
  `CreateEntrants` encadena `.ToArray()`. **R-14:** `return new CreatedMatch(matchId, format, ToParticipants(…));`. Captura
  solo `MatchStoreException` (9.3.1) y registra con la excepción aparte (11.3.1). Nota para `Rooms`: `PrivateMatchCreator`
  repite la búsqueda del Elo con `ModeStatistic.DefaultEloRating`.

**Decisión del usuario:** `PlayersPerMatch` se queda. La cola trabaja en memoria, y si el catálogo cambia,
`Match.SeatEntrants` rechaza la partida, el fallo se registra y se avisa a los jugadores. Se aplicaron la R-11 ×4,
`presenceDeadline` y, en `RankedMatchCreator`, la 5.3.1 ×2 y la R-14. Compila el servidor (carpeta aparte) y pasan 220
pruebas de aplicación. Commit `fa4b91d`, sin push.

### 135 y 136. `Moderation` (2026-11-10)

`IBannedWordRepository.ListChatTerms` e `ISanctionRepository.ListChatSanctions`: puertos que cumplen y se usan.
**Cerrados sin cambios.**

### 137 a 148. `PrivateChat` (2026-11-10)

- **Records con referencias → R-11 (6):** `ConversationPartner` (137), `ConversationSummary` (138), `PrivateConversation`
  (145), `PrivateMessageDelivery` (146), `PrivateMessageDraft` (147), `PrivateMessageEntry` (148).
- **139. `IMessageRepository`**: Pasada 3 (se pregunta, anotado en el archivo 14): `MarkRead(MessageParticipants
  readMessages, …)` se lee como una colección de mensajes (2.1.2), y es la pareja autor-destinatario.
- **140. `IPrivateChatRoom`**, **142. `IPrivateMessageNotifier`**, **143. `PrivateChatRoom`**: cumplen. **Sin cambios.**
- **141. `IPrivateChatService`**: servicio sin documentación → **R-27**.
- **144. `PrivateChatService`**:
  - **10.1.1 (incumplimiento, anotado en el archivo 78):** crea `new ChatModerator(unitOfWork)`. Recibirlo daría cuatro
    parámetros al constructor (verificador, unidad de trabajo, sala y moderador), y la **2.2.2** pide un DTO a partir de
    tres (se pregunta).
  - **5.1.1 (incumplimiento):** `ListConversations` tiene una lambda de seis líneas dentro de `Select`; además encadena
    `.ToList()` dos veces (5.3.1), una dentro de un argumento, y `.ToDictionary` al final.
  - **5.3.1:** `OpenConversation` encadena `.ToList()`. **R-14:** `return new PrivateConversation(new …, entries,
    _moderator.FindMute(…));`. **R-04:** `IsFriend` devuelve `ListFriendAccountIds(…).Contains(…)`.
  - Decidido en `Friends`: `SendPrivateMessage` usa `VerifyIdentity` en lugar de buscar la identidad al final.
    `FindPartner` e `IsFriend` pasan a recibir el `accountId`.

**Decisiones del usuario (137 a 148):**
- **`PrivateChatChannel(IPrivateChatRoom Room, IChatModerator Moderator)`** como DTO del constructor (2.2.2 con 10.1.1):
  `PrivateChatService(ISessionVerifier, IUnitOfWork, PrivateChatChannel)`. La raíz de composición registra
  `services.AddScoped<PrivateChatChannel>()`, y el contenedor lo arma por su constructor, sin `GetRequiredService`.
- `ListConversations` con un bucle `foreach`.
- `readMessages` → `participants`.
- **L-01 → R-29:** el diccionario de compañeros se crea con `var partnersById = new Dictionary<int,
  PlayerIdentity>(partnerIdentities.Count);` y se llena con un `foreach`, en lugar de `ToDictionary`. El usuario preguntó
  si el bucle saturaría la rutina con muchos datos: no, `ToDictionary` hace el mismo recorrido lineal por dentro y
  reserva la capacidad cuando conoce el tamaño; con la capacidad en el `new` el costo es igual. Aquí el tamaño es el
  número de conversaciones del jugador.

Se aplicaron la R-11 ×6, la R-27 (documentación de `IPrivateChatService` e `<inheritdoc/>`), la 5.3.1, la R-14 y la R-04.
Cambian `MessageRepository`, `ServiceRegistration`, `FakeMessageRepository` y `TestPrivateChatService`, que arma el
canal y registra la identidad en el verificador. Compila el servidor (carpeta aparte) sin avisos y pasan 158 + 220
pruebas. Commit `85ffd48`, sin push.
Quedan `ToDictionary` en dos consultas de EF (`MatchStore` línea 96 y `MessageRepository` línea 60). La 5.3.1 dice que
las consultas `IQueryable` siguen solo la 3.5; se ven al revisar esos archivos.

### 149 a 174. `Rooms` (2026-11-10)

CU-10 y CU-11 (salas privadas, código, listos, ajustes y partida privada). En orden alfabético:
- **Cumplen, sin cambios:** `IPrivateMatchCreator` (149), `IPrivateRoomService` (150, ya documentada), `IRoomCodeGenerator`
  (151), `IRoomKeeper` (152), `IRoomMatchService` (153, ya documentada), `IRoomMatchStarter` (154), `IRoomNotifier` (155),
  `IRoomPlayerVerifier` (156), `IRoomSettingsValidator` (158), `IRoomStore` (159), `RequestedRoomSettings` (162, solo
  valores, R-16), `RoomMatchStarter` (166), `RoomRejectedException` (170, dos constructores con datos), `RoomRejection`
  (171), `RoomSettingsValidator` (172) y `RoomStoreException` (174, como `MatchStoreException`).
- **9.4.1 (incumplimiento):** no comprueban `sessionToken` al inicio, porque lo dejan al verificador:
  `PrivateRoomService.SetReady`, `LeaveRoom` y `FindOwnRoom` (161), `RoomMatchService.StartMatch` (165) y
  `RoomPlayerVerifier.VerifyPlayerCanEnterRoom` (168).
- **160. `PrivateMatchCreator`**: **5.3.1 ×2** (`Select().ToArray()` dentro de un argumento, `Select().ToList()`), **R-14**
  (`return new CreatedMatch(…, ToParticipants(…))`) y **R-23** (`(byte)(Match.FirstTurnOrder + memberIndex)`).
- **161. `PrivateRoomService`**: **R-04** en `JoinRoom` (`return _roomKeeper.Join(player, code.Trim().ToUpper(…), now);`).
  Pasada 2 (se pregunta): esa normalización del código de sala es una regla del dominio, como `FriendCodePolicy.Normalize`.
- **163. `RoomDeparture`**: **R-11**.
- **164. `RoomKeeper`**: Pasada 2 (se pregunta, anotado en el archivo 47): `ChangeSettings` comprueba
  `hostedRoom.Members.Count > settings.GameMode.PlayerCount` antes de guardar, y `RoomRegistry.ChangeSettings` vuelve a
  comprobar `WaitingRoom.CanSeatAllMembers`: la misma regla en dos lugares.
- **165. `RoomMatchService`**: **R-04:** `return _matchStarter.StartMatch(…).MatchId;`.
- **167. `RoomMemberSnapshot`**: record posicional de **cinco** parámetros → **R-09/2.2.2 (incumplimiento):** se pregunta si
  se agrupa o pasa a propiedades `init`.
- **169. `RoomRegistry`**: **R-04** en `FindRoomOf` (`?:` con llamadas) y en `FindHostedRoom` (llamada anidada); **R-14** en los
  dos `new RoomDeparture(RoomSnapshot.Capture(room), …)`; **5.3.1** en `RemoveRoom` (`foreach` sobre un `Select` sin guardar;
  basta recorrer `room.Members`). Pasada 4 (se pregunta): `StartMatch<TResult>` es genérico y solo se usa con
  `CreatedMatch`. Nota: `_failedAttemptsByAccountId` nunca se vacía, así que guarda un historial por cada jugador que falló
  un código mientras el servidor sigue encendido.
- **173. `RoomSnapshot`**: **R-11**; **R-17:** `SeatCount =>` → método; **5.3.1** en `Capture` y en `ListAccountIdsExcept`
  (además, R-12); **R-14** en `CaptureMember` (`room.IsHost(…)` dentro del `new`).
- Pasada 2 (se pregunta): `MatchmakingPlayerVerifier.VerifyPlayerCanSearch` y `RoomPlayerVerifier.VerifyPlayerCanEnterRoom`
  hacen casi las mismas comprobaciones (canal de avisos, partida sin terminar, en sala), con distinta excepción.

**Decisiones del usuario (149 a 174):**
- `RoomMemberSnapshot` pasa a propiedades `required { get; init; }` con inicializador (R-09), en `CaptureMember` y en dos
  pruebas.
- `RoomPolicy.NormalizeCode` (recorta y pasa a mayúsculas invariantes) en el dominio.
- `RoomSnapshot.CanSeatAllMembers(settings)`, que usa `RoomKeeper.ChangeSettings`.
- `StartMatch<TResult>` se queda genérico (el registro no depende de Matchmaking).
- Los verificadores de jugador se quedan separados.
- `RoomRegistry` borra el historial de códigos fallidos de un jugador cuando queda vacío (`ForgetEmptyHistory`, después
  de revisar el límite). Queda una limitación: el historial de quien falló y no vuelve a intentar se queda hasta su
  siguiente intento.

Se aplicaron la 9.4.1 (cinco métodos), la 5.3.1 (`PrivateMatchCreator` ×2, `RoomSnapshot` ×2 y `RemoveRoom`, que ahora
recorre `room.Members`), la R-04 (`FindRoomOf` con `if`, `FindHostedRoom`, `RoomMatchService`, `JoinRoom`), la R-14, la
R-17 (`GetSeatCount()`, también en `RoomTranslator`), la R-23 y la R-11 (`RoomDeparture`, `RoomSnapshot`). Se quitó el
`using System.Linq` sin uso de `RoomRegistry`. `var closedRoom = RoomSnapshot.Capture(room);` usa `var` porque es un
método estático que devuelve su propio tipo (3.4.1). Compila el servidor (carpeta aparte) sin avisos y pasan 158 + 220
pruebas. Commit `1fd9813`, sin push.

### 175 a 182. `Security` y `Sessions` (2026-11-10)

- **175. `GeneratedToken`** y **178. `ConnectedPlayer`**: clases inmutables que no son de EF → **2.8.1:** `sealed record`
  (mismo constructor con `ThrowIfNull`). Commit `d4b645e`.
- **176. `IPasswordHasher`** (`Verify`, excepción de la 2.2.3), **177. `ISessionTokenGenerator`**, **179. `ISessionRepository`**,
  **180. `ISessionVerifier`**, **181. `InvalidSessionException`** (tres constructores estándar) y **182. `SessionVerifier`**
  (cambiado en `Friends` con `VerifyIdentity` y `FindSessionAccount`): cumplen. **Sin cambios.**

### Cierre de la capa `Bastion.Server.Application` (2026-11-10)

Según la R-27, se activó la verificación de la 7.3.1:
- `Bastion.Server.Application.csproj` pone `GenerateDocumentationFile` en `true`.
- `.editorconfig` apaga CS1591 en `[*.cs]` y lo hace error en `[I*Service.cs]`.

Las 11 interfaces `I…Service` de la capa están documentadas y compila sin avisos. Se comprobó que funciona: al quitar
el `<summary>` de `ILoginService`, la compilación falla con `error CS1591`; luego se restauró el archivo. Pasan
158 + 220 + 136 pruebas. Commit `7171c56`, sin push.

**Pendiente para la revisión de la configuración** (no se preguntó ni se cambió, por indicación del usuario): en
`.editorconfig`, «# 3.4.1 At most 120 characters per line» y «# 3.5.1 var only…» citan la numeración vieja (8.1.2). En
v2.4, la 3.4.1 es `var` y la 3.5.1 dice que no hay largo máximo de línea.

**Capa `Bastion.Server.Application` terminada** (archivos 53 a 182). Sigue `Bastion.Server.Adapters` (32 archivos). Pendientes
anotados para esa capa:
- `UnitOfWork.SaveChanges` no traduce las excepciones de EF.
- Los `ToDictionary` sobre `IQueryable` en `MatchStore` y `MessageRepository`.
- La proyección de caducidad en `FriendRequestRepository`.
- `FriendshipRepository.Remove` (orden menor/mayor y nombres `accountAId`/`accountBId`).
- `MessageConfiguration.TextLength = 500` frente a los 200 del dominio (4.4.2).
