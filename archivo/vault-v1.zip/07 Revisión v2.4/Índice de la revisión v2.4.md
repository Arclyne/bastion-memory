---
tags: [indice, revision-v2-4]
---
# Índice de la revisión v2.4
Volver a [[00 Inicio]] · Original completo: [[journal-revision-v2.4]]

Journal de tu amigo de la revisión del código contra el estándar v2.4, separado por partes y ordenado. El texto no se modificó.

- [[Estado de la entrega]]
- [[Decisiones de método]]
- [[Cómo se revisa cada archivo]]
- [[Lecturas abiertas del estándar]]
- [[Interpretaciones del estándar|Decisiones de reglas]]
- [[Candidatos a reutilizar]]
- [[Registro de archivos]]
- [[Bitácora 1 - Bastion.Domain]]
- [[Bitácora 2 - Bastion.Server.Application]]
- [[Bitácora 3 - Bastion.Server.Adapters]]
- [[Bitácora 4 - Bastion.Server.Host]]
- [[Bitácora 5 - Bastion.Contracts]]
- [[Bitácora 6 - Bastion.Client.Networking]]
- [[Bitácora 7 - Bastion.Client]]
