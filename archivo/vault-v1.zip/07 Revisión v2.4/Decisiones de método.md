---
tags: [revision-v2-4]
---
# Decisiones de método
Volver a [[Índice de la revisión v2.4]]

| Id | Fecha | Decisión |
| --- | --- | --- |
| D-01 | 2026-11-10 | Se revisa archivo por archivo, nunca el proyecto entero de una vez. |
| D-02 | 2026-11-10 | Orden por capas, de adentro hacia afuera: Domain → Server.Application → Server.Adapters → Server.Host → Contracts → Client.Networking → Client; al final las pruebas de cada proyecto. |
| D-03 | 2026-11-10 | Los hallazgos se registran aquí; las decisiones las toma el usuario; al aprobarlas se corrige ese archivo en la rama de trabajo, con compilación y pruebas. Nada se sube sin que el usuario lo pida. |
| D-04 | 2026-11-10 | Una pausa al terminar cada archivo, con todas sus dudas juntas. No se supone nada: toda duda va al usuario. |
| D-05 | 2026-11-10 | El journal vive en `context/revision-v2.4/`, fuera del repositorio. |
| D-06 | 2026-11-10 | **La prioridad es la facilidad de lectura.** Un `return` se lee de un vistazo: si la expresión hace más de un paso (restar, convertir, redondear), cada paso va en una variable con nombre antes del `return`. Se evita repetir código, pero sin repartir lo que describe una misma cosa en varios lugares (por ejemplo, los valores iniciales de una clase no se dividen entre declaraciones y constructores). Toda propuesta se juzga primero por cómo se lee. |
| D-07 | 2026-11-10 | Un commit local por archivo revisado, con su identidad y sin rastro de IA, en `review-standard-v2.4`. **El push se hace solo al final de toda la revisión.** Las decisiones de los archivos anteriores (tabla «Decisiones de reglas») se aplican sin volver a preguntar en los siguientes. |
