---
tags: [revision-v2-4]
---
# Candidatos a reutilizar
Volver a [[Índice de la revisión v2.4]]

Datos o lógica vistos en archivos revisados, para comparar con los siguientes.

| Qué | Dónde aparece | Estado |
| --- | --- | --- |
| Tiempo límite y creación de `Regex` | `AccountRules`, `FriendCodeRules` | Decidido (R-08): `TextPattern.Create`; `FriendCodeRules` se cambia al revisarlo |
| Jugadores por partida clasificatoria (4.4.2) | `MatchmakingRules.PlayersPerMatch = 2`; `GameMode(CLASSIC).PlayerCount = 2` en el catálogo | Decidido: se queda (archivos 116–134) |
| Alfabeto de los códigos | `FriendCodeRules.Alphabet` (sin L) y `RoomRules.CodeAlphabet` (con L) | Se pregunta al revisar `RoomRules.cs` |
| Buscar jugador por código de amigo | `FriendRequestService.FindPlayerByCode`, `PrivateChatService` (normalizar → validar → `FindPlayerIdentityByFriendCode`) | Decidido: `FriendCodeLookup.FindPlayer` (archivos 85–108) |
| Verificar la sesión y buscar la identidad | `FriendListService`, `FriendRequestService`, `PrivateChatService` | Decidido: `ISessionVerifier.VerifyIdentity`; falta adoptarlo en `PrivateChatService` |
| Largo máximo del mensaje (4.4.2) | `ChatRules.MaximumMessageLength = 200`; `MessageConfiguration.TextLength = 500`; `Message.Text NVARCHAR(500)` | Decidido: `ChatPolicy` en EF y `NVARCHAR(200)` en el script (commit `12b9ebe`); la base local sigue en 500 hasta que el usuario decida |
