---
tags: [revision-v2-4]
---
# Bitácora 3 - Bastion.Server.Adapters
Volver a [[Índice de la revisión v2.4]]

### 183 a 200. Registro, contexto, configuraciones y convertidor (2026-11-10)

- **183. `AdaptersRegistration`** (raíz de composición de los adaptadores, 10.2.1) y **184. `TurnOrderShuffler`**
  (`ToArray` sobre una lista, no una consulta encadenada): cumplen. **Sin cambios.**
- **185. `BastionDbContext`**: Pasada 1 (se pregunta, anotado en la R-20): trece `DbSet<T> X => Set<T>();` con `=>`.
- **186 a 198. Configuraciones de EF:**
  - **9.4.1 (incumplimiento):** `Configure(builder)` es público y no comprueba `builder` en ocho de trece: `AccessLog`,
    `Account`, `BannedWord`, `FriendRequest`, `Friendship`, `Message`, `Sanction` y `Session`. Las otras cinco sí lo hacen.
  - Pasada 2 (se pregunta): `.HasConversion(new UpperSnakeCaseEnumConverter<X>()).HasMaxLength(N).IsUnicode(false)` se repite
    doce veces; `EndReasonLength = 15` está en `MatchConfiguration` y en `ParticipationConfiguration` para la misma
    enumeración (`MatchEndReason`).
  - **4.4.2 (se pregunta, anotado en el archivo 9):** `MessageConfiguration.TextLength = 500`, que coincide con
    `Message.Text NVARCHAR(500)` de la base, mientras que el dominio limita a 200 (`ChatPolicy.MaximumMessageLength`).
- **199. `UpperSnakeCaseEnumConverter`**: la 5.2.1 no aplica a `value => ToCode(value)`: `ValueConverter` recibe
  `Expression<Func<…>>`, y un grupo de método no se convierte en árbol de expresión. **R-25:** `ToCode` y `FromCode` son
  públicos y solo los usa la clase → `private`.
- **200. `DeletedRowCount`**: objeto de datos para `SqlQuery` (2.11.3, `get; set;`). **Sin cambios.**

**Decisiones del usuario (183 a 200):**
- Los `DbSet<T> X => Set<T>()` se quedan como patrón de EF (**R-31**).
- `MessageConfiguration` usa `ChatPolicy.MaximumMessageLength` y el script `02_create_tables.sql` pasa
  `Message.Text` a `NVARCHAR(200)`. Los mensajes de prueba miden como mucho 77 caracteres. **De momento solo el
  script**: la base local sigue con `NVARCHAR(500)`, y cambiarla pide quitar y recrear `CK_Message_Text`.
- `EndReasonLength` es una sola constante pública en `MatchConfiguration`, que usa `ParticipationConfiguration`.
- Las 14 columnas de enumeración (no eran 12) usan el nuevo **`EnumColumnMapping.HasUpperSnakeCaseConversion(largo)`**:
  - Tiene dos sobrecargas, para `PropertyBuilder<TEnum>` y `PropertyBuilder<TEnum?>`, porque `TEnum?` es
    `Nullable<TEnum>` y no cumple `struct`.
  - El cuerpo está una sola vez, en el privado `StoreAsCode<TEnum>(PropertyBuilder, largo)`, sobre la clase base.
  - El usuario preguntó la diferencia entre las dos: no son constructores, sino sobrecargas para propiedades que no
    admiten nulos y para las que sí.

Se aplicaron la 9.4.1 (ocho `Configure`) y la R-25 (`ToCode`/`FromCode` privados; los árboles de expresión del
convertidor siguen funcionando). Se quitó el `using …Conversions` de las configuraciones que ya no usan el convertidor.
Una lectura de la base local confirmó las enumeraciones, también las anulables y una dentro de una consulta, y el largo
200 del modelo. Compila el servidor (carpeta aparte) sin avisos y pasan 158 + 220 pruebas. Commit `12b9ebe`, sin push.

**PR #15 fusionado** en `main` (`2eb1167`). La revisión sigue en la rama **`review-standard-v2.4-repositories`**, creada
desde ese `main`. Por indicación del usuario, en esta rama solo se hacen commits locales; el push espera a que él lo pida.

### 201 a 208. Repositorios de `Adapters` (2026-11-10)

Son consultas de EF sobre `IQueryable`. La 5.3.1 las exceptúa («se rige solo por la Sección 3.5»), pero la R-04 y la 5.1.1 sí
aplican.
- **201. `AccessLogRepository`** y **208. `SessionRepository`** (`FirstOrDefault` con una lambda de una línea, R-21): cumplen.
  **Sin cambios.**
- **Lectura L-18 (R-04 en consultas de EF):** casi todos los métodos devuelven la cadena entera
  (`return _context.X.Where(…).Select(…).ToList();`), en `AccountRepository` (4), `BannedWordRepository`, `FriendRequestRepository`
  (2), `FriendshipRepository` (3), `MessageRepository` (2) y `SanctionRepository`.
- **Lectura L-19 (5.1.1 en consultas de EF):** hay lambdas de varias líneas en condiciones largas: `AccountRepository.SelectActivePlayers`,
  `FriendRequestRepository.FindBetween` (pareja en los dos sentidos), `FriendshipRepository.ListFriends` (condición y proyección),
  `MessageRepository.ListConversation` y `MarkRead`, y la proyección de `FriendRequestRepository.ListSummaries` (cuatro
  líneas). En EF no se puede usar un grupo de método, porque la consulta necesita un árbol de expresión.
- Pasada 2: `new PlayerIdentity(account.AccountId, account.Nickname, account.FriendCode)` se repite en seis proyecciones
  (`AccountRepository` ×4, `FriendRequestRepository`, `FriendshipRepository`). `ListSummaries` repite la fórmula de
  caducidad de `FriendRequest.GetExpirationTime` (anotado en el archivo 16). `FriendshipRepository.Remove` repite el orden
  menor/mayor del constructor de `Friendship`, con variables `accountAId`/`accountBId` (anotado en el archivo 17).
- **3.4.1:** `MessageRepository.ListConversation` usa `var latestFirst = ….ToList();`, y `ToList` no está en la lista de la 3.4.1.
- **5.1.2 (hallazgo nuevo):** lambda dentro de lambda en `MessageRepository`: `conversation.Max(message => …)` y
  `setters.SetProperty(message => message.ReadAt, readAt)`.

**Decisiones del usuario (201 a 208):**
- **R-32 (L-18 → D):** toda consulta de EF sigue la forma de la 5.3.1. La consulta va en un `IQueryable<T>` con nombre en
  plural y el método devuelve `new List<T>(consulta)`. Las de valor único hacen `FirstOrDefault()` en una variable o en
  un ayudante. Los métodos privados que arman una consulta (`Select…`) la guardan en una variable y devuelven la
  variable, o una sola llamada (`a.Concat(b)`).
- **R-33 (L-19 → A):** las consultas de EF se parten en pasos simples:
  - una condición `&&` por `.Where`; EF las une con `AND`;
  - una pareja en los dos sentidos se resuelve con `Concat` de dos consultas de un sentido (`UNION ALL`), o con dos
    búsquedas por clave unidas con `??` (9.4.2);
  - `GroupBy(clave, elemento)` y `.Select(ids => ids.Max())`, sin lambda anidada (5.1.2);
  - `ExecuteUpdate(setters => setters.SetProperty(_readAt, readAt))`, con el selector en un campo estático
    `Expression<…>`;
  - las proyecciones anidadas traen la entidad y arman el resultado en memoria con un método (grupo de método, 5.2.1).
- `FriendshipRepository.Remove`: `smallerAccountId`/`largerAccountId`.

**Aplicado** en la rama `review-standard-v2.4-repositories` (sin commit todavía):
- `AccountRepository`: cuatro consultas con D; los ayudantes privados `FindIdentity(IQueryable<Account>)` y
  `ListIdentities(IQueryable<Account>)`; `SelectActivePlayers` con dos `.Where` y `AsNoTracking`.
- `BannedWordRepository` y `SanctionRepository` siguen D; el `&&` de la sanción quedó en dos `.Where`.
- `FriendRequestRepository`:
  - `FindBetween` es `FindSent(a, b) ?? FindSent(b, a)`, con `DbSet.Find` por la clave (RequesterId, RecipientId);
  - `ListSummaries` hace el `Join` hacia el tipo privado anidado `RequestWithCounterpart` (constructor explícito, R-11);
  - el mapeo va en memoria con `ToSummary`, que usa `GetExpirationTime()` y ya no copia la fórmula de caducidad.
- `FriendshipRepository`: `ListFriends` lleva dos `.Where` y mapea en memoria (`ToFriendSummary`);
  `SelectFriendAccountIds` tiene dos consultas con nombre y un `Concat`; los nombres de `Remove` cambiaron.
- `MessageRepository`:
  - `ListConversation` hace un `Concat` de `SelectMessagesFrom` en los dos sentidos (`conversationMessages`, plural);
  - `ListLatestPerPartner` usa `GroupBy` con un selector de elemento;
  - `CountUnreadByAuthor` proyecta a `KeyValuePair<int, int>` y devuelve `new Dictionary<int, int>(consulta)`;
  - `MarkRead` usa el campo `_readAt`.
- **Pasada 2:** `new PlayerIdentity(account.AccountId, account.Nickname, account.FriendCode)` estaba **ocho** veces: seis en
  `Adapters` y dos en `Application` (`FriendPresenceService`, `SessionVerifier`). Ahora es la fábrica
  `PlayerIdentity.FromAccount(Account)` (`Application`, con `ThrowIfNull`).

**Verificación:**
- Se hizo una foto de lo que devuelven los repositorios en la base local antes y después, solo leyendo: 43 líneas
  **idénticas**.
- Se revisó el SQL: `INNER JOIN` en `ListSummaries`, `GROUP BY … COUNT(*)` con `KeyValuePair`, `MAX` sin lambda
  anidada, dos `SELECT TOP(1)` por clave en `FindBetween` y `UPDATE … SET ReadAt` en `MarkRead`. `MarkRead` se probó
  con las cuentas -1 y -2, que no existen, dentro de una transacción deshecha: no tocó ninguna fila.
- Compila sin avisos de código (solo los NU1902/NU1903 de NuGet, que ya estaban). Pasan 158 + 220 + 136 pruebas.
- Precio conocido del mapeo en memoria: las lecturas de identidad traen todas las columnas de `Account`, también
  `PasswordHash`, `PasswordSalt` y `Email`.

**Preguntas antes del commit:**
1. Dónde vive el mapeo a `PlayerIdentity`. Está aplicada la fábrica en `PlayerIdentity`. El usuario preguntó si
   convenía un **ensamblado propio** como referencia central para `Application` y `Adapters`, y se analizó así:
   - Las referencias son `Application → Domain`, `Adapters → Domain, Application` y `Host → Contracts, Application, Adapters`.
   - El mapeo necesita `Account` (`Domain`) y `PlayerIdentity` (`Application`). Un ensamblado que solo tenga el mapeo
     tendría que referenciar `Application`, y entonces `Application` no podría usarlo (referencia circular). Sus dos
     copias se quedarían.
   - Para que sirva a las dos capas, `PlayerIdentity` tendría que mudarse a ese ensamblado. Eso cambia 30 archivos que
     usan el tipo (3 de `Adapters`, 16 de `Application`, 2 de `Host` y 9 de pruebas), agrega un octavo proyecto para un
     método de seis líneas y saca de `Application` un tipo que forma parte de su puerto `IAccountRepository`.
   - No hay más mapeos repetidos que lo llenen: las demás construcciones desde entidades (`ConnectedPlayer`, `Session`,
     `Friendship`, `RoomSnapshot`, `MatchFormat`) aparecen una sola vez.
   - Por analogía con la 4.4.2 («en la capa más interna que lo necesita»), la capa más interna que conoce los dos
     tipos es `Application`, y `Adapters` ya la referencia. **Se recomendó mantener la fábrica.** Falta la respuesta
     del usuario.
   - El usuario preguntó si la variante 1 llevaba **inyección de dependencias** para reducir el acoplamiento. Como se
     describió, no la llevaba: era una referencia directa. Se analizó con inversión de dependencias:
     - La interfaz `IPlayerIdentityMapper` iría en `Application`; la 2.14.2 admite el sustantivo porque su lista es
       abierta. La implementación iría en `Bastion.Server.Mapping → Application, Domain` y se registraría en `Host`.
       Con eso desaparece la referencia circular.
     - Cambia mucho:
       - `FriendPresenceService` y `SessionVerifier` pasan de dos a tres parámetros, el tope de la 2.2.2;
       - `UnitOfWork` pasa de uno a dos y le pasa el mapper a tres repositorios, que también pasan de uno a dos;
       - `Host` registra el servicio y referencia el proyecto nuevo;
       - dos pruebas tendrían que referenciar ese proyecto, o un falso que copie el mapeo por novena vez.
     - **No reduce el acoplamiento:** cinco clases suman una dependencia más y no se elimina ninguna. La 10.1.1 pide
       inyectar solo un servicio externo (entrada y salida, estado compartido o resultado no determinista), y un mapeo
       puro no es ninguno de los tres; no tiene otra implementación que cambiar ni nada que simular en una prueba.
       La inyección sería obligatoria si el mapeo llegara a necesitar un servicio externo, por ejemplo la presencia
       o un dato guardado aparte.
     - La variante ligera sería la misma interfaz con la implementación en `Adapters`, sin proyecto nuevo. Tiene el
       mismo costo en constructores y pruebas.
2. `CountUnreadByAuthor`: **el usuario eligió A** (`new Dictionary<int, int>(IQueryable<KeyValuePair<…>>)`, ya aplicada).

**Decisión final de la pregunta 1:** el usuario mantuvo la fábrica `PlayerIdentity.FromAccount` (**R-34**), sin ensamblado
propio y sin inyección.

Commit `f570f4f`, sin push.

### 209. `MatchStore` (2026-11-10)

Abre un contexto nuevo por operación (`IDbContextFactory`), porque lo usan servicios que viven más que una petición.
- **Pasada 1:**
  - **Sin hallazgos:** §1, §3, §5.1/5.2, §6 y §8 (no tiene comentarios).
  - **§9:** traduce `DbUpdateException` y `DbException` a `MatchStoreException`, conservando la interna (9.2.1). Las
    dos jerarquías no se relacionan, así que el orden da igual (9.1.2). Tiene `using` en el contexto (9.5.1) y
    `ThrowIfNull` en los públicos (9.4.1).
  - **§10:** `IDbContextFactory` se inyecta (10.1.1).
  - **No aplican:** §7 (no es un servicio), §11 (no escribe bitácora) y §12.
  - **2.14.2 (incumplimiento, no se vio al revisar `Application`):** la regla fija que "Store guarda y recupera datos
    locales del cliente". `MatchStore` y `RoomStore` guardan en SQL Server, desde el servidor. El uso correcto está en
    el cliente: `LanguagePreferenceStore`. La familia `IMatchStore`/`MatchStore`/`MatchStoreException`/`FakeMatchStore`
    y la de `Room` aparecen en 34 archivos: 3 de `Adapters`, 17 de `Application`, 5 de `Host` y 9 de pruebas.
  - **R-32/R-33, aplicadas:** seis consultas. `LoadEloRatingsByAccountId` pasa de `ToDictionary` a
    `new Dictionary<int, short>(consulta de KeyValuePair)`, y cada `&&` va en su propio `.Where`.
- **Pasada 2:**
  - `!participation.Result.HasValue` se repetía en dos consultas; ahora es `SelectUnfinishedParticipations`
    (4.4.1, aplicado, como `SelectActivePlayers`).
  - `Add` + `SaveChanges` + `return id` aparece en `AddMatch`, `AddMatchChatMessage` y `RoomStore.AddRoomInContext`
    (se pregunta).
  - `RunInNewContext` es idéntico en `RoomStore` salvo por el tipo de excepción; se pregunta en el archivo 210.
- **Pasada 3:** `UpdateMatch` también termina la sala de una partida privada, y su nombre no lo dice (se pregunta).
- **Pasada 4:** sus ocho métodos se usan (archivo 112). Nadie usa el `int` que devuelve `UpdateMatch` (las filas de
  `SaveChanges`); existe porque `RunInNewContext` pide un resultado. `RoomStore.UpdateRoom` hace lo mismo (se pregunta).
- **Verificación:** una foto de las lecturas en la base local, antes y después, solo leyendo: 48 líneas idénticas.
  Cubre las cuentas 1 a 14, los tres modos, el Elo de cuatro modos y nueve partidas más una inexistente. El SQL quedó
  igual: `EXISTS`, `TOP(1)`, `IN (…)` y `TOP(1)` con `LEFT JOIN`. Compila sin avisos de código. Ninguna prueba cubre
  `Adapters`.

**Preguntas (209):**
1. 2.14.2: renombrar la familia `Store` del servidor (recomendado: `Repository`, en un commit aparte, también `Room`).
2. `UpdateMatch`: nombre y `int` sin uso (recomendado: `UpdateMatchAndRoom`, y mantener el `int` que pide el runner).
3. `Add` + `SaveChanges` repetido (recomendado: dejarlo).

**Decisiones del usuario (209): A en las tres.**
- `UpdateMatch` → `UpdateMatchAndRoom`; el `int` se queda. `Add` + `SaveChanges` se queda en cada método.
  Commit `49b5d37`, sin push.
- **R-35** (2.14.2): renombre en un commit aparte, `c229563`, sin push:
  - las familias `Match` y `Room` pasan de `Store` a `Repository` (interfaz, clase, excepción y falso);
  - cambian también los campos `_matchStore`/`_roomStore`, los mensajes de las excepciones y de bitácora de `Host`
    y el `<exception>` de `IMatchChatService`;
  - en las pruebas, `StoreFailureMessage` → `RepositoryFailureMessage`, y cuatro nombres `…StoreFails…`/`…InStore…`
    pasan a `Repository`.
  - Son 36 archivos (ocho con `git mv`). Git ve las dos excepciones como alta y baja porque se parecen solo un 40%.
  - Compila sin avisos de código, pasan 158 + 220 + 136 pruebas, y la foto de las lecturas sigue idéntica con el nombre
    nuevo.
- **Quedan para la revisión de las pruebas:** las propiedades `AccountStore`, `BannedWordStore` y `SanctionStore` del
  falso de la unidad de trabajo, y su método `Store(…)`.
- **Observación:** `MatchRepository` y `RoomRepository` siguen en `Persistence/`, no en `Persistence/Repositories/`
  con los de la unidad de trabajo. Lo único que se decidió fue el nombre.

### 210. `RoomRepository` (antes `RoomStore`) (2026-11-10)

Como `MatchRepository`, abre un contexto por operación. `CloseOpenRooms` solo se usa al arrancar el servidor
(`RoomBackgroundService.CloseRoomsLeftOpen`).
- **Pasada 1:**
  - **Sin hallazgos:** §1, §2 (con R-35 ya aplicada), §3, §6 y §8.
  - **§9:** `using` en el contexto y en la transacción de `AddRoomMatch` (9.5.1), traducción con la excepción interna
    (9.2.1) y `ThrowIfNull` en los públicos (9.4.1).
  - **§10:** correcta.
  - **No aplican:** §7, §11 y §12.
  - **5.1.2 (incumplimiento, corregido):** `ChangeRoomSettings` y `CloseRoom` escribían `room => …` dentro de
    `context => UpdateRoom(…)`. Ahora la acción va antes, en `Action<Room> changeSettings` / `closeRoom`. Partirlo en
    métodos privados no servía: tendrían cuatro parámetros (2.2.2).
  - **5.1.1 y 5.1.2 (incumplimiento, corregido):** `CloseOpenRoomsInContext` tenía una lambda de tres líneas con dos
    lambdas adentro. Ahora usa `ExecuteUpdate(setters => SetClosed(setters, closedAt))`, y cada `SetProperty` va en su
    línea dentro de un método aparte. Es distinto del campo `Expression` de la R-33, porque esa forma dejaba una línea de
    unos 130 caracteres; se pregunta.
  - **R-32/R-33:** los dos `Any(a && b)` pasan a consulta con nombre, un `.Where` por condición y `Any()`.
- **Pasada 2:**
  - `room.Code == code` se repetía en dos consultas; ahora es `SelectRoomsWithCode` (aplicado, 4.4.1).
  - `RunInNewContext` es idéntico al de `MatchRepository` salvo el tipo de excepción (se pregunta).
  - El `ExecuteUpdate` de `CloseOpenRooms` copia en SQL lo que hace `Room.Close` (`Closed` y `LastActivityAt`)
    (se pregunta).
- **Pasada 3:**
  - `UpdateRoom` solo aplica el cambio si la sala está abierta.
  - `AddRoomMatch` agrega la partida y además pasa la sala a `InMatch`, como `UpdateMatchAndRoom`.
  - Los privados están en otro orden que los públicos (se pregunta).
- **Pasada 4:** los siete métodos se usan. El `int` de `UpdateRoom` se queda, como el de `UpdateMatchAndRoom` (209, P2).
- **Verificación:**
  - Se usó una foto con un interceptor que bloquea toda escritura y solo imprime su SQL.
  - La base solo tiene dos salas, las dos cerradas, así que la foto incluye el SQL de cada lectura.
  - Antes y después salen 22 líneas idénticas: `EXISTS` con `Code` y `Status`, `TOP(1)` por `RoomId`, y el `UPDATE … SET
    Status, LastActivityAt WHERE Status = 'OPEN'`, que se bloqueó.
  - `CloseRoom` y `ChangeRoomSettings` se llamaron sobre salas cerradas y una inexistente, y no escribieron.
  - Compila sin avisos de código.

**Preguntas (210):**
1. `RunInNewContext` repetido (recomendado: clase base genérica `ContextPerOperationRepository<TFailure>`).
2. Carpeta (recomendado: mover los dos a `Persistence/Repositories/`).
3. Nombres y orden de los privados (recomendado: `UpdateOpenRoom`, `AddMatchAndStartRoom` y el orden de los públicos).
4. `CloseOpenRooms` (recomendado: cargar las salas abiertas y llamar a `Room.Close` en cada una).

**Decisiones del usuario (210): P2 A, P3 A y P4 A.** Aplicadas, sin commit todavía:
- `MatchRepository` y `RoomRepository` se movieron con `git mv` a `Persistence/Repositories/`, con el espacio de nombres
  `…Persistence.Repositories`. `AdaptersRegistration` tiene el `using` nuevo.
- `UpdateRoom` → `UpdateOpenRoom` y `AddRoomMatch` → `AddMatchAndStartRoom`. Los privados siguen el orden de los
  públicos.
- `CloseOpenRoomsInContext` carga las salas abiertas, llama a `Room.Close` en cada una y devuelve `SaveChanges()`. Se
  quitaron `SetClosed` y el `using …Query`.
- **Verificación:** la foto de `MatchRepository` sigue idéntica. La de `RoomRepository` cambia solo en `CloseOpenRooms`:
  antes era el `UPDATE` (bloqueado) y ahora es el `SELECT … WHERE Status = 'OPEN'`. El resultado sigue en 0. Como no hay
  salas abiertas, el camino de escritura no se pudo probar sin escribir. Compila sin avisos de código.

**P1, pendiente:** el usuario preguntó si en lugar de la clase base se puede hacer una **clase auxiliar** que maneje las
excepciones en un solo lugar. Sí se puede, por composición:
- `NewContextRunner<TFailure> where TFailure : Exception`, en `Persistence/`, recibe `IDbContextFactory` y
  `Func<Exception, TFailure>`;
- su `Run<TResult>(operation)` tiene el único `try`/`catch` de `DbUpdateException` y `DbException`;
- cada repositorio guarda un campo `_newContextRunner` y lo crea en su constructor con
  `innerException => new MatchRepositoryException(innerException)`. Lo permite la excepción de la 10.2.1: crea una parte
  que comparte su tiempo de vida.

Se recomendó sobre la clase base: el mismo código queda en un solo lugar, sin herencia, y con un poco menos en cada
repositorio. Falta la respuesta del usuario.

El usuario pidió **más propuestas**, cada una con su técnica, pros, contras y razonamiento. Datos que se usaron:
- Las dos excepciones se atrapan en 10 lugares (1 en `Application`, 9 en `Host`). Solo `RoomService` atrapa las dos, y
  las convierte en el mismo `FaultException`; lo único que cambia es el texto de la bitácora.
- `IRoomMatchService` documenta las dos con significados distintos.
- Hay 13 `catch (DbException|DbUpdateException)` en `Host`/`Application`, porque `UnitOfWork.SaveChanges` no traduce
  (archivo 211). Ese archivo necesita la misma traducción, pero no un contexto nuevo por operación.

Las propuestas:
- **D.** Separar un `DatabaseFailureTranslator<TFailure>` (solo el `try`/`catch`, SRP), que `NewContextRunner` usa y que
  `UnitOfWork` podría usar en 211. **Recomendada.**
- **E.** Unir las dos excepciones en una sola y usar un ejecutor no genérico inyectado por interfaz. Cambia el contrato
  en `Application` y `Host`; conviene decidirlo con la 211.
- **F.** Un proxy dinámico (`DispatchProxy`, AOP). **G.** Interceptores de EF. **H.** Esperar a la regla de tres.
- **Descartadas:** un `catch (Exception) when` (la 9.3.1 lo prohíbe), un tipo `Result` (va contra la §9) y juntar los dos
  repositorios en una clase.

**Decisión del usuario: P1 → D (R-36).** Commit `7c50e46`, sin push, que también lleva P2, P3 y P4:
- Hay dos clases nuevas en `Persistence/`:
  - `DatabaseFailureTranslator<TFailure>`, con el único `try`/`catch` de `DbUpdateException`/`DbException`;
  - `NewContextRunner<TFailure>`, que abre el contexto y lo usa.
- Los dos repositorios guardan `_newContextRunner` y ya no tienen `_contextFactory`, `RunInNewContext` ni
  `using System.Data.Common`.
- **Verificación:** las fotos de `MatchRepository` (48 líneas) y de `RoomRepository` (frente a P4) siguen idénticas.
  Compila sin avisos de código y pasan 158 + 220 + 136 pruebas.

**Hallazgo nuevo (de la prueba de falla, se pregunta):**
- Contra una base que no existe, los dos repositorios dejan salir una `InvalidOperationException` que envuelve la
  `SqlException` ("likely due to a transient failure… EnableRetryOnFailure").
- La estrategia de ejecución de SQL Server envuelve así los errores transitorios cuando no hay reintentos, y la
  aplicación usa `UseSqlServer` sin `EnableRetryOnFailure`.
- Ese tipo no es `DbUpdateException` ni `DbException`, así que no se traduce y no lo atrapa ningún
  `catch (…RepositoryException)`.
- Es anterior a la D, porque los `catch` eran los mismos. La D deja un solo lugar donde corregirlo.

Se probaron estrategias de EF contra fallas reales, sin tocar la base:

| Falla | Por defecto | `NonRetryingExecutionStrategy` | `EnableRetryOnFailure(2, 1 s)` |
| --- | --- | --- | --- |
| Base que no existe (transitoria) | `InvalidOperationException` ← `SqlException` (se escapa) | `MatchRepositoryException` ← `SqlException` | `RetryLimitExceededException` (hereda de `Exception`, se escapa) |
| Puerto cerrado (no transitoria) | `MatchRepositoryException` | `MatchRepositoryException` | — |

**Consecuencias de que se escape:**
- `RankedMatchCreator` solo atrapa `MatchRepositoryException`. `MatchmakingDispatcher` no atrapa nada, y
  `MatchmakingBackgroundService.ExecuteAsync` tampoco. En .NET, una excepción en un `BackgroundService` detiene el host
  por defecto, y no hay `HostOptions` configuradas: **se cae el servidor**.
- `Host` no tiene `IErrorHandler`. En un servicio WCF, la excepción llega a CoreWCF como falla genérica, y en un canal
  con sesión el canal queda en `Faulted`.

Propuestas que se dieron al usuario:
- **A.** Un `catch` con filtro en el traductor.
- **B.** Reintentos de EF.
- **C.** Dejarlo pendiente.
- **D.** `NonRetryingExecutionStrategy` en `AdaptersRegistration`: corrige la causa en la raíz de composición y ya cubre
  también `UnitOfWork` y los 13 `catch (DbException|DbUpdateException)` de `Host`. **Recomendada.**
- **E.** Reintentos limitados más `RetryLimitExceededException`.
- **F.** Desenvolver la cadena en el traductor.
- **G.** `IErrorHandler` como escudo de excepciones en `Host`, complementaria.
- **H.** Comprobar la conexión al arrancar (fail fast), complementaria.
- **Descartadas:** atrapar en cada servicio de `Host`, `BackgroundServiceExceptionBehavior.Ignore` y agregar Polly.

**Decisión del usuario: D (R-37).** Commit `63ab7f3`, sin push:
- `AdaptersRegistration` llama `UseSqlServer(connectionString, UseNonRetryingStrategy)`.
- El método privado configura `ExecutionStrategy(dependencies => new NonRetryingExecutionStrategy(dependencies))`.
  Es un método aparte para no anidar lambdas (5.1.2) y lleva un `//` en inglés con el porqué (8.1.1).
- **Verificación con el registro real** (`AddBastionAdapters` y el contenedor):
  - con la base local, los dos repositorios y la unidad de trabajo leen igual;
  - con una base inexistente salen `MatchRepositoryException` ← `SqlException`, `RoomRepositoryException` ←
    `SqlException`, y la unidad de trabajo deja la `SqlException`, que atrapan los `catch (DbException)` de `Host`;
  - con la estrategia anterior, la unidad de trabajo dejaba salir `InvalidOperationException`.
  - Compila sin avisos de código y pasan 158 + 220 + 136 pruebas.
- **Para la revisión de `Host`:** la G (`IErrorHandler`) y la H (comprobar la conexión al arrancar) quedan como
  complementarias.

### 211. `UnitOfWork` (2026-11-10)

- **Pasada 1:**
  - **Sin hallazgos:** §1, §2, §3, §4, §6 (campo, constructor, propiedades y método en orden) y §8.
  - **No aplican:** §5 (no hay lambdas ni LINQ) y §7 (`IUnitOfWork` no es `I…Service`).
  - **9.4.1:** el constructor comprueba `context`.
  - **9.5.1:** no es dueña del contexto; lo crea el contenedor, que lo libera al cerrar el ámbito.
  - **10.2.1:** crea sus ocho repositorios sobre el mismo contexto, que es justo el ejemplo de la excepción de la regla.
- **Pasada 2:** no hay repetición en el archivo.
- **Pasada 3:** los nombres son claros.
- **Pasada 4:** se usan las ocho propiedades (`Accounts` 6, `Sessions` 2, `AccessLogs` 1, `Friendships` 11,
  `FriendRequests` 9, `Sanctions` 1, `BannedWords` 1, `Messages` 6) y `SaveChanges` (5).
- **El pendiente (traducción):** `SaveChanges` no traduce, pero tampoco las lecturas de sus repositorios: las 37
  llamadas de lectura también dejan salir `DbException`.
  - Traducir solo `SaveChanges` no evitaría que `Host` siga atrapando `DbException`.
  - `Host` atrapa `DbUpdateException` y `DbException` en 13 lugares de nueve servicios, y todos los convierten en el mismo
    `FaultException(ServerFailureReason)`. Solo cambia el texto de la bitácora ("could not be saved" o "could not be
    reached").
  - Ninguna clase de `Application` reacciona a una falla de la unidad de trabajo. En cambio, `RankedMatchCreator` sí
    reacciona a `MatchRepositoryException`.

**Preguntas (211):**
1. Cómo traducir (recomendado: no traducir en la unidad de trabajo; el borde, `Host`, maneja los errores de la base;
   anotarlo como regla). Alternativas:
   - traducir solo `SaveChanges`;
   - traducir todo (lecturas y guardado) con una excepción de `Application`;
   - sobrescribir `SaveChanges` del contexto;
   - interceptores de EF.
2. Si se elige no traducir, ¿`DatabaseFailureTranslator` queda aparte o vuelve a `NewContextRunner`? (recomendado:
   aparte).

**Decisiones del usuario (211): A en las dos.**
- **R-38.** La unidad de trabajo no traduce: `Host` maneja `DbException`/`DbUpdateException`.
- `DatabaseFailureTranslator` sigue como clase aparte, aunque hoy tenga un solo usuario.
- **Sin cambios de código ni commit.**
- **Para la revisión de `Host`:** los 13 pares de `catch` repetidos en nueve servicios (posible `IErrorHandler`, la G del
  hallazgo de la R-37).

### 212. `RoomCodeGenerator` (2026-11-10)

`return RandomNumberGenerator.GetString(RoomPolicy.CodeAlphabet, RoomPolicy.CodeLength);`: es una sola llamada con
argumentos simples. El azar va detrás de una interfaz inyectada (10.1.1), y lo usa `RoomRegistry`. Cumple las cuatro
pasadas. **Sin cambios.**

### 213 y 214. `PasswordHasher` y `SessionTokenGenerator` (2026-11-10)

- **R-04 (incumplimiento, corregido):**
  - `PasswordHasher.DeriveHash` pasaba `Encoding.UTF8.GetBytes(password)` dentro del `return`; ahora va antes, en
    `passwordBytes`.
  - `SessionTokenGenerator.Hash` hacía `return SHA256.HashData(Encoding.UTF8.GetBytes(token));`; ahora usa `tokenBytes`.
- **R-14 (incumplimiento, corregido):** `return new GeneratedToken(token, Hash(token));` → `tokenHash` antes.
- **4.4.2:** `PasswordHasher.HashLength`/`SaltLength` y `SessionTokenGenerator.TokenHashLength` son públicas porque las
  usan las configuraciones de EF para el largo de las columnas. Es la única definición. La R-25 no aplica.
- **2.2.3:** `Verify` ya quedó como excepción en el archivo 176.
- **Seguridad, sin hallazgos:**
  - PBKDF2-SHA512 con 210 000 iteraciones;
  - `FixedTimeEquals`;
  - sal y hash señuelo para que una cuenta sin contraseña tarde lo mismo;
  - token de 32 bytes aleatorios, guardado como SHA-256.
- **Pasada 3 (se pregunta):** `SessionTokenGenerator.TokenLength = 32` son bytes aleatorios. El token, en Base64, mide
  44 caracteres. El nombre hace pensar en el largo del texto.
- **4.2.1 frente a la seguridad (se pregunta):** `Verify` no sale antes cuando falta la contraseña guardada, a propósito,
  para no revelar por el tiempo de respuesta si la cuenta tiene contraseña. No hay nada que lo explique, y alguien podría
  "corregirlo" con una guarda.
- **Verificación con datos sintéticos** (ninguna contraseña real): 12 líneas idénticas antes y después. Cubre `Verify`
  correcta, incorrecta, vacía, sin hash, sin sal y con acentos, el hash de dos tokens conocidos, y el largo y la
  coincidencia del token generado. Compila sin avisos de código y pasan 158 + 220 + 136 pruebas.

**Preguntas (213 y 214):**
1. `Verify` sin guarda (recomendado: un `//` en inglés que explique el porqué, 8.1.1).
2. `TokenLength` (recomendado: `TokenByteCount`).

**Respuesta del usuario:** P2 A, aplicada (`TokenByteCount`). Para P1 eligió la A, pero pidió **evitar a toda costa los
comentarios** y quiere propuestas que se lean mejor sin ellos. Queda como regla **R-39**. Lo mismo aplica al `//` que se
agregó en `AdaptersRegistration` (R-37, commit `63ab7f3`), que es el único comentario escrito a mano en el código. El
encabezado de `Strings.Designer.cs` lo genera la herramienta de recursos.

Propuestas sin comentario para `Verify`:
- **A.** Nombres que revelan la intención (renombrar los señuelos).
- **B.** Extraer `IsMatchInConstantTime(...)`, con variables explicativas. **Recomendada.**
- **C.** Un objeto de caso especial (`StoredPassword.Missing`).
- **D.** Poner la garantía en el contrato: `IPasswordHasher.VerifyInConstantTime`.
- **E.** Una prueba como documentación. No es viable: la prueba de tiempo sería inestable y no hay proyecto de pruebas
  de `Adapters`.

Para `AdaptersRegistration`: renombrar `UseNonRetryingStrategy` → `KeepTransientErrorsAsDbException` y quitar el `//`.

**Respuesta del usuario:** la B vale para los dos, pero los nombres siguen siendo ambiguos, también `Verify`. Pidió nombres
más claros.

**Dato nuevo:** cuando la cuenta no existe, `LoginService` llama `_passwordHasher.Verify(password, null, null)` y
descarta el resultado. Solo sirve para que la respuesta tarde lo mismo y no se pueda averiguar qué cuentas existen. La
prueba `LogIn_UnknownIdentifier_StillChecksAPassword` lo comprueba con `FakePasswordHasher.VerifyCount`.

**Propuestas:**
- `Verify` → `IsPasswordCorrect(enteredPassword, storedHash, storedSalt)`. Cumple la 2.2.3, así que se quita la
  excepción del archivo 176.
- Un método nuevo en el puerto, `SimulatePasswordCheck(enteredPassword)`, para la llamada de `LoginService`.
- El ayudante pasa a `IsHashEqualWithoutTimingLeak`, y los señuelos a `_saltWhenNoPasswordStored` /
  `_hashWhenNoPasswordStored`.
- El método del registro pasa a `KeepDatabaseErrorsAsDbException`. Se descarta `DisableRetriesAndErrorWrapping`, porque
  la estrategia por defecto tampoco reintentaba.
- Archivos que toca: `IPasswordHasher`, `LoginService`, `PasswordHasher`, `AdaptersRegistration`, `FakePasswordHasher` y
  `TestLoginService`.

**Decisión del usuario: aplicar los cuatro nombres.**
- **Commit `0f27c74`** (213 y 214, con el puerto y el inicio de sesión):
  - `IPasswordHasher.IsPasswordCorrect(enteredPassword, storedHash, storedSalt)` y `SimulatePasswordCheck(enteredPassword)`.
  - `LoginService` llama `SimulatePasswordCheck(password)` cuando la cuenta no existe.
  - En `PasswordHasher`: `IsHashEqualWithoutTimingLeak`, `_saltWhenNoPasswordStored`/`_hashWhenNoPasswordStored` y las
    variables `isHashEqual`, `hasStoredPassword`, `isPasswordEntered`, `enteredHash`.
  - En `SessionTokenGenerator`: `TokenByteCount` y las variables de la R-04 y la R-14.
  - En las pruebas, `FakePasswordHasher.SimulatedCheckCount` y `LogIn_UnknownIdentifier_SimulatesAPasswordCheck`.
  - Con `IsPasswordCorrect`, **la excepción de la 2.2.3 del archivo 176 ya no hace falta**.
- **Commit `2efd55e`:** `AdaptersRegistration.KeepDatabaseErrorsAsDbException`, sin el `//`. En el código ya no queda
  ningún comentario escrito a mano (R-39).
- **Verificación:**
  - Las 12 líneas de la foto de seguridad siguen idénticas.
  - La comprobación real tarda 102 ms y la simulada 98 ms.
  - El registro real sigue traduciendo con una base inexistente.
  - Compila sin avisos de código y pasan 158 + 220 + 136 pruebas.

**Capa `Bastion.Server.Adapters` terminada** (archivos 183 a 214). No tiene servicios, así que la R-27 no activa nada.
Sigue `Bastion.Server.Host`. Pendientes anotados para esa capa:
- los 13 pares `catch (DbUpdateException)` / `catch (DbException)` repetidos en nueve servicios;
- la G (`IErrorHandler`) y la H (comprobar la conexión al arrancar) de la R-37.
