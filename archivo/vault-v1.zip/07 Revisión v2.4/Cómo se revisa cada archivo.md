---
tags: [revision-v2-4]
---
# Cómo se revisa cada archivo
Volver a [[Índice de la revisión v2.4]]

Cuatro pasadas, siempre en este orden:

1. **Reglas del estándar**, en etapas; cada etapa es una sección completa del estándar y se comprueba regla por
   regla (91 reglas en total):
   - §1 Idioma: 1.3.1.
   - §2 Nombrado: 2.1 variables, 2.2 métodos, 2.3 constantes, 2.4 clases, 2.5 interfaces, 2.6 campos privados,
     2.7 descartes, 2.8 class/struct/record, 2.9 identidad, 2.10 literales, 2.11 propiedades, 2.12 eventos,
     2.13 genéricos, 2.14 sufijos, 2.15 enumeraciones (33 reglas).
   - §3 Estilo: 3.1 indentación, 3.2 espaciado, 3.3 llaves Allman, 3.4 `var`, 3.5 división de líneas,
     3.6 atributos, 3.7 controles de Gum (7 reglas).
   - §4 Complejidad: anidamiento, guardas, llaves, `switch`/`default`, DRY, `?:`, complejidad ciclomática, patrón
     `is` (9 reglas).
   - §5 Funcional: lambdas de una línea, contextos prohibidos de lambda, grupo de método, LINQ a objetos (4 reglas).
   - §6 Estructura de archivos: un tipo por archivo, orden de miembros, `using`, espacio de nombres (4 reglas).
   - §7 Documentación XML (5 reglas). §8 Comentarios (5 reglas). §9 Excepciones (12 reglas).
     §10 Inyección (4 reglas). §11 Bitácoras (3 reglas). §12 Pruebas (4 reglas).
   - Una sección que no aplica al archivo se anota como «no aplica» con el porqué.
2. **Repetición**: datos o lógica repetidos dentro del archivo o con archivos ya revisados. Si conviene moverlos a
   una clase reutilizable, se anota en «Candidatos a reutilizar» y se pregunta.
3. **Nombres ambiguos para alguien ajeno a la aplicación**: tipo, miembros, parámetros y variables. Un nombre es
   ambiguo si al leerlo sin el contexto de la clase no se sabe qué es o qué hace, o si se confunde con otro.
4. **Necesidad**: cada miembro debe usarse en algún lugar de la solución. Lo que no se usa se reporta con la
   búsqueda que lo comprueba.
