---
tags: [revision-v2-4]
---
# Bitácora 5 - Bastion.Contracts
Volver a [[Índice de la revisión v2.4]]

Son 61 archivos (240 a 300), en orden de carpeta: `Accounts`, `Chat`, `Friends`, `Matches`, `Matchmaking`,
`Notifications`, `PrivateChat`, `Rooms`, `ServiceEndpoints` y `Sessions`. Datos generales:
- **Marco:** `netstandard2.0`, con `LangVersion latest` y `Nullable` de `Directory.Build.props`. No hay
  `ArgumentNullException.ThrowIfNull`, pero los contratos no tienen métodos con cuerpo.
- **Clases de datos:** los `[DataContract]` son objetos de transferencia: la 2.11.3 (get y set públicos) y la R-03 no
  piden constructor.
- **R-27 al cerrar la capa:** con `GenerateDocumentationFile` activo en la copia aparte, solo faltan
  `IFriendshipService` (9 errores CS1591) e `IConversationService` (5). Los `cref` de `IAccountService` resuelven.
- **Para preguntar en su carpeta:** tres `<summary>` dicen "signed-in player" (`IMatchService`, `IMatchmakingService`
  e `ISessionService`). La R-41 fija "login" en los textos del programa, pero no menciona la documentación XML.

### 240 a 246. `Accounts` (2026-11-11)

- **Cumple:**
  - 1.3.1, 2.4.1, 2.11.1 y 2.11.3 (objetos de transferencia con get y set públicos);
  - 2.15.1 (`RestrictionReason` en singular), 3.6.1 (un atributo por línea), 6.1, 6.3 y 6.4.
  - §8 y §9 no aplican: no hay comentarios ni cuerpos de método.
- **Pasada 3:**
  - `RestrictionReason.Pending` usa el mismo término que `AccountStatus.Pending` del dominio y que `ILoginService`.
  - `LockMinutes` es el nombre de `AccountRestrictedException` en `Application` y en `Client.Networking`.
  - `Identifier` es el nombre de `LoginViewModel` y de `ILoginService` ("nickname or email").
  - Se quedan.
- **Pasada 4:** cada propiedad tiene uso.
  - `LockMinutes` lo usa `LoginViewModel`, y `PreferredLanguage` lo usa `ApplyPreferredLanguage`.
  - `DeviceFingerprint` y `ClientVersion` los usa `LoginTranslator.ToConnection`.
  - `AccountClient.ToRestriction` traduce los cuatro valores de `RestrictionReason`.
- **7.1.1 (R-27), aplicado:** `IAccountService` no tenía documentación. Ahora lleva:
  - el `<summary>` del servicio: "Logs registered players in and opens their session.";
  - el `<summary>` de `LogIn`, con el registro en la bitácora de accesos;
  - los dos `<param>` y el `<returns>`;
  - tres `<exception>`, con el mismo texto que `ILoginService`: `InvalidCredentialsFault` (también por credenciales o
    dispositivo faltantes), `AccountRestrictedFault` y la `FaultException` del servidor.
- **Pregunta 1 (9.4.1, pasada 2):** `LogIn(PlayerCredentials credentials, ClientDevice device)` es la única operación con
  argumentos de red sin `?`. `AccountService` los compara con `null` (R-40), y los demás contratos los declaran
  anulables (`RoomOptions? options`, `string? sessionToken`).
- **Pregunta 2 (R-44, pasada 2):** `AccountService` se revisó en 215–217, antes de que existiera la R-44. Es el único
  servicio que todavía tiene el `try` dentro de la operación y la hora como argumento.
- **Propuesta en la copia aparte** (`Host` compila sin avisos de código):
  - **Pregunta 1:** `PlayerCredentials? credentials, ClientDevice? device` en el contrato y en `AccountService`.
  - **Pregunta 2:**
    - `DateTime now` y `string password` van cada uno en su variable;
    - `Func<PlayerSession> logIn = () => LogInInRequestScope(attempt, password);`;
    - `return TranslateLoginFailures(nameof(LogIn), connection.IpAddress, logIn);`, con la IP como contexto, como el
      `MatchId` de `MatchService`.
    - Las guardas de credenciales y dispositivo, `ToConnection` y `ToAttempt` siguen fuera del `try`, como hoy.
- **Sonda (`accounts-probe`):** compara `HEAD` con la propuesta en 10 casos: éxito, contraseña nula, credenciales nulas,
  dispositivo nulo, credenciales inválidas, cuenta bloqueada (15 min) y vetada, login sin guardar, base caída y error de
  programación.
  - Son iguales la respuesta, la falla y su detalle, y el intento que recibe `ILoginService` (identificador recortado,
    IP, dispositivo, hora y largo de la contraseña).
  - Solo cambian los dos textos Error, que ahora llevan `Operation=LogIn;` antes de `IpAddress=`.

**Preguntas (240 a 246):**
1. Argumentos anulables en `LogIn` (recomendado: sí).
2. La R-44 en `AccountService`, con `Operation=LogIn; IpAddress=…` (recomendado: sí).

**Respuesta del usuario (2026-11-11):** «Sí, A en las dos». Se aplicó la propuesta sin cambios (`IAccountService` y
`AccountService`).
- **Verificación:**
  - `Host` y `Client.Networking` compilan sin avisos de código en una compilación completa (solo NU1902/NU1903);
  - pasan 514 pruebas.

**Commit de `Accounts`:** `2a59451` (2026-11-11), en `review-standard-v2.4-host`, sin push.

### 247 a 253. `Chat` (2026-11-11)

Los archivos son `ChatChannelForbiddenFault`, `ChatMessageReceipt`, `ChatMessageRejectedFault`, `ChatRejectionReason`,
`IChatService`, `LobbyChatLog` y `LobbyChatMessage`.
- **Cumple:**
  - 1.3.1, 2.4.1, 2.11.1 y 2.11.3, 2.15.1, 3.6.1 y §6;
  - §8 y §9 no aplican.
- **`IChatService` (7.1–7.2, R-27):** ya estaba documentado. Se comparó cada `<exception>` con lo que hace `ChatService`, y
  todo coincide:
  - `SendChatMessage` y `OpenLobbyChat` solo leen la base: las sanciones y las palabras vetadas. El chat general guarda
    los mensajes en memoria (`LobbyChatRoom`), así que basta "could not reach the database".
  - `SendMatchChatMessage` guarda por `MatchRepository`, que traduce a `MatchRepositoryException` (R-36), así que
    "could not read or write the database" también es correcto.
  - `ChatChannelForbiddenFault` sale cuando el autor no tiene una participación sin terminar en la partida
    (`FindAccountIdsWithUnfinishedParticipation`).
- **Pasada 3:**
  - `LobbyChatLog` se queda. "Chat log" es el historial de mensajes, en inglés común, y cada capa tiene su propio
    nombre (`LobbyChatHistory` en `Application`, `LobbyChatTranscript` en el cliente), así que los traductores no tienen
    dos tipos con el mismo nombre.
  - **Pregunta 2:** `LobbyChatLog.ConnectedPlayers` es un `int`, pero el nombre en plural se lee como una lista
    (2.1.2). El proyecto llama `…Count` a los conteos (`GameMode.PlayerCount`, `closedRoomCount`). El nombre viaja por
    toda la cadena:
    - `LobbyChatHistory` y `LobbyChatService` en `Application`;
    - `ChatTranslator` en `Host`;
    - `LobbyChatTranscript` y `ChatContractTranslator` en `Client.Networking`;
    - `LobbyChatViewModel`;
    - dos pruebas.
- **Pasada 4:**
  - `IsMuted` y `MutedUntil` hacen falta los dos: una sanción permanente da `IsMuted = true` con `MutedUntil = null`
    (`ChatMute.FromSanctionsInEffect`).
  - **Pregunta 1:** el cliente no lee ningún `MessageId`. Hay 6 contratos con ese campo:
    - `ChatMessageReceipt` y `LobbyChatMessage`;
    - `ChatMessageNotification`, `MatchChatMessageNotification` y `PrivateMessageNotification`;
    - `PrivateChatMessage`.
  - De los recibos, el cliente solo usa `SentAt` (`ChatClient`, `ConversationClient`).
  - La CU-27 no lo necesita: el reporte apunta a la partida o a la sala, no a un mensaje (RN-01).
  - Quitarlo arrastra a `Application`: `LobbyChatRoom` numera los mensajes solo para el contrato, y lo prueba
    `TestLobbyChatRoom`.

**Preguntas (247 a 253):**
1. `MessageId` sin lectura en el cliente (recomendado: A, se queda en los 6 contratos como identidad del mensaje en la
   red y queda como regla, para no volver a preguntarlo en `Notifications` y `PrivateChat`; B, quitarlo de los 6, con su
   arrastre en los traductores y en `LobbyChatRoom`).
2. `ConnectedPlayers` → `ConnectedPlayerCount` (recomendado: A, en toda la cadena, con la variable `connectedPlayerCount`
   y la constante de la prueba; B, solo en el contrato; C, dejarlo). Es un renombre: se verifica con la compilación
   completa y las pruebas al aplicarlo.

**Respuesta del usuario (2026-11-11):** «Sí, A en las dos».
- **Pregunta 1:** queda como regla R-57, sin cambios en el código.
- **Pregunta 2:** `ConnectedPlayerCount` en 9 archivos:
  - `LobbyChatLog`, `LobbyChatHistory` (con el parámetro `connectedPlayerCount`) y `LobbyChatService`;
  - `ChatTranslator`;
  - `LobbyChatTranscript`, `ChatContractTranslator` y `LobbyChatViewModel`;
  - `TestChatContractTranslator` (con la constante) y `TestLobbyChatService`.
- **Verificación:**
  - `Host` y `Client` compilan sin avisos de código en una compilación completa (solo NU1902/NU1903);
  - pasan 514 pruebas;
  - la copia aparte recibió los cuatro archivos del servidor.

**Commit de `Chat`:** `1326770` (2026-11-11), en `review-standard-v2.4-host`, sin push.

### 254 a 264. `Friends` (2026-11-11)

Los archivos son:
- `FriendList`, `FriendListEntry`, `FriendRequestEntry` y `FriendRequestList`;
- `FriendRequestResult`, `FriendshipRejectedFault` y `FriendshipRejectionReason`;
- `IFriendshipService`, `PlayerRelationship`, `PlayerSearchEntry` y `PresenceState`.

Revisión:
- **Cumple:**
  - 1.3.1, 2.4.1, 2.11.1 y 2.11.3, 2.15.1 (las cuatro enumeraciones en singular), 3.6.1 y §6;
  - §8 y §9 no aplican.
- **Pasada 3:** los nombres se leen solos y siguen el vocabulario de `Application`:
  - `OwnFriendCode`, `ListedAt`, `LastSeenAt`, `RequestedAt` y `ExpiresAt`;
  - `PlayerRelationship.Self` y `FriendshipRejectionReason.OwnAccount`;
  - en las operaciones, `requesterFriendCode` y `recipientFriendCode`.
- **Pasada 4:** cada propiedad y cada valor tiene uso.
  - `FriendContractTranslator` traduce los 8 rechazos, las 5 relaciones, los 2 resultados y las 2 presencias.
  - `ListedAt` lo usan `FriendRowViewModel` y `FriendRequestRowViewModel` para los textos relativos.
- **7.1.1 (R-27), aplicado en la copia aparte:** `IFriendshipService` no tenía documentación. Ahora lleva el `<summary>`
  del servicio y los de sus ocho operaciones, con `<param>`, `<returns>` y `<exception>`.
  - El texto sigue el de `IFriendListService` e `IFriendRequestService`.
  - Agrega lo que pasa en `Host`: un código faltante llega como el rechazo de cada operación (`PlayerNotFound`,
    `RequestNotFound` o `NotFriends`), y una búsqueda sin texto no da resultados.
  - Las notificaciones: la solicitud y la amistad llegan al otro jugador.
  - Las operaciones que solo leen dicen "could not reach the database", y las que guardan, "could not read or write
    the database", como en `IChatService`. `FriendshipService` atrapa `DbUpdateException` y `DbException`.
  - Compila con `GenerateDocumentationFile`: los errores CS1591 de `IFriendshipService` desaparecen. Solo quedan los
    5 de `IConversationService`.
- **Pregunta 1 (2.1.2, incumplimiento):** `FriendRequestList.Received` y `.Sent` son arreglos, pero sus nombres son
  participios, no sustantivos en plural.
  - Lo mismo pasa en `FriendRequestBoard` de `Application` (85–108, no se vio entonces) y en `FriendRequestListing` del
    cliente.
  - `FriendshipTranslator` ya llama `receivedRequests` y `sentRequests` a sus variables.
  - Los campos `_received` y `_sent` de `FriendRequestsViewModel` se ven al revisar `Client`.

**Pregunta (254 a 264):**
1. `Received`/`Sent` → `ReceivedRequests`/`SentRequests` (recomendado: A, en toda la cadena:
   - `FriendRequestBoard`, con sus parámetros;
   - `FriendshipTranslator`;
   - el contrato;
   - `FriendRequestListing` y `FriendContractTranslator`;
   - el uso en `FriendRequestsViewModel`;
   - tres pruebas.

   B, solo en el contrato; C, dejarlo.) Es un renombre: se verifica con la compilación completa y las pruebas al
   aplicarlo.

**Respuesta del usuario (2026-11-11):** «Sí, toda la cadena».
- **Aplicado:**
  - la documentación de `IFriendshipService`, desde la copia aparte;
  - `ReceivedRequests`/`SentRequests` en `FriendRequestBoard` (con los parámetros `receivedRequests`/`sentRequests`),
    en las variables de `FriendRequestService.ListFriendRequests`, en `FriendshipTranslator`, en el contrato, en
    `FriendRequestListing` y `FriendContractTranslator`, en `FriendRequestsViewModel` y en
    `TestFriendContractTranslator` y `TestFriendRequestService`.
- **Verificación:**
  - `Host` y `Client` compilan sin avisos de código en una compilación completa (solo NU1902/NU1903);
  - pasan 514 pruebas.

**Commit de `Friends`:** `43e62a0` (2026-11-11), en `review-standard-v2.4-host`, sin push.

### 265 y 266. `Matches` (2026-11-11)

- **`MatchNotJoinedFault` (266):** cumple. Lleva el mismo nombre que `MatchNotJoinedException` de `Application`, y lo usa
  `MatchClient`.
- **`IMatchService` (265):**
  - **Cumple:** 7.1.1, el orden de la 7.2.1 y 3.6.1.
  - **7.2 (corregido en la copia aparte), pendiente desde 223–224:** el `<summary>` de `AbandonMatch` decía "that player
    loses and the rival wins". Ahora sigue a `IMatchAbandonmentService`: con dos jugadores el rival gana y la partida
    termina; con cuatro, sigue mientras queden dos.
  - **7.2.2 (corregido en la copia aparte):** la `FaultException` decía "could not reach the database". `MatchService`
    también la lanza cuando falla `MatchRepository`, que lee y guarda la partida. Ahora dice "could not read or write the
    database", como las demás operaciones que guardan.
  - Compila con `GenerateDocumentationFile`.
  - **Pregunta 1 (R-41 en la documentación):**
    - la R-41 pide "login" y "log in" en la bitácora, en las excepciones y en las fallas, pero no menciona la
      documentación XML;
    - tres `<summary>` de servicio dicen "signed-in player": `IMatchService`, `IMatchmakingService` e `ISessionService`;
    - la copia aparte ya dice "logged-in player" en `IMatchService`.

**Pregunta (265 y 266):**
1. La R-41 también en la documentación XML (recomendado: A, "logged-in player" en los tres, cada uno al revisar su
   carpeta; B, dejar "signed-in", porque la documentación no es un texto que vea el jugador).

**Respuesta del usuario (2026-11-11):** «Sí, logged-in». La R-41 se amplía a la documentación XML.
- **Aplicado:** `IMatchService`, desde la copia aparte. Es un cambio solo de documentación; `Host` compila sin avisos de
  código.

**Commit de `Matches`:** `40e3763` (2026-11-11), en `review-standard-v2.4-host`, sin push.

### 267 a 269. `Matchmaking` (2026-11-11)

- **`SearchRejectedFault` y `SearchRejectionReason` (268 y 269):** cumplen. Repiten los tres valores de
  `SearchRejection` de `Application`, y `MatchmakingClient` traduce los tres.
- **`IMatchmakingService` (267):** sin preguntas. Se aplicaron reglas ya decididas y la nota pendiente desde 225–227:
  - **R-41:** "signed-in player" → "logged-in player" en el `<summary>` del servicio.
  - **7.2.2 (nota de 225–227):** la `FaultException` de `StartSearch` dice ahora "could not reach the database to check
    the session or the unfinished matches of the player". `MatchmakingService` la lanza por `DbException` y por
    `MatchRepositoryException`, y `StartSearch` solo lee.
  - **7.2:** `SearchRejectedFault` nombra sus tres casos, como `IChatService` e `IFriendshipService`: no tiene canal de
    notificaciones, tiene una partida sin terminar o está en una sala.
  - Las tres `<exception>` de `StartSearch` van en varias líneas, como en el resto del archivo y en `IChatService`.
  - `CancelSearch` y `ConfirmPresence` son de un solo sentido: no dejan salir excepciones (R-50), así que no llevan
    `<exception>`.
- **Verificación:** compila con `GenerateDocumentationFile` (solo quedan los 5 CS1591 de `IConversationService`), y
  `Contracts` compila en el repositorio. Solo cambió documentación.

**Commit de `Matchmaking`:** `3878797` (2026-11-11), en `review-standard-v2.4-host`, sin push.

### 270 a 286. `Notifications` (2026-11-11)

Son 17 archivos: `Notification` (la base abstracta con los 12 `[KnownType]`), las 12 notificaciones,
`MatchFoundParticipant`, `RoomClosedReason`, `SearchEndedReason` e `INotificationCallback`.
- **Cumple:**
  - 1.3.1, 2.4.1, 2.11.1 y 2.11.3, 2.14.1 (cada notificación termina en `Notification`, su clase base), 2.15.1,
    3.6.1 (un `[KnownType]` por línea) y §6;
  - §8 y §9 no aplican.
- **Pasada 3:**
  - `SearchEndedReason` se queda aunque `Application` y el cliente digan `SearchEndReason`. En `Contracts` las razones
    usan el participio (`RoomClosedReason`), y cada capa tiene su propio tipo (como `LobbyChatLog`).
  - `RoomClosedNotification.Code` se lee como el código de la sala: lo dice el nombre del tipo.
- **Pasada 4:**
  - `NotificationCallback` y los traductores del cliente leen cada propiedad. `MessageId` se queda por la R-57.
  - `RoomClosedReason` solo tiene `HostLeft`, pero `RoomContractTranslator.ToCloseReason` lo traduce.
- **Pregunta 1 (7.1.1):** `INotificationCallback` es un `[ServiceContract]`, el contrato de devolución que el cliente
  atiende, y no tiene documentación.
  - La R5 de la regla del proyecto admite `<summary>` en todo contrato `[ServiceContract]`, pero la glob de CS1591 solo
    cubre `I*Service.cs`.
  - Si se documenta, la clase del cliente que lo implementa (`NotificationCallback`) lleva `<inheritdoc/>` en la clase y
    en `ReceiveNotification` (7.1.2).
  - En la copia aparte, el `cref` a `Sessions.ISessionService.Subscribe` resuelve con `GenerateDocumentationFile`.

**Pregunta (270 a 286):**
1. Documentar `INotificationCallback`, con `<inheritdoc/>` en `NotificationCallback` (recomendado: A; B, dejarlo, porque
   la 7.1.1 dice "servicio" y la glob solo cubre `I*Service.cs`).

**Respuesta del usuario (2026-11-11):** «Sí, documéntalo».
- **Aplicado:**
  - `INotificationCallback`, desde la copia aparte;
  - `<inheritdoc/>` en `NotificationCallback`, sobre la clase y sobre `ReceiveNotification`.
- **Verificación:** `Client.Networking` compila sin avisos de código en una compilación completa (solo NU1902/NU1903) y
  pasan las 136 pruebas del cliente. Solo cambió documentación.

**Commit de `Notifications`:** `ac2a8b4` (2026-11-11), en `review-standard-v2.4-host`, sin push.

### 287 a 290. `PrivateChat` (2026-11-11)

Los archivos son `ConversationEntry`, `IConversationService`, `PrivateChatMessage` y `PrivateConversationLog`.
- **Cumple:**
  - 1.3.1, 2.4.1, 2.11.1 y 2.11.3, 3.6.1 y §6;
  - §8 y §9 no aplican.
- **Pasada 3:**
  - `PrivateConversationLog` se queda por la misma razón que `LobbyChatLog`;
  - `UnreadCount` sigue la forma `…Count`;
  - `ConversationEntry`, `ConversationSummary` y `ConversationPreview` son el mismo dato con un tipo por capa.
- **Pasada 4:** `ConversationContractTranslator` lee cada propiedad. `MessageId` se queda por la R-57.
- **7.1.1 (R-27), aplicado sin preguntas:** `IConversationService` no tenía documentación (nota de 228–229).
  - Ahora lleva el `<summary>` del servicio y los de sus cuatro operaciones, con `<param>`, `<returns>` y `<exception>`.
  - El texto sigue a `IPrivateChatService`, y le agrega:
    - el código faltante, que `ConversationService` rechaza con `PlayerNotFound`;
    - el aviso al destinatario;
    - "could not reach the database" en `ListConversations`, que solo lee;
    - "could not read or write the database" en las otras tres: `OpenConversation` y `MarkConversationRead` marcan los
      mensajes como leídos, y `SendPrivateMessage` guarda el mensaje.
  - Con esto, `Contracts` compila sin errores con `GenerateDocumentationFile` (ni CS1591 ni avisos IDE).
- **Verificación:** `Contracts` compila en el repositorio. Solo cambió documentación.

**Commit de `PrivateChat`:** `9e3f09c` (2026-11-11), en `review-standard-v2.4-host`, sin push.

### 291 a 297. `Rooms` (2026-11-11)

Los archivos son `IRoomService`, `RoomGameMode`, `RoomMemberState`, `RoomOptions`, `RoomRejectedFault`,
`RoomRejectionReason` y `RoomState`. Con esto, `ServiceEndpoints` es el 298 y `Sessions` son el 299 y el 300.
- **Cumple:**
  - 1.3.1, 2.4.1, 2.11.1 y 2.11.3, 2.15.1, 3.6.1 y §6;
  - §8 y §9 no aplican.
- **Pasada 4:**
  - `RoomContractTranslator` y `RoomClient` leen cada propiedad, los 14 rechazos y los 3 modos.
  - `RetryAfterSeconds` sirve para `TooManyAttempts`.
  - "six-character code" coincide con `RoomPolicy.CodeLength = 6`.
- **7.2 y 7.2.2 (corregido en la copia aparte; incluye la nota de 231–233):**
  - el `<summary>` del servicio ahora también nombra lo que hace el anfitrión: cambiar las opciones e iniciar la partida;
  - `SetReady` y `FindOwnRoom` no documentaban la `FaultException`. Las dos pasan por `TranslateRoomFailures` (R-44),
    así que ahora dicen "could not reach the database";
  - `CreateRoom` y `ChangeOptions` guardan la sala (`RoomRepositoryException`), así que dicen "could not read or write
    the database";
  - `StartMatch` dice "could not reach the database or save the match; the room stays open";
  - `JoinRoom` se queda con "could not reach the database": no guarda nada;
  - los rechazos se quedan con "the detail says why", porque son 14 y la enumeración los nombra.
  - Compila con `GenerateDocumentationFile`.
- **Pregunta 1 (pasada 3, nota de 231–233):** el contrato y el cliente dicen "options" (`RoomOptions`, `ChangeOptions`,
  `RoomState.Options`, `PrivateRoomOptions`). El servidor dice "settings" (`RoomSettings` del dominio,
  `RequestedRoomSettings`, `ChangeSettings`, `RoomSettingsValidator`).
  - Dentro del contrato se mezclan las dos palabras: la prosa de `ChangeOptions` decía "settings" (la copia aparte ya
    dice "options"), y `RoomRejectionReason` tiene `InvalidSettings`.
  - Si el contrato se llamara `RoomSettings`, chocaría con el `RoomSettings` del dominio en `RoomTranslator`, que usa los
    dos.

**Pregunta (291 a 297):**
1. "Options" frente a "settings". Recomendado: A.
   - **A:** cada capa conserva su palabra (como `LobbyChatLog`) y el contrato usa solo "options":
     - la prosa en la copia aparte;
     - `RoomRejectionReason.InvalidSettings` → `InvalidOptions`, con su línea en `RoomTranslator` y su `case` en
       `RoomContractTranslator`.
     - El `RoomRejection.InvalidSettings` del cliente se ve al revisar `Client`.
   - **B:** solo la prosa; `InvalidSettings` se queda.
   - **C:** "settings" en todo: el contrato, el cliente y sus pantallas. Es el arrastre más grande, y el choque de
     nombres en `RoomTranslator` obliga a un alias.

**Respuesta del usuario (2026-11-11):** «Sí, A».
- **Aplicado:**
  - la documentación de `IRoomService`, desde la copia aparte;
  - `RoomRejectionReason.InvalidOptions`, con su entrada en la tabla de `RoomTranslator`
    (`[RoomRejection.InvalidSettings] = RoomRejectionReason.InvalidOptions`) y su `case` en `RoomContractTranslator`.
  - Queda para la revisión de `Client`: el `RoomRejection.InvalidSettings` del cliente.
- **Verificación:**
  - `Host` y `Client` compilan sin avisos de código en una compilación completa (solo NU1902/NU1903);
  - pasan 514 pruebas.

**Commit de `Rooms`:** `ab66fbb` (2026-11-11), en `review-standard-v2.4-host`, sin push.

### 298. `ServiceEndpoints` (2026-11-11)

- **Cumple:** 2.3.1, 2.3.2 (todas son `const`) y 6.2. Cada constante y `CreateAddress` se usan, todos en
  `ServerAddress` del cliente.
- **9.4.1 (incumplimiento, corregido sin preguntas):** `CreateAddress(string host, int port, string path)` no comprobaba
  sus parámetros de referencia. `netstandard2.0` no tiene `ThrowIfNull`, así que van dos guardas
  `if (x is null) { throw new ArgumentNullException(nameof(x)); }`.
- **R-04 (corregido):** `return new UriBuilder(…).Uri` pasa a `var addressBuilder = new UriBuilder(…);` y luego
  `return addressBuilder.Uri;`.
- **Para la revisión de configuración (4.4.2):**
  - `ServiceModel.config` del servidor repite en XML las ocho rutas (`/accounts`…);
  - `appsettings.json` repite el puerto 8000 de `DefaultPort`.
  - La configuración XML no puede leer las constantes de C#.

### 299 y 300. `Sessions` (2026-11-11)

- **`InvalidSessionFault` (300):** cumple.
- **`ISessionService` (299):**
  - **R-41:** "signed-in player" → "logged-in player".
  - El resto ya estaba documentado y coincide con `SessionService`: la `FaultException` de `Subscribe` sale por
    `DbException`, y `KeepAlive` es de un solo sentido y no hace nada.

**Commit de `ServiceEndpoints` y `Sessions`:** `6d689a1` (2026-11-11), sin push.

### Cierre de la capa `Bastion.Contracts` (2026-11-11)

- **R-27:** `Bastion.Contracts.csproj` activa `GenerateDocumentationFile`, en el commit `ab0c785`.
  - CS1591 ya es error en `I*Service.cs` por el `.editorconfig`.
  - `Contracts` compila sin avisos, tampoco IDE0005.
  - `Host` y `Client` compilan sin avisos de código, y pasan 514 pruebas.
- **Commits de la capa en `review-standard-v2.4-host`** (todos locales, sin push): `2a59451`, `1326770`, `43e62a0`,
  `40e3763`, `3878797`, `ac2a8b4`, `9e3f09c`, `ab66fbb`, `6d689a1` y `ab0c785`.
- **Reglas nuevas o ampliadas en la capa:**
  - R-57 (`MessageId`);
  - R-41 en la documentación XML.
- **Notas para `Client.Networking` y `Client`:**
  - `RoomRejection.InvalidSettings` del cliente;
  - los campos `_received` y `_sent` de `FriendRequestsViewModel`;
  - R-41 en los textos de `Client` y `Client.Networking`;
  - R-54 en `RoomContractTranslator`.
- **Sigue `Client.Networking`.**
