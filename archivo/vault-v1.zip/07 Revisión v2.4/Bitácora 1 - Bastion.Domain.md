---
tags: [revision-v2-4]
---
# Bitácora 1 - Bastion.Domain
Volver a [[Índice de la revisión v2.4]]

### 1. `src/Bastion.Domain/Accounts/Account.cs` (2026-11-10)

Entidad de la cuenta; la persiste EF Core (`AccountConfiguration`) y la usan `LoginService`, `FriendPresenceService`
y los repositorios.

**Pasada 1, reglas por sección**
- §1 Idioma: cumple.
- §2 Nombrado: cumple en 2.1–2.8 y 2.10–2.15. Dudas: **2.9.1** (L-03, no redefine `Equals`) y **2.1.2** (¿`byte[]
  PasswordHash`/`PasswordSalt` cuentan como colección y van en plural?).
- §3 Estilo: cumple (no usa `var`, Allman, espaciado). 3.7 no aplica.
- §4 Complejidad: cumple (guardas en `Activate` y `GetRemainingLockMinutes`, patrón `is`).
- §5 Funcional: no aplica (sin lambdas ni LINQ).
- §6 Estructura: cumple (un tipo, orden constante → constructores → propiedades → métodos, `using`, espacio de
  nombres = carpeta).
- §7 y §8: cumple (no es servicio; sin documentación ni comentarios).
- §9 Excepciones: cumple (`InvalidOperationException` en inglés, `ThrowIfNull` en el constructor y en
  `ChangePassword`).
- §10 Inyección: cumple (recibe `now`, no lee el reloj). §11 y §12: no aplican.

**Pasada 2, repetición**
- R-1: la condición del bloqueo (`LockedUntil is DateTime lockedUntil && lockedUntil > now`) está en `IsLockedAt` y,
  negada, en `GetRemainingLockMinutes`.
- R-2: los dos constructores repiten `PreferredLanguage = DefaultLanguage` y `FriendCode = string.Empty`.
- `"en"` solo está aquí en C#; también es el `DEFAULT ('en')` de `Account.PreferredLanguage` en
  `02_create_tables.sql:104` (otra capa, no se repite en código).

**Pasada 3, nombres**
- N-1: `ChangePassword(byte[] hash, byte[] salt)` no recibe una contraseña sino su hash → `SetPasswordHash(passwordHash,
  passwordSalt)`.
- N-2: `FailedAttempts`, `LastFailedAttemptAt` no dicen de qué → `FailedSignInCount`, `LastFailedSignInAt` (con
  `HasColumnName` para no tocar la base).
- N-3: `DefaultLanguage` → `DefaultPreferredLanguage`.
- Se quedan por decisión anterior (`05-pendientes.md`): `Activate`.

**Pasada 4, necesidad** (búsqueda con `git grep` en `src/` y `tests/`)
- `CanSignIn()`: solo lo usan las pruebas; el login decide por `AccountStatus` en `LoginService.AdmitByAccountStatus`.
- `ChangePassword`, `Activate()` y el constructor público: solo los usan las pruebas (CU-02 y CU-04 no están en el
  servidor todavía).
- `IsTwoFactorEnabled`: nadie la lee; EF la mapea por convención.
- `DefaultLanguage` es `public` pero solo se usa dentro de la clase.

**Hallazgo nuevo al preparar las propuestas:** la **2.6.3** pide inicializar en su declaración todo valor que no
depende de un parámetro del constructor. En `Account` eso son `AccountType = Registered`, `AccountStatus = Pending`,
`PreferredLanguage = DefaultLanguage` y `FriendCode = string.Empty`, hoy asignados en los constructores. La regla dice
«campo»; si aplica también a propiedades autoimplementadas es la lectura L-10.

**Decisiones tomadas:** R-01 (2.9.1) y R-02 (2.1.2).

**Propuestas presentadas el 2026-11-10** (el usuario pidió contexto, propuesta, pros y contras antes de decidir):
- A1 quitar `CanSignIn` y sus 2 pruebas · A2 quitar `ChangePassword` · A3 quitar `Activate` · A4 quitar el constructor
  público · A5 quitar `IsTwoFactorEnabled` · A6 `DefaultLanguage` a `private`.
- B1 unificar la condición del bloqueo · B2 inicializar en la declaración (2.6.3) · B3 `ChangePassword` →
  `SetPasswordHash` · B4 `FailedAttempts`/`LastFailedAttemptAt` → `FailedSignInCount`/`LastFailedSignInAt` ·
  B5 `DefaultLanguage` → `DefaultPreferredLanguage`.
- Recomendación dada: aplicar A1, A6, B1, B2, B4 y B5; mantener A2–A5 (las pruebas los necesitan y CU-02, CU-04 y
  CU-05 los usarán); B3 solo si se mantiene A2.

**Respuesta del usuario (2026-11-10):** el `return` de B1 queda difícil de leer, y B2 reparte la inicialización
entre declaraciones y constructores. De ahí sale la decisión D-06. Propuestas revisadas:
- **B1′**: `GetRemainingLockMinutes` usa `IsLockedAt` como guarda y separa el cálculo en
  `TimeSpan remainingLock = LockedUntil.Value - now;` antes de `return (int)Math.Ceiling(remainingLock.TotalMinutes);`.
- **B2′**: toda la inicialización sigue en los constructores; para no repetirla, el constructor público encadena
  `: this()` y el privado fija los valores comunes (`Nickname = string.Empty`, `PreferredLanguage`, `FriendCode`).
  Con eso la L-10 se respondería así: la 2.6.3 aplica a campos, no a propiedades autoimplementadas.

**Respuesta del usuario sobre B1′:** `return (int)Math.Ceiling(remainingLock.TotalMinutes);` sigue difícil de leer
porque mezcla un cast y una llamada. Propuesta **B1″**, un paso por línea:

```csharp
TimeSpan remainingLock = LockedUntil.Value - now;
double roundedUpMinutes = Math.Ceiling(remainingLock.TotalMinutes);
int remainingMinutes = (int)roundedUpMinutes;
return remainingMinutes;
```

Criterio propuesto para todos los `return` (pendiente de confirmar, ampliaría la D-06): el `return` devuelve una
variable, un literal o una sola llamada con argumentos simples; los casts, la aritmética y las llamadas anidadas
van antes, en variables con nombre, un paso por línea.

**Observación del usuario sobre B2′:** el constructor privado no reescribe el `Nickname`. Aclaración: con `: this()`
el privado corre primero (`Nickname = string.Empty`) y después el cuerpo del público asigna el parámetro, así que el
valor final es correcto. Pero `Nickname` se asigna dos veces y quien lee tiene que saber ese orden, lo que va contra
la D-06. Opciones:
- **B2′** (encadenar con `: this()`): sin repetir `PreferredLanguage` ni `FriendCode`; el orden queda oculto y
  `Nickname` se asigna dos veces.
- **B2-0** (dejar los constructores como están): cada uno se lee completo sin saltar al otro; se repiten dos
  asignaciones de valores por omisión.
- Recomendación: B2-0, porque prima la lectura (D-06).

**Decisión del usuario:** B2′, encadenar con `: this()` (queda como R-03).

**Decisiones finales del archivo (2026-11-10):**
- Se aplican: A1 (quitar `CanSignIn` y sus 2 pruebas), A6 (`DefaultLanguage` privada), B1″ (un paso por línea),
  B2′ (`: this()`), B4 (`FailedSignInCount`/`LastFailedSignInAt` con `HasColumnName`) y B5
  (`DefaultPreferredLanguage`).
- Se quedan: `ChangePassword`, `Activate`, el constructor público (los usan las pruebas y los usarán CU-02 y CU-04) e
  `IsTwoFactorEnabled` (la usará CU-05). B3 no se aplica. La L-09 queda abierta: se decide caso por caso.
- El criterio del `return` queda como R-04.

**Al compilar (2026-11-10):** B1″ da el aviso CS8629 en `LockedUntil.Value`, porque el compilador no sabe que la
guarda `IsLockedAt(now)` ya descartó el nulo. El usuario pidió pros, contras y alternativas. Opciones:
1. `[MemberNotNullWhen(true, nameof(LockedUntil))]` sobre `IsLockedAt` (probado, sin aviso).
2. Volver a la guarda con `is` en `GetRemainingLockMinutes` (la condición queda dos veces).
3. Un privado `TryGetActiveLockEnd(now, out DateTime lockEnd)` y los dos públicos lo usan.
4. Un privado `GetRemainingLock(now)` que devuelve `TimeSpan.Zero` si no hay bloqueo: `IsLockedAt` compara con cero
   y `GetRemainingLockMinutes` ya no necesita guarda (probado, sin aviso y con el mismo resultado en tres casos).
5. `LockedUntil.GetValueOrDefault()`: no se recomienda, porque sugiere un valor alternativo que nunca ocurre (9.4.2).
- Recomendación: la 4. Queda pendiente si la R-04 admite una comparación en el `return` (`return remainingLock >
  TimeSpan.Zero;`) o si va a una variable `bool`; lo mismo afecta a `HasPassword` e `IsLockedAt`.
- Mientras se decide, el archivo queda con B1″ y el aviso; no hay commit.
- **Decisión del usuario:** opción 3, el patrón Try (queda como R-06). Antes de elegir pidió que se le explicara el
  patrón y cómo funciona `out`. `HasPassword` se queda igual por la R-05.

**Estado final del archivo (2026-11-10):** cambios aplicados en `review-standard-v2.4`. Además de `Account.cs`, tocan
`AccountConfiguration.cs` (dos `HasColumnName`), `TestAccount.cs` (se quitan las 2 pruebas de `CanSignIn` y
`FailedAttempts` pasa a `FailedSignInCount`) y `TestLoginService.cs` (`FailedSignInCount` y el nombre de una prueba).
Todo compila sin avisos de código (el Host, en otra carpeta, porque el servidor del usuario sigue abierto) y pasan
518 pruebas (162 + 220 + 136). Con un programa aparte se comprobó contra la base local, en solo lectura, que
`FailedSignInCount` y `LastFailedSignInAt` siguen leyendo las columnas `FailedAttempts` y `LastFailedAttemptAt`.
Commit `38a940d` (2026-11-10), sin push (D-07).

### 2. `src/Bastion.Domain/Accounts/AccountRules.cs` (2026-11-10)

Clase estática con las longitudes del apodo y del correo, y la validación de su formato con expresiones regulares.

**Pasada 1, reglas por sección**
- §1: cumple. §3: cumple (argumentos de `new Regex(` uno por línea, 3.5.1). §5: no aplica. §6: cumple. §7, §8: cumple.
  §9: cumple (los parámetros son `string?`, no piden `ThrowIfNull`). §10–§12: no aplican.
- §2 **2.4.1**: `AccountRules` está en plural y no es una clase que solo agrupe valores del mismo tipo (mezcla `int`,
  `TimeSpan`, `Regex` y métodos). Lo mismo pasa con `ChatRules`, `FriendCodeRules`, `FriendshipRules`,
  `MatchmakingRules` y `RoomRules`. Ya existe un precedente en singular: `LockoutPolicy`.
- §4 **4.4.2**: `MatchTimeoutMilliseconds = 250` y `_matchTimeout` están iguales en `Friends/FriendCodeRules.cs:15-17`.
- R-05: `IsEmail` devuelve una condición de tres partes con una llamada
  (`text is not null && text.Length <= MaximumEmailLength && _emailPattern.IsMatch(text)`). Hay que decidir si eso
  sigue siendo «corta».

**Pasada 2, repetición**
- El tiempo límite de las expresiones regulares y la forma de crearlas (`new Regex(patrón, CultureInvariant,
  _matchTimeout)`) se repiten en `FriendCodeRules`. Candidato a una clase compartida del dominio.

**Pasada 3, nombres**
- `MatchTimeoutMilliseconds`/`_matchTimeout`: en Bastión «match» es la partida → `RegexTimeoutMilliseconds`/
  `_regexTimeout`.
- `IsNickname(text)`, `IsEmail(text)`, `IsIdentifier(text)` → `IsValidNickname(nickname)`, `IsValidEmail(email)`,
  `IsValidSignInIdentifier(identifier)`; `MaximumIdentifierLength` → `MaximumSignInIdentifierLength`.
- Lectura (D-06): `$"^[A-Za-z0-9_]{{{MinimumNicknameLength},{MaximumNicknameLength}}}$"` es difícil de leer por las
  llaves triples; se puede comprobar la longitud aparte y dejar el patrón en `^[A-Za-z0-9_]+$`.

**Pasada 4, necesidad**
- `IsNickname`, `IsEmail` e `IsIdentifier` solo los usan las pruebas (`TestAccountRules`).
- CU-01, paso 3 y FA-04, pide que el cliente valide que el identificador tenga formato de apodo o de correo;
  `LoginViewModel` solo comprueba que no esté vacío. `IsIdentifier` es la pieza para eso, y `Bastion.Client` ya
  referencia `Bastion.Domain`. CU-02 RN-01 (apodo de 3 a 30) usará `IsNickname`.
- Las constantes sí se usan: `MinimumNicknameLength` (búsqueda de amigos), `MaximumNicknameLength`,
  `MaximumEmailLength` y `MaximumIdentifierLength` (configuraciones de EF).

**Decisiones tomadas:** R-07 (`AccountRules` → `AccountPolicy`), R-08 (`TextPattern.Create`), y se mantienen
`IsNickname`/`IsEmail`/`IsIdentifier`, con CU-01 FA-04 anotado para revisar `LoginViewModel`.

**Propuestas de nombres y lectura presentadas** (el usuario pidió razón, pros, contras y propuesta de cada una):
N1 `MatchTimeout` → queda resuelto dentro de `TextPattern` · N2 `IsValidNickname`/`IsValidEmail`/
`IsValidSignInIdentifier` y `MaximumSignInIdentifierLength` · N3 la longitud del apodo fuera del patrón ·
N4 `IsEmail` con guarda · ubicación de `TextPattern` en `Bastion.Domain/Text`.

**Decisión del usuario:** «Todas» (N2, N3, N4 y `TextPattern` en `Bastion.Domain/Text`).

**Estado final (2026-11-10):** `AccountRules.cs` → `AccountPolicy.cs` con `IsValidNickname`, `IsValidEmail`,
`IsValidSignInIdentifier` y `MaximumSignInIdentifierLength`; nuevo `src/Bastion.Domain/Text/TextPattern.cs`;
`TestAccountRules.cs` → `TestAccountPolicy.cs` (clase y pruebas renombradas, sin tocar sus datos, que se revisan con
las pruebas); llamadas actualizadas en `AccessLogConfiguration`, `AccountConfiguration` y `FriendRequestService`.
Nota de CU-01 FA-04 agregada a `05-pendientes.md`. Compila sin avisos de código y pasan 518 pruebas. Commit
`2a09e60`, sin push.

### 3. `src/Bastion.Domain/Accounts/AccountStatus.cs` (2026-11-10)

Enumeración de los estados de una cuenta.
- Pasada 1: cumple. §2.15.1 sustantivo singular sin sufijo ni prefijos en los valores; §6 un tipo y su espacio de
  nombres. Las demás secciones no aplican a una enumeración sin lógica.
- Pasada 2: los valores se repiten solo en el `CHECK` de la base (`CK_Account_AccountStatus`), que es otra capa.
- Pasada 3: nombres claros.
- Pasada 4: los cinco valores se usan en `src` (`LoginService.AdmitByAccountStatus` y otros).
- **Cerrado sin cambios.**

### 4. `src/Bastion.Domain/Accounts/AccountType.cs` (2026-11-10)

Enumeración del tipo de cuenta: registrada o invitado.
- Pasada 1: cumple, igual que `AccountStatus`.
- Pasada 2: sin repetición en C#. Pasada 3: nombres claros.
- Pasada 4: `Guest` no se nombra en el código, pero la base tiene una cuenta `GUEST` (`Invitado_4821`). EF la lee con
  el conversor de la enumeración, así que quitar el valor rompería la lectura de esa fila. CU-03 (jugar como invitado)
  también lo usará.
- **Cerrado sin cambios.**

### 5. `src/Bastion.Domain/Accounts/LockoutPolicy.cs` (2026-11-10)

Bloqueo escalonado por intentos fallidos. Coincide con CU-01 RN-03: 3 intentos → 5 min, 6 → 30 min, desde 9 → 60 min,
y el contador se restablece a las 24 h.
- Pasada 1: §2, §3, §6 y §9 cumplen. §4.5.1 admite el `?:`, pero **R-04** no: el último `return` es un condicional
  con una llamada. Se aplica la R-04 (D-07): `if (consecutiveFailures == FirstThreshold)` con su `return` y al final
  `return TimeSpan.Zero;`, igual que las dos ramas anteriores.
- Pasada 2: sin repetición.
- Pasada 3 (se pregunta): `CounterResetPeriod` no dice de qué contador → `FailedSignInCountResetPeriod`, que coincide con
  `Account.FailedSignInCount`; `FirstThreshold`/`SecondThreshold`/`ThirdThreshold` → `FirstLockThreshold`/…;
  `consecutiveFailures` → `failedSignInCount`.
- Pasada 4: `CounterResetPeriod` y `GetLockDuration` los usa `Account`; las constantes son privadas.

**Decisión del usuario:** los tres renombres. Se aplicaron con la R-04; también cambian `Account.cs` (usa
`FailedSignInCountResetPeriod`) y `TestLockoutPolicy.cs` (nombre de la prueba). La constante privada
`CounterResetHours` se dejó igual porque no se preguntó. Compila y pasan las pruebas de dominio y aplicación
(162 + 220). Commit `a48853e`, sin push.

### 6. `src/Bastion.Domain/Auditing/AccessAttempt.cs` (2026-11-10)

Record posicional con el identificador escrito, la conexión y la hora de un intento de inicio de sesión. Lo usan
`LoginService`, `AccountService` y `LoginTranslator`.
- Pasada 1: §2.8.1 (valor inmutable como `record`), §2.2.2 (3 parámetros), §3, §6 cumplen. **Lectura L-02**: sus
  parámetros de referencia (`EnteredIdentifier`, `Connection`) no se comprueban con `ThrowIfNull`; ¿la 9.4.1 aplica al
  constructor primario de un record posicional? ¿Y cuenta para el límite de 3 de la 2.2.2?
- Pasada 2: sin repetición. Pasada 4: se usa.
- Pasada 3: ver la decisión de vocabulario «Login/SignIn» (abajo).

### 7. `src/Bastion.Domain/Auditing/AccessLog.cs` (2026-11-10)

Entidad de la bitácora de accesos; la crea `LoginService` y EF la inserta.
- Pasada 1: cumple (R-01 sin `Equals`; R-03 cada constructor asigna sus valores, sin valores comunes que encadenar;
  `ThrowIfNull(attempt)`).
- Pasada 2: sin repetición. Pasada 3: nombres claros.
- Pasada 4: ninguna clase lee sus propiedades, pero son las columnas que la bitácora guarda: se quedan.

### 8. `src/Bastion.Domain/Auditing/AccessLogResult.cs` (2026-11-10)

Enumeración del resultado de un intento de acceso.
- Pasada 1: cumple. Pasada 2: los valores se repiten solo en el `CHECK` de la base, que además admite otros para
  casos futuros. Pasada 4: los seis valores los usa `LoginService`.
- Pasada 3: `LoginSucceeded` usa «Login», y en archivos ya revisados se usa «SignIn» (`RecordFailedSignIn`,
  `FailedSignInCount`, `IsValidSignInIdentifier`). Es el mismo concepto con dos palabras.

**Decisión de vocabulario abierta:** en `src` hay unos 35 nombres con «Login/LogIn» (`LoginService`, `LoginViewModel`,
`LoginCredentials`, `IAccountService.LogIn`, claves de recursos) y unos 13 con «SignIn/SignedIn» (`Account`,
`AccountPolicy`, `LockoutPolicy`, `SignedInPlayer`, `SignedInSession`).

**Decisiones tomadas:** R-09 (los records cuentan para la 2.2.2) y R-10 («Login» en todo). El renombre de los
nombres «SignIn» de los archivos 1, 2 y 5 (con `LoginService`, `AccessLogConfiguration`, `AccountConfiguration` y sus
pruebas) va en el commit `c406863`; compila y pasan 162 + 220 pruebas. `AccessLog.cs` y `AccessLogResult.cs` quedan
cerrados sin cambios (`LoginSucceeded` ya usa «Login»).

**L-02, regla 9.4.1 en records posicionales:** el usuario pidió razonamiento, pros, contras y alternativas. Hay 67
records posicionales en `src` (Domain 10, Server.Application 29, Client 10, Client.Networking 18); `with` se usa en 3
lugares (`MatchFormat`, `RoomSettings` y un evento de `PrivateConversationViewModel`); no se usa la deconstrucción.
Opciones presentadas:
- A. Constructor explícito con `ThrowIfNull` (deja de ser posicional). Única que cumple la letra. Recomendada.
- B. Exentos: se quedan en una línea.
- C. `?? throw` en las propiedades del record posicional (no usa `ThrowIfNull`, se lee peor).
- D. Por capa: A en Domain y Server.Application, B en Client y Client.Networking.

**Decisión del usuario (L-02):** opción A, constructor explícito → **R-11**. `AccessAttempt` pasa a un constructor con
`ThrowIfNull(enteredIdentifier)` y `ThrowIfNull(connection)` y propiedades `{ get; }`; no se usa con `with`. Los dos
lugares que lo crean (`LoginTranslator` y `TestLoginService`) ya pasan los argumentos en orden y no cambian. Compila el
servidor (en carpeta aparte, el servidor del usuario sigue abierto) y pasan 162 + 220 pruebas. Commit `36d0280`, sin push.

### 9. `src/Bastion.Domain/Chat/ChatRules.cs` (2026-11-10)

Reglas del chat (CU-20 RN-03 largo, RN-04 ritmo): `MaximumMessageLength = 200`, `CooldownSeconds = 3`,
`HistoryCapacity = 200`, `RecentMessageCount = 50` e `IsValidMessage`. Lo usan el cliente (tres modelos de vista y
`ChatRejectionText`) y el servidor (`ChatModerator`, `ChatCooldown`, `LobbyChatRoom`, `LobbyChatService`,
`PrivateChatService`).
- Pasada 1: §1, §3, §5–§12 cumplen o no aplican (sin lambdas, sin comentarios, `text` es `string?` y no pide
  `ThrowIfNull`). §2.4.1: nombre en plural → **R-07**, pasa a `ChatPolicy` (y `TestChatRules` → `TestChatPolicy`, 12.1.1).
  **R-04**: `return !string.IsNullOrWhiteSpace(text) && text.Trim().Length <= MaximumMessageLength;` encadena una
  llamada (`Trim().Length`) dentro de la condición → guarda `if (string.IsNullOrWhiteSpace(text)) { return false; }`,
  `string trimmedText = text.Trim();` y `return trimmedText.Length <= MaximumMessageLength;` (R-05).
- Pasada 2: `IsValidMessage` es la única validación del largo y la usan cliente y servidor (CU-20 RN-06): bien.
  Fuera del archivo: `MessageConfiguration.TextLength = 500` y `Message.Text NVARCHAR(500)` no usan los 200 del dominio
  (4.4.2). Se pregunta al revisar `MessageConfiguration.cs`.
- Pasada 3 (se pregunta): `CooldownSeconds` no dice de qué (el CU-20 RN-12 tiene otro de 10 s para los emotes);
  `RecentMessageCount` se lee como una cuenta, y es un límite (cuántos mensajes recientes manda el servidor y conserva
  la pantalla); `IsValidMessage` solo mira el largo, no el filtro de palabras, pero coincide con
  `ChatRejection.InvalidMessage`.
- Pasada 4 (se pregunta): `HistoryCapacity` solo lo usa `LobbyChatRoom`: guarda 200 líneas, pero en producción solo
  se leen las últimas 50 (`LobbyChatService` llama `ListRecent(RecentMessageCount)`; la única llamada con
  `HistoryCapacity` es la prueba `Post_AboveCapacity_DropsOldestLine`). 150 líneas se guardan y nunca se sirven.

**Decisiones del usuario:** quitar `HistoryCapacity` (el lobby guarda solo `MaximumRecentMessages`);
`RecentMessageCount` → `MaximumRecentMessages`; `CooldownSeconds` → `MessageCooldownSeconds`; `IsValidMessage` se queda
(coincide con `ChatRejection.InvalidMessage` y el CU-20 RN-03). Se aplicaron con la R-07 y la R-04: `ChatPolicy.cs`,
`TestChatPolicy.cs`, los nueve archivos de cliente y servidor que la usan, y la prueba
`MatchChatMessageReceived_OverMaximumRecentMessages_DropsOldestMessage` (llevaba el nombre viejo). Compila el servidor
(carpeta aparte) y pasan 162 + 220 + 136 pruebas. Commit `47be2f3`, sin push.

Para los siguientes archivos: `ILobbyChatRoom.ListRecent(int count)` y `LobbyChatRoom` ya solo guardan lo que se pide;
al revisarlos, ver si el parámetro `count` sigue haciendo falta.

### 10. `src/Bastion.Domain/Chat/ChatWordFilter.cs` (2026-11-10)

Filtro de palabras prohibidas (CU-20 RN-01). Pasa el texto y cada término a minúsculas sin acentos, con un solo
espacio entre palabras y un espacio a cada lado, para que `Contains(" term ")` encuentre solo palabras completas. Lo
usa `ChatModerator`.
- Pasada 1: §1, §3 (Allman, `var builder` evidente, `&&` al inicio de la continuación), §4.1–4.6, §6, §9
  (`ThrowIfNull` de los dos parámetros) cumplen; §7, §8, §10–§12 no aplican.
  - **2.2.3 (incumplimiento):** `ContainsBannedTerm` devuelve `bool` y es una pregunta; `Contains` no está en la lista
    (Is, Are, Has, Can, Should) ni es un miembro de la plataforma o de una interfaz → `HasBannedTerm`.
  - **R-04 (incumplimiento):** el `return` es una cadena LINQ de tres operadores con dos lambdas. La 5.3.1 la admite
    (termina en `Any`, un operador por línea), pero la R-04 pide devolver una variable. Es el primer `return` con
    LINQ: se pregunta cómo resolverlo para todo el proyecto.
  - **Lectura de la 2.2.1:** `ToComparableWords` usa la convención `To<Tipo>`, pero el estándar la admite para
    convertir «en otro tipo», y aquí va de `string` a `string`.
- Pasada 2: «agregar un separador si el último carácter no lo es» se repite en `ToComparableWords` (al final) y en
  `AppendComparable` (dentro de un `else if` que mezcla dos condiciones).
- Pasada 3: `ToComparableWords`, `AppendComparable`, `comparableText` y `decomposed` no dicen qué le pasa al texto.
- Pasada 4: los tres métodos y la constante se usan.

**Decisiones del usuario:** la cadena LINQ va en una variable `bool` y el `return` la devuelve (**R-12**, para todo el
proyecto); `ContainsBannedTerm` → `HasBannedTerm` (y `containsBannedTerm` → `hasBannedTerm`, 2.1.4); se crea
`AppendSeparator(builder)` y el `else if` queda con una sola condición; nombres de la familia «Normalize»:
`NormalizeWords`, `AppendNormalizedCharacter`, `normalizedText`, `decomposedText` (**R-13** para la 2.2.1). Cambian
también `ChatModerator` (la llamada) y `TestChatWordFilter` (nombres de las pruebas y la variable). Compila el
servidor (carpeta aparte) y pasan 162 + 220 pruebas. Commit `014dc0c`, sin push.

### 11. `src/Bastion.Domain/Chat/MatchChatSubmission.cs` (2026-11-10)

Lo que un jugador manda al chat de una partida: el número de partida y el texto. Lo crean `ChatService` (Host) y
`MatchChatRelay`, y lo reciben `IMatchChatService.SendMessage` y `Message.CreateForMatch`.
- Pasada 1: record posicional con un `string` sin comprobar → **R-11**: constructor con `ThrowIfNull(text)` y
  propiedades `{ get; }`; no se copia con `with`. El resto cumple; 2.2.2 con dos parámetros.
- Pasada 2: sin repetición. Pasada 3: nombre claro (lo que se envía al chat de partida).
- Pasada 4: necesario. Sin él, `SendMessage` y `CreateForMatch` tendrían cuatro parámetros (2.2.2).

Cerrado sin preguntas (solo la R-11). Los llamadores ya pasan los argumentos en orden. Compila el servidor (carpeta
aparte) y pasan 162 + 220 pruebas. Commit `a7cb6dd`, sin push.

### 12. `src/Bastion.Domain/Chat/Message.cs` (2026-11-10)

Entidad de EF de un mensaje guardado: privado (canal `Friends`, con constructor público) o de partida (canal `Match`,
con `CreateForMatch`).
- Pasada 1: §1, §3, §6 y §9 cumplen (`ThrowIfNull` de `participants`, `text` y `submission`; `ArgumentException` con
  `nameof`). R-01: sin `Equals`. R-03: los dos constructores no comparten valores (el privado solo pone
  `Text = string.Empty` para EF), así que no se encadenan.
  - **R-04 (incumplimiento):** `GetPartnerId` devuelve `IsSentBy(accountId) ? RecipientId.GetValueOrDefault() : AuthorId`,
    un condicional con dos llamadas → `if (IsSentBy(accountId)) { return RecipientId.GetValueOrDefault(); }` y
    `return AuthorId;`, como en `LockoutPolicy`.
  - **Lectura de la R-04:** `CreateForMatch` devuelve `new Message { … }` con cinco asignaciones simples. Hay 121
    `return new` en `src`: se pregunta si una creación cuenta como «una sola llamada».
- Pasada 2: sin repetición (`GetPartnerId` reutiliza `IsSentBy`).
- Pasada 3: `new Message(participants, …)` crea un mensaje privado, pero la llamada no lo dice, mientras que el de
  partida usa `CreateForMatch`. `SameAccountMessage` sigue la convención del proyecto para textos de excepción
  (`FriendRequest`, `Friendship`, `DefaultMessage`). `GetPartnerId` usa el vocabulario de `PrivateChatService`.
- Pasada 4: `MarkRead` solo lo usan `FakeMessageRepository` y `TestMessage`. En producción,
  `MessageRepository.MarkRead` marca con `ExecuteUpdate` y el filtro `ReadAt == null`, que es la misma regla.
  Es un caso de la L-09.

**Decisiones del usuario:** `Message.CreatePrivate(participants, text, sentAt)` en lugar del constructor público, que
pasa a ser solo el privado de EF; `return new X { … }` con valores simples se admite (**R-14**), y `CreateForMatch`
se queda; `MarkRead` se mantiene (**R-15**). Se aplicó también la R-04 en `GetPartnerId`. Cambian
`PrivateChatService` (la llamada), `TestPrivateChatService` (el ayudante `StoreMessage`) y `TestMessage`: dos pruebas
pasan a `CreatePrivate_DifferentPlayers_UsesFriendsChannel` y `CreatePrivate_SameAuthorAndRecipient_Throws`, y el
ayudante `CreateMessage` guarda primero los participantes en una variable (R-14). Compila el servidor (carpeta aparte)
y pasan 162 + 220 + 136 pruebas. Commit `7a17d55`, sin push.

### 13. `src/Bastion.Domain/Chat/MessageChannel.cs` (2026-11-10)

Enumeración del canal de un mensaje: `Match`, `Spectators`, `Room`, `Global`, `Friends`.
- Pasada 1: 2.15.1 (singular, no es `[Flags]`) y el resto cumplen.
- Pasada 2: los valores se repiten en el `CHECK` `CK_Message_Channel` de la base, que es su origen.
- Pasada 3: nombres claros.
- Pasada 4: el código solo usa `Friends` y `Match`, pero la base de prueba tiene filas `GLOBAL` (2), `ROOM` (3) y
  `SPECTATORS` (1), y EF las lee con `UpperSnakeCaseEnumConverter`. Se quedan, como `AccountType.Guest`.

**Cerrado sin cambios.**

### 14. `src/Bastion.Domain/Chat/MessageParticipants.cs` (2026-11-10)

Autor y destinatario de un mensaje privado: `record MessageParticipants(int AuthorId, int RecipientId)`. Lo usan
`Message.CreatePrivate` y `IMessageRepository.MarkRead`.
- Pasada 1: record posicional **sin parámetros de referencia**: la 9.4.1 no tiene nada que comprobar. Lectura **L-11**:
  ¿la R-11 lo convierte igual a constructor explícito?
- Pasada 2: sin repetición. Pasada 3: nombre claro.
  Fuera del archivo: en `IMessageRepository.MarkRead` y `MessageRepository.MarkRead` el parámetro se llama
  `readMessages`, que parece una colección de mensajes (2.1.2) y es la pareja autor-destinatario. Se pregunta al
  revisar esos archivos.
- Pasada 4: necesario. Sin él, `CreatePrivate` y `MarkRead` tendrían cuatro y tres datos sueltos (2.2.2).

**Decisión del usuario (L-11):** se queda posicional → **R-16**. **Cerrado sin cambios.** Con esto termina la carpeta
`Chat` del dominio; sigue `Friends`.

### 15. `src/Bastion.Domain/Friends/FriendCodeRules.cs` (2026-11-10)

Código de amigo (CU-21 RN-05): seis caracteres de un alfabeto sin los que se confunden (sin I, L, O, 0, 1). Valida
(`IsValidFriendCode`), quita guiones y espacios y pasa a mayúsculas (`NormalizeFriendCode`), y agrega un guion después
del segundo carácter para mostrarlo (`FormatFriendCode`, «QU-7K2P»). Lo usan `FriendRequestService`,
`FriendListService`, `PrivateChatService`, `AccountConfiguration` (largo de la columna) y el cliente
(`FriendsPanelViewModel`).
- Pasada 1: §1, §3, §4.1–4.3, §6 y §9 cumplen.
  - **2.4.1:** plural → **R-07**: `FriendCodePolicy` (y `TestFriendCodeRules` → `TestFriendCodePolicy`).
  - **R-08:** crea su `Regex` con su propio tiempo límite → `TextPattern.Create`; se van `MatchTimeoutMilliseconds` y
    `_matchTimeout`.
  - **R-04:** `return code.Insert(GroupLength, Separator.ToString());` lleva una llamada anidada → la cadena del
    separador va antes en una variable.
  - R-05: `return text is not null && _friendCodePattern.IsMatch(text);` es una condición corta: se queda.
- Pasada 2: el alfabeto se repite en `database/05_create_friends.sql` (generación y `CHECK`), que es la definición
  de la base, como los `CHECK` de las enumeraciones. `RoomRules.CodeAlphabet` es otro alfabeto que **sí** incluye la L:
  se pregunta al revisar `RoomRules`.
  Fuera del archivo: normalizar, validar y buscar por código se repite en `FriendRequestService.FindPlayerByCode` y en
  `PrivateChatService` (y algo parecido en `FriendListService`). Se pregunta en la capa de aplicación.
- Pasada 3 (se pregunta): los métodos repiten «FriendCode» en una clase que ya se llama así (`Length` no lo repite);
  `GroupLength = 2` hace pensar en grupos de dos («QU-7K-2P»), pero solo se agrega un guion, después del segundo carácter.
- Pasada 4: los tres métodos y `Length` se usan en producción.

**Decisiones del usuario:** `IsValid`, `Normalize` y `Format` (sin repetir «FriendCode»); `GroupLength` →
`SeparatorPosition`. Se aplicaron con la R-07, la R-08 y la R-04. Cambian `FriendRequestService`,
`FriendListService`, `PrivateChatService`, `AccountConfiguration`, `FriendsPanelViewModel` y
`TestFriendCodePolicy` (nombres de las pruebas). Compila el servidor (carpeta aparte) y pasan 162 + 220 + 136 pruebas.
Commit `b97c92c`, sin push.

### 16. `src/Bastion.Domain/Friends/FriendRequest.cs` (2026-11-10)

Entidad de EF de una solicitud de amistad pendiente (CU-21, CU-22). La clave es (`RequesterId`, `RecipientId`) y caduca
a los `FriendshipRules.RequestLifetimeDays` días.
- Pasada 1: §1, §3, §4, §6 y §9 cumplen (solo parámetros por valor). R-01: sin `Equals`; R-03: el constructor privado
  de EF está vacío.
  - **2.11.4 (incumplimiento):** `public DateTime ExpiresAt => RequestedAt.AddDays(...)` es un valor calculado con
    cuerpo de expresión fuera de un catálogo de diccionario; la regla pide un método. Es el primero del dominio: en
    `src` hay 80 propiedades con `=>`, casi todas en modelos de vista del cliente (que Gum enlaza por nombre de
    propiedad) y 13 `DbSet` en `BastionDbContext` (L-04). Esos se verán en su capa.
- Pasada 2: la comprobación «el mismo jugador en los dos lados» (`if (a == b) throw new ArgumentException(…)`) se
  repite en `FriendRequest`, `Friendship` y `Message.CreatePrivate`, cada una con su texto.
  Fuera del archivo: la fórmula de caducidad se repite en la proyección de EF de `FriendRequestRepository` (línea 85,
  `request.RequestedAt.AddDays(FriendshipRules.RequestLifetimeDays)`), porque EF no traduce un método propio a SQL; y
  `FriendRequestService` filtra los `FriendRequestSummary` con `ExpiresAt > now` (líneas 97 y 100). Se ven al revisar
  esos archivos.
- Pasada 3: nombres claros. Pasada 4: todo se usa en producción.

**Decisiones del usuario:** `ExpiresAt` pasa al método `GetExpirationTime()` (**R-17**); la guarda «el mismo jugador»
se queda en cada entidad con su texto (**R-18**). Se va `builder.Ignore(request => request.ExpiresAt)` de
`FriendRequestConfiguration` (EF no mapea métodos); cambian `FriendRequestService` (línea 87) y
`FakeFriendRequestRepository`. Los `ExpiresAt` de `FriendshipTranslator` y del cliente son de `FriendRequestSummary` y
`PendingFriendRequest`, no de la entidad, y no cambian. Compila el servidor (carpeta aparte) y pasan 162 + 220 pruebas.
Commit `22f7502`, sin push.

### 17. `src/Bastion.Domain/Friends/Friendship.cs` (2026-11-10)

Entidad de EF de una amistad. Guarda la pareja ordenada (`AccountAId` el menor y `AccountBId` el mayor, por el `CHECK
CK_Friendship_Order` de la base) y la fecha. La crea `FriendRequestService` al aceptar una solicitud.
- Pasada 1: cumple (R-01, R-03, R-18; `Math.Min`/`Math.Max` en asignaciones, no en un `return`).
- Pasada 2: sin repetición. `GetFriendAccountId` se parece a `Message.GetPartnerId`, pero aquel lanza una excepción con
  un tercero y este no.
- Pasada 3 (se pregunta): `AccountAId`/`AccountBId` no dicen que el primero es el menor (lo dicen el `CHECK` y los
  comentarios del SQL; las pruebas ya usan `SmallerAccountId`/`LargerAccountId`). `StrangerMessage` puede leerse como
  un mensaje de chat de un desconocido.
- Pasada 4 (se pregunta): `GetFriendAccountId` (y con él `StrangerMessage`) solo lo usan 3 pruebas de `TestFriendship`.
  Producción obtiene los amigos en SQL (`FriendshipRepository.ListFriendAccountIds`) y el fake usa `AccountAId`/
  `AccountBId`. La R-15 no aplica porque ningún doble lo necesita.

**Decisiones del usuario:** quitar `GetFriendAccountId`, `StrangerMessage` y sus 3 pruebas; `AccountAId`/`AccountBId`
→ `SmallerAccountId`/`LargerAccountId`, con `HasColumnName("AccountAId"/"AccountBId")` en `FriendshipConfiguration`
(constantes `SmallerAccountIdColumn`/`LargerAccountIdColumn`). Cambian `FriendshipRepository` (consulta LINQ),
`FakeFriendshipRepository` y `TestFriendship` (dos pruebas pasan a `Constructor_LargerIdFirst_SetsSmallerAccountId` y
`…SetsLargerAccountId`). Una lectura sobre la base local confirmó el mapeo (`SmallerAccountId → AccountAId`) y que
`FriendRequest` mapea solo `RequesterId`, `RecipientId` y `RequestedAt`. Compila el servidor (carpeta aparte) y pasan
159 + 220 pruebas (3 menos de dominio). Commit `5e23ebe`, sin push.
Para `FriendshipRepository`: `Remove` repite el orden `Math.Min`/`Math.Max` del constructor, y sus variables locales
siguen siendo `accountAId`/`accountBId` (parámetros del procedimiento `usp_Friendship_Delete`). Se ven al revisarlo.

### 18. `src/Bastion.Domain/Friends/FriendshipRules.cs` (2026-11-10)

Dos constantes: `MaximumFriends = 100` (CU-21 RN-02) y `RequestLifetimeDays = 30` (CU-21 RN-08, CU-22 RN-05).
- Pasada 1: 2.4.1 en plural → **R-07**: `FriendshipPolicy`. El resto cumple.
- Pasada 2: los 30 días se repiten en la proyección de `FriendRequestRepository` usando la constante, sin literal.
- Pasada 3: nombres claros (dentro de `FriendshipPolicy`, «Request» es la solicitud de amistad).
- Pasada 4: las dos se usan en producción.

Cerrado sin preguntas (solo la R-07). Cambian `FriendRequest`, `FriendRequestRepository`, `FriendRequestService` y dos
archivos de pruebas. Compila el servidor (carpeta aparte) y pasan 159 + 220 + 136 pruebas. Commit `7b5fb83`, sin push.
Con esto termina la carpeta `Friends` del dominio; sigue `GameModes`.

### 19. `src/Bastion.Domain/GameModes/GameMode.cs` (2026-11-10)

Fila del catálogo `GameMode` (CLASSIC 9×9 con 2 jugadores y 10 muros; FOUR_PLAYERS 9×9 con 4 y 5; QUICK 7×7 con 2 y 6).
Solo la crea EF al leer la base; las pruebas la arman con inicializador de objeto (`RoomSamples`, `TestMatch`,
`FakeMatchStore`). Seis propiedades `{ get; init; }`.
- Pasada 1: §1, §3, §6 cumplen; §9 no aplica (sin métodos ni constructores). 2.11.1 cumple: los valores no cambian
  y usan `init`. R-01: sin `Equals`.
  - **Lectura L-12 (2.8.1):** «valores inmutables […] se declaran record». `GameMode` es inmutable, pero es una
    entidad de EF, y un record redefine `Equals` por valor, lo que choca con la R-01.
- Pasada 2: sin repetición; los valores viven en la base, y el dominio no los copia en constantes.
- Pasada 3: `WallsPerPlayer` es el número de muros del modo, que una sala privada puede cambiar
  (`RoomSettings.WallsPerPlayer`, y `MatchFormat` lo toma como valor inicial). Se pregunta si el nombre lo deja claro.
- Pasada 4: las seis propiedades se usan en producción.

**Decisiones del usuario:** sigue como `class` (**R-19**); `WallsPerPlayer` se queda. **Cerrado sin cambios.**

### 20. `src/Bastion.Domain/GameModes/GameModeCode.cs` (2026-11-10)

Enumeración de la clave del modo: `Classic`, `FourPlayers`, `Quick`. EF la guarda como `CLASSIC`, `FOUR_PLAYERS` y
`QUICK` (`UpperSnakeCaseEnumConverter`), que son también las claves de los diccionarios de recursos (D-21).
- Pasada 1: 2.15.1 (singular, sin `[Flags]`) y el resto cumplen. Pasada 2: los valores coinciden con las filas del
  catálogo y con la traducción de contratos (`RoomTranslator`), sin literales. Pasada 3: nombres claros.
  Pasada 4: los tres se usan (`RoomTranslator`, `MatchmakingRules.RankedGameModeCode`).

**Cerrado sin cambios.**

### 21. `src/Bastion.Domain/Matches/BoardCoordinates.cs` (2026-11-10)

`record BoardCoordinates(int ColumnIndex, int RowIndex)`: casilla del tablero en índices desde cero. La usan
`BoardLayout`, el cliente (`BoardPawn`, `BoardSceneLayout`, `MatchViewModel`) y sus pruebas.
- Pasada 1: valor inmutable como `record` (2.8.1); solo enteros → **R-16**, se queda posicional. Pasadas 2 a 4: sin
  repetición, nombres claros (dicen que son índices), se usa en producción.

**Cerrado sin cambios.**

### 22. `src/Bastion.Domain/Matches/BoardLayout.cs` (2026-11-10)

Casilla de salida de cada jugador según el tamaño del tablero y su turno (CU-13): `GetStartingCoordinates` (índices)
y `GetStartingSquare` (nombre de la casilla, como «e1», que guarda `Participation.CurrentSquare`).
- Pasada 1: §1, §3 (3.5.1: argumentos del `throw` uno por línea), §4.3.2 (`default` con
  `ArgumentOutOfRangeException` porque el turno llega como argumento), §6 cumplen; `return new BoardCoordinates(…)`
  con valores simples (R-14).
  - El mensaje literal del `throw` **no** incumple la 2.10.1: los ejemplos correctos del propio estándar (4.3.2 y
    1.3.1) escriben el mensaje literal en el `throw`. Pasa igual en unos 12 `default` de Client.Networking y Client.
  - **R-04 (incumplimiento):** `return string.Create(…, $"{column}{coordinates.RowIndex + FirstRow}")` suma dentro del
    `return`, y `char column = (char)(FirstColumn + coordinates.ColumnIndex);` suma y convierte en la misma línea →
    un paso por línea: `int columnCode = …; char column = (char)columnCode; int rowNumber = …;` y el `return` con
    variables.
- Pasada 2: el cliente (`BoardSceneLayout`) tiene su propia letra de columna `FirstColumnName = 'A'` para los nombres
  de las mallas 3D. Es otro dato (el nombre de una malla, en mayúscula), no la notación de la casilla.
- Pasada 3 (se pregunta): `int lastIndex = boardSize - FirstRow;` resta el número de la primera fila (1) para obtener
  el último índice, que solo es correcto porque las filas empiezan en 1. Quien lo lee tiene que deducirlo.
- Pasada 4: los dos métodos se usan en producción (`Participation`, cliente).

**Decisión del usuario:** `FirstRow` → `RowNumberOffset`. Se aplicó con la R-04 (cuatro líneas, un paso cada una).
Compila el servidor (carpeta aparte) y pasan 159 + 220 + 136 pruebas. Commit `dd8ffb3`, sin push.

### 23. `src/Bastion.Domain/Matches/Match.cs` (2026-11-10)

Entidad de EF de una partida (CU-09, CU-10, CU-17): la empiezan `StartRanked` y `StartPrivate`, que sientan a los
jugadores en orden de turno, y `Abandon` resuelve el abandono (con dos jugadores termina la partida; con cuatro, el
que se va pierde, pasa el turno y, si queda uno, ese gana). La usan `RankedMatchCreator`, `PrivateMatchCreator`,
`MatchAbandonmentService`, `MatchStore` y el cliente (las constantes de turno).
- Pasada 1: §1, §3, §4.1–4.6 (el `?:` de `Finish` elige entre dos valores sin efectos), §6, §10 cumplen. Los mensajes
  literales de los `throw` se admiten (los ejemplos del estándar los escriben igual).
  - **9.4.1 (incumplimiento):** `StartRanked` y `StartPrivate` son públicos y no comprueban `entrantsInTurnOrder`; la
    comprobación está en el privado `SeatEntrants` → `ThrowIfNull` al inicio de los dos públicos, y se quita del
    privado.
  - **5.3.1 (incumplimiento):** `ListActiveParticipations` encadena `ToList()` al final de la consulta → la consulta
    va en un `IEnumerable<Participation>` con nombre y se materializa con `new List<Participation>(…)`.
  - **L-04 (2.11.4):** `public IReadOnlyCollection<Participation> Participations => _participations;` es la navegación
    de EF (configurada con `UsePropertyAccessMode.Field`). La 2.11.4 no tiene excepción para frameworks.
  - **Lectura L-13 (R-04/R-12):** `return _participations.FirstOrDefault(participation => …);` es una sola llamada
    LINQ con una lambda. La R-12 habla de cadenas; el propio estándar devuelve `_players.Count(player => player.IsActive)`
    en su ejemplo correcto de la 2.11.4.
- Pasada 2 (se pregunta): `StartRanked` y `StartPrivate` son iguales salvo el `MatchType` (guardas, `new Match` y
  `SeatEntrants`). Un `Start(MatchType, …)` privado tendría cuatro parámetros (2.2.2).
- Pasada 3 (se pregunta): `bool Abandon(…)` no dice qué significa `true` (que la partida terminó;
  `MatchAbandonmentService` lo guarda como `isMatchOver`). `LastPlayerCount = 1` se lee como «cuántos jugadores hubo al
  final», y en `if (activeParticipations.Count > LastPlayerCount)` significa «queda más de uno».
- Pasada 4: todos los miembros públicos se usan en producción.

**Decisiones del usuario:** `Participations => _participations` se queda como excepción de EF (**R-20**);
`FindParticipation` se queda (**R-21**: un operador LINQ con una lambda de una línea es una llamada); `Abandon` pasa a
`void` y `MatchAbandonmentService` pregunta `match.Status == MatchStatus.Finished`; las dos fábricas se quedan;
`LastPlayerCount` → `LastStandingPlayerCount`. Se aplicaron también la 9.4.1 (`ThrowIfNull(entrantsInTurnOrder)` en
las dos fábricas, fuera de `SeatEntrants`) y la 5.3.1 (`ListActiveParticipations`). La prueba
`Abandon_FourPlayersFirstLeaves_KeepsMatchGoing` comprueba ahora `MatchStatus.InProgress`. Compila el servidor
(carpeta aparte) y pasan 159 + 220 + 136 pruebas. Commit `6227c25`, sin push.

### 24 a 31. Los tipos pequeños de `Matches` (2026-11-10)

- **24. `MatchEndReason.cs`** (`Goal`, `Timeout`, `Resignation`, `Draw`, `Abandonment`): cumple. El código solo usa
  `Abandonment`, pero los cinco están en el `CHECK` `CK_Match_EndReason` y tienen filas en la base de prueba, que EF
  lee. Se quedan (como `MessageChannel`). **Cerrado sin cambios.**
- **25. `MatchEntrant.cs`** (`record MatchEntrant(int AccountId, short? EloRating)`): solo tipos por valor → R-16,
  posicional. `EloRating` es nulo en las partidas privadas. **Cerrado sin cambios.** Para `PrivateMatchCreator`: la
  línea 44 encadena `.ToList()` (5.3.1).
- **26. `MatchFormat.cs`** (`record MatchFormat(GameMode GameMode, byte ClockMinutes)` con `WallsPerPlayer` que toma el
  del modo): **R-11**, porque `GameMode` es una referencia sin comprobar → constructor con `ThrowIfNull(gameMode)`,
  que también pone `WallsPerPlayer` (R-03). `GameMode` y `ClockMinutes` quedan `{ get; }`, y `WallsPerPlayer`
  `{ get; init; }` porque se cambia con inicializador (`PrivateMatchCreator`) y con `with` (`TestMatch`).
- **27. `MatchStatus.cs`** (`InProgress`, `PendingClose`, `Finished`): `PendingClose` no lo usa el código ni tiene
  filas. Está en el `CHECK` `CK_Match_Status` y lo pide el CU-18 RN-11 (una partida que no se puede cerrar queda
  pendiente de cierre y se reintenta), que todavía no está hecho. Se pregunta.
- **28. `MatchType.cs`** (`Ranked`, `Private`): cumple y se usan los dos. **Cerrado sin cambios.**
- **29. `Participation.cs`**: entidad de EF de un jugador en una partida; la crea `Match` (constructor `internal`).
  - Pasada 1: cumple §2 (`_pawnSymbolsInTurnOrder` en plural), §6, §9 (la 9.4.1 no aplica a `internal`;
    `GetPawnSymbol` comprueba el rango con `ThrowIfLessThan`/`ThrowIfGreaterThan`). **R-04:**
    `return _pawnSymbolsInTurnOrder[turnOrder - Match.FirstTurnOrder];` resta dentro del `return` → `int symbolIndex`.
  - **Lectura L-14:** en el constructor, `RemainingClockMilliseconds = (int)TimeSpan.FromMinutes(format.ClockMinutes).TotalMilliseconds;`
    junta una llamada, una propiedad y un cast, que es lo que la R-04 separa, pero no es un `return`.
  - Pasadas 2 a 4: sin repetición; nombres claros; las propiedades que nadie lee son columnas que EF guarda.
- **30. `ParticipationResult.cs`** (`Won`, `Lost`, `Draw`): `Draw` no lo usa el código, pero está en el `CHECK` y en las
  filas de prueba. **Cerrado sin cambios.**
- **31. `PawnSymbol.cs`** (`Blue`, `Red`, `Green`, `Yellow`): cumple; los cuatro se usan. **Cerrado sin cambios.**

**Decisiones del usuario:** `PendingClose` se queda (CU-18 RN-11, pendiente de implementar); la R-04 vale en cualquier
línea donde un cast se junte con una llamada o una operación (**R-23**). Se aplicaron la R-11 en `MatchFormat`, la R-04
en `GetPawnSymbol` y la R-23 en `Participation` (reloj) y en `Match` (`placement` y `turnOrderNumber`, archivo ya
cerrado). `var clockTime = TimeSpan.FromMinutes(…)` usa `var` porque el tipo está a la vista (3.4.1, IDE0007).
Compila el servidor (carpeta aparte) sin advertencias y pasan 159 + 220 + 136 pruebas. Commit `78c7011`, sin push.
Con esto termina la carpeta `Matches`; sigue `Matchmaking`.

### 32. `src/Bastion.Domain/Matchmaking/MatchSearch.cs` (2026-11-10)

Búsqueda de un jugador en la cola clasificatoria, en memoria (no es entidad de EF). Lleva la confirmación de presencia
(a los 15 min sale «¿sigues ahí?» con 60 s para responder, `05-pendientes.md`). La usan `MatchmakingQueue` y
`MatchSearchService`.
- Pasada 1: §1, §3, §6 cumplen; §9 (`ThrowIfNull(nickname)`); 2.8.1 `class` porque cambia; **2.9.1 cumple**: redefine
  `Equals`/`GetHashCode` por `AccountId`, su clave de negocio (la R-01 no aplica, no es de EF). 2.11.1: lo que no cambia
  es `{ get; }`, y lo demás `private set`.
  - **R-04 (incumplimiento, tres `return`):** `ShouldStartPresenceCheck` y `HasPresenceExpired` restan fechas dentro de la
    condición del `return`, y `StartPresenceCheck` devuelve `now + PresenceResponseWindow` → la resta o la suma va
    antes en una variable; en `HasPresenceExpired`, guarda `if (PresenceRequestedAt is not DateTime requestedAt)` (4.7.1).
- Pasada 2: sin repetición.
- Pasada 3 (se pregunta): `IsAvailable()` no dice para qué está disponible (es `Status == Searching`: se puede emparejar
  y no espera respuesta de presencia). `StartPresenceCheck` devuelve la hora límite de la respuesta, y el nombre no lo
  dice (como la R-22, pero no es un `bool`).
- Pasada 4: todos los miembros se usan (`MatchmakingQueue`).

### 33. `src/Bastion.Domain/Matchmaking/MatchmakingRules.cs` (2026-11-10)

Reglas de la cola: `PlayersPerMatch = 2`, los minutos y segundos de la presencia, el modo (`Classic`) y el reloj
(5 min) de la partida clasificatoria, y dos `TimeSpan`.
- Pasada 1: 2.4.1 en plural → **R-07**: `MatchmakingPolicy`. **2.3.2 cumple**: los `TimeSpan` públicos son
  `public static TimeSpan X { get; } = …`, que es lo que pide la regla (`LockoutPolicy` ya lo hace igual).
- Pasada 2: `PlayersPerMatch = 2` es el `PlayerCount` del modo `CLASSIC` en el catálogo; si cambiaran por separado,
  `Match.SeatEntrants` rechazaría la partida. Lo usa solo `MatchmakingQueue`: se pregunta al revisarlo (4.4.2).
- Pasada 3: nombres claros.
- Pasada 4 (se pregunta): `PresenceCheckMinutes` y `PresenceResponseSeconds` son públicas y solo las usa esta clase
  para armar los `TimeSpan`; afuera se usan los `TimeSpan`. En `LockoutPolicy`, la constante de horas es privada.

### 34. `src/Bastion.Domain/Matchmaking/SearchStatus.cs` (2026-11-10)

`Searching`, `AwaitingPresence`: cumple (2.15.1) y se usan los dos. **Cerrado sin cambios.**

**Decisiones del usuario (32 y 33):** `IsAvailable` → `IsSearching`; `StartPresenceCheck` sigue devolviendo la hora límite
(al revisar `MatchmakingQueue`, el resultado va en `DateTime presenceDeadline = …`); `PresenceCheckMinutes` y
`PresenceResponseSeconds` pasan a `private`. Se aplicaron con la R-04 (las tres variables `timeSinceConfirmation`,
`waitingTime` y `presenceDeadline`) y la R-07 (`MatchmakingPolicy`). Cambian `MatchmakingQueue`, `RankedMatchCreator` y
tres archivos de pruebas. Compila el servidor (carpeta aparte) y pasan 159 + 220 + 136 pruebas. Un solo commit para los
dos archivos, porque `MatchSearch` usa la clase renombrada: `a3463d8`, sin push. Termina `Matchmaking`; sigue
`Moderation`.

### 35 a 38. `Moderation` (2026-11-10)

- **35. `BannedWord.cs`**: catálogo de EF de solo lectura (`BannedWordId`, `Term`, `Scope`), con un único constructor
  privado. Cumple (R-19 `class`; 2.11.1 sin `set` público). La columna `Language` de la base no se mapea porque el
  filtro todavía no distingue idiomas (CU-20 RN-01). Los tres miembros se usan (`BannedWordRepository`). **Cerrado sin
  cambios.**
- **36. `BannedWordScope.cs`** (`Nickname`, `Chat`, `Both`): `Nickname` no lo usa el código (el filtro de nicknames del
  CU-02 no está hecho), pero está en el `CHECK` y en filas de la base. **Cerrado sin cambios.**
- **37. `Sanction.cs`**: entidad de EF de una sanción; producción solo la lee (`SanctionRepository.ListChatSanctions`)
  para saber si un jugador está silenciado (`ChatModerator`, `ChatMute`).
  - Pasada 1: §1, §3, §6 cumplen; §9 sin referencias. **2.11.4 → R-17:** `public bool IsPermanent => EndedAt is null;`
    es un valor calculado → método `IsPermanent()` (2.2.3).
  - **Lectura L-15 (R-05):** `return RevokedAt is null && (IsPermanent || EndedAt > now);` mezcla `&&` y `||` con
    paréntesis; la R-05 admite condiciones cortas.
  - Pasada 2: sin repetición.
  - Pasada 3 (se pregunta): `EndedAt` está en pasado, pero es la fecha en que **termina** la sanción, aunque sea
    futura; `ChatMute` la llama `EndsAt`. La columna de la base es `EndedAt`.
  - Pasada 4 (se pregunta): `Revoke` solo lo usa una prueba (`TestSanction`). El constructor público solo lo usan las
    pruebas y los dobles: la sanción que arma no se podría guardar, porque le faltan columnas `NOT NULL`
    (`ModeratorId`, `SanctionType`, `Reason`). Producción nunca crea sanciones.
- **38. `SanctionScope.cs`** (`Account`, `Chat`): `Account` solo lo usan las pruebas, pero está en el `CHECK` y en filas
  de la base. **Cerrado sin cambios.**

**Decisiones del usuario (37):** `IsInEffectAt` con guardas, una pregunta por `if` (**R-24**); `EndedAt` → `EndsAt` con
`HasColumnName("EndedAt")` (constante `EndsAtColumn`); se quita `Revoke` y su prueba, y el constructor se queda (R-15:
es la única forma de que pruebas y dobles armen una sanción). Se aplicó la R-17 (`IsPermanent()`). Cambian
`SanctionConfiguration`, `ChatMute` y `TestSanction`. Una lectura de la base local confirmó `EndsAt → EndedAt`, y que
las sanciones 1 y 4, revocadas, no están en vigor. Compila el servidor (carpeta aparte) y pasan 158 + 220 pruebas (una
menos de dominio). Commit `3288d60`, sin push. Termina `Moderation`; sigue `Rooms`.

### 39 a 47. `Rooms` (2026-11-10)

- **39. `FailedCodeAttempts.cs`**: intentos fallidos de código de sala de un jugador (5 en 5 min); lo usa
  `RoomRegistry`.
  - **2.4.1 (incumplimiento):** el nombre está en plural (se pregunta el nuevo).
  - **R-17:** `public bool HasAttempts => _attemptTimes.Count > 0;` → método `HasAttempts()`.
  - **R-04:** `return _attemptTimes.Peek() + RoomRules.FailedCodeWindow - now;` → un paso por línea.
  - Pasada 2 (se pregunta): `_attemptTimes.Peek() + FailedCodeWindow` (cuándo caduca el intento más viejo) se repite en
    `GetRetryDelay` y en la condición del `while` de `ForgetOldAttempts`.
- **40. `RoomRules.cs`**: código de sala (6 caracteres), muros 1–20, relojes 3/5/10 (CU-09, `CK_Room_Settings`) e
  intentos fallidos.
  - **2.4.1 → R-07:** `RoomPolicy`, y su prueba `TestRoomPolicy`.
  - **5.2.1 (incumplimiento):** `code.All(character => CodeAlphabet.Contains(character))` solo reenvía el argumento →
    `code.All(CodeAlphabet.Contains)`.
  - Pasada 4: `FailedCodeWindowMinutes` es pública y solo la usa la clase para armar el `TimeSpan` → `private`, como en
    `MatchmakingPolicy` (D-07). `MinimumWallsPerPlayer` solo la usa la clase; `MaximumWallsPerPlayer`, la clase y una
    prueba (se pregunta).
  - Pasada 2 (se pregunta, candidato anotado): `CodeAlphabet` (con L) y `FriendCodePolicy.Alphabet` (sin L) son
    distintos, y cada uno coincide con su base: `CK_Room_Code` (`[A-HJ-NP-Z2-9]`) y `05_create_friends.sql`. Además,
    las salas validan con `All`/`Contains` y los códigos de amigo con un `Regex`.
- **41. `RoomIdentity.cs`** (`record (int RoomId, string Code)`) y **43. `RoomOpening.cs`** (`record (string Code, int
  HostId, DateTime OpenedAt)`): **R-11**, constructor con `ThrowIfNull(code)`.
- **42. `RoomMember.cs`**: miembro de una sala en espera (`class`, cambia de asiento y de «listo»). Cumple. Pasada 3 (se
  pregunta): `MarkReady(bool isReady)` se lee raro con `false` (`member.MarkReady(false)`), y `WaitingRoom` llama la
  misma acción `SetReady`.
- **44. `RoomSettings.cs`** (`record (GameMode, byte WallsPerPlayer, byte ClockMinutes)` con `IsValid()`): **R-11**,
  `ThrowIfNull(gameMode)`. `TestRoom` lo copia con `with { WallsPerPlayer = … }` → `WallsPerPlayer { get; init; }`.
  `IsValid` devuelve tres condiciones con `&&` (R-05).
- **45. `RoomStatus.cs`** (`Open`, `InMatch`, `Closed`): cumple; los tres se usan y están en `CK_Room_Status`.
  **Cerrado sin cambios.**
- **46. `Room.cs`**: entidad de EF de la sala (`Open`, `ChangeSettings`, `Close`, `StartMatch`, `FinishMatch`). Cumple
  §1–§9 (9.4.1, R-14, mensajes literales admitidos). Pasada 3 (se pregunta): `HostId` (y `RoomOpening.HostId`) frente a
  `WaitingRoom.HostAccountId` para lo mismo; la columna es `HostId`.
- **47. `WaitingRoom.cs`**: sala en espera en memoria (no es de EF).
  - **R-17:** `public int SeatCount => Settings.GameMode.PlayerCount;` es un valor calculado → método. Fuera del
    dominio, `RoomSnapshot` tiene la misma propiedad (se ve en su revisión).
  - **Lectura L-16 (2.11.4):** `public IReadOnlyList<RoomMember> Members => _members;` expone un campo con `=>`, y no es
    de EF (la R-20 no lo cubre).
  - Pasada 4 (se pregunta): `_kickedAccountIds` nunca recibe un valor (no hay método para expulsar; el CU-12 «Expulsar»
    es Must y no está hecho), así que `HasKicked` siempre da `false`, y la rama `RoomRejection.Kicked` de
    `RoomRegistry` nunca se cumple. `HasMember` es público y solo lo usa la clase (`Admit`).
  - Fuera del archivo: `RoomKeeper` (línea 69) repite la cuenta de `CanSeatAllMembers`.

**Decisiones del usuario (39 a 47):** `FailedCodeAttemptHistory`; `GetOldestAttemptExpiry()` privado (con la R-04
aplicada también a su `return`, que la vista previa traía con una suma); alfabetos separados; los límites de muros se
quedan públicos y `HasMember` pasa a `private`; `HostId` → `HostAccountId` en `Room` y `RoomOpening`
(`HasColumnName("HostId")`); `MarkReady` → `SetReady`; `Members => _members` se queda (**R-26**); `_kickedAccountIds` se
queda y el CU-12 se anota en `05-pendientes.md` (junto con el CU-18 RN-11 de `PendingClose`). Se aplicaron también la
R-07 (`RoomPolicy`), la R-11 (tres records), la R-17 (`HasAttempts()` y el privado `GetSeatCount()`, que solo usa la
clase), la 5.2.1 y la R-25 (`FailedCodeWindowMinutes` privada). Una lectura de la base local confirmó
`HostAccountId → HostId`. Compila el servidor (carpeta aparte) y pasan 158 + 220 + 136 pruebas. Commit `28d73c2`, sin
push. Termina `Rooms`; siguen `Sessions`, `Statistics` y `Text`.

### 48 a 52. `Sessions`, `Statistics` y `Text` (2026-11-10)

- **48. `ClientConnection.cs`** (`record (string IpAddress, string DeviceFingerprint, string ClientVersion)` y
  `MaximumIpAddressLength = 45`): **R-11**, constructor con tres `ThrowIfNull`. La constante la usan
  `SessionConfiguration` y `AccessLogConfiguration` (4.4.2); los largos de huella y versión solo los usa
  `SessionConfiguration` y viven ahí. Nombres claros.
- **49. `Session.cs`**: entidad de EF de una sesión de 24 h. Cumple (R-03, R-05 en `IsActiveAt`, R-02 en `TokenHash`).
  `MaximumLifetimeHours` la usan dos pruebas, así que no es un caso de la R-25 y se queda pública (el cambio se intentó
  y se deshizo al no compilar las pruebas). Pasada 4: `LastUsedAt` y `EndedAt` son columnas que EF lee
  (`IsActiveAt` usa `EndedAt`), pero ningún código las actualiza: la base dice que `LastUsedAt` se actualiza cada minuto
  y que `EndedAt` marca el cierre explícito. El cierre de sesión y el latido no están hechos. **Cerrado sin cambios.**
- **50. `SessionTicket.cs`**: `sealed class` inmutable (hash del token y hora de emisión), no es de EF →
  **2.8.1 (incumplimiento):** pasa a `sealed record` con el mismo constructor.
- **51. `ModeStatistic.cs`**: entidad de EF de solo lectura (Elo por modo); `DefaultEloRating` la usan los dos
  creadores de partidas. **Cerrado sin cambios.**
- **52. `Text/TextPattern.cs`**: creada en esta revisión (R-08). Cumple; el `var regex = …; return regex;` se admite
  (la R-14 también permitiría devolver el `new` directamente). **Cerrado sin cambios.**

Compila el servidor (carpeta aparte) y pasan 158 + 220 + 136 pruebas. Commit `cd96587`, sin push.
**Con esto termina la capa `Bastion.Domain`** (52 archivos). Sigue `Bastion.Server.Application` (130 archivos), en el
orden de sus carpetas: `Accounts`, `Auditing`, `Chat`, `Common`, `Friends`, `Matches`, `Matchmaking`, `Moderation`,
`PrivateChat`, `Rooms`, `Security`, `Sessions`. Pendientes anotados para esa capa (tabla «Candidatos a reutilizar» y
bitácoras): búsqueda por código de amigo repetida, `PlayersPerMatch` frente al catálogo, `presenceDeadline` en
`MatchmakingQueue`, `.ToList()` encadenados (5.3.1) en `PrivateMatchCreator`, `RoomKeeper` frente a
`CanSeatAllMembers`, `RoomSnapshot.SeatCount` con `=>`, `ListRecent(count)` del lobby, `readMessages` en `MarkRead`,
y `SignedInPlayer`/`SignedInSession`/`ToSignedInSession` (R-10).
