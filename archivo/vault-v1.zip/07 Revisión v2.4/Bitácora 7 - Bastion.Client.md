---
tags: [revision-v2-4]
---
# Bitácora 7 - Bastion.Client
Volver a [[Índice de la revisión v2.4]]

Son 108 archivos con 10 260 líneas, sin contar `Strings.Designer.cs`, que se genera solo. Van del 386 al 493, por
carpeta:

| Carpeta | Archivos |
| --- | --- |
| raíz (`BastionGame`, `Program`) | 386–387 |
| `Controls` | 388–392 |
| `Localization` | 393–398 |
| `Screens` (raíz) | 399–404 |
| `Screens/Login` | 405–407 |
| `Screens/MainMenu` (raíz) | 408–414 |
| `Screens/MainMenu/Chat` | 415–434 |
| `Screens/MainMenu/Friends` | 435–457 |
| `Screens/Matches` (con `Scene`) | 458–476 |
| `Theme` | 477–493 |

Datos generales:
- **Reglas propias de la capa:** 3.7.1 (inicializador de objeto en los controles de Gum, con IDE0017), la excepción de
  enlace de datos de la 2.11.4 (MVVM), 9.7.1 (`async void` solo en manejadores, todo dentro de un `try`) y 10.4.1.
- **6.3:** solo tres archivos tienen los `using` fuera de orden: `BastionGame`, `MainMenuView` y `VersusViewModel`.
- **Nombres de manejadores:** 32 archivos usan `Handle…`; solo `BastionGame.OnClientSizeChanged` y
  `PickerSkin.OnListItemsChanged` usan `On…`, que en el proyecto es el nombre del método que lanza un evento.

### 386 y 387. `BastionGame` y `Program` (2026-11-11)

- **Cumple:**
  - **10.2.1 y 10.4.1:** `BastionGame` es la inicialización del juego, así que puede crear `ServerConnection`,
    `LanguageService` y `ScreenNavigator` y usar `TimeProvider.System`.
  - **5.1.2:** se suscribe a `ClientSizeChanged` con un grupo de método y se desuscribe en `Dispose`.
  - **2.6.3:** `_screenNavigator` y `_boardScene` son anulables y se crean en `Initialize` y `LoadContent`, cuando
    MonoGame ya tiene el dispositivo gráfico.
  - **2.10.1:** cada tamaño y cada escala están en constantes.
- **Aplicado sin preguntas (reglas decididas, sin commit):**
  - **6.3:** los `using` de `Bastion.*` van antes que los de `Gum` y `Microsoft.Xna.Framework`, como se corrigió en
    `AccountService`.
  - **D-06:** `_serverConnection` se creaba en la declaración y `_graphics` en el constructor. Ahora los dos se crean en
    el constructor.
  - **R-47:** `DrawShownMatchBoard` baja después de la cadena de `Initialize` (`OnClientSizeChanged`,
    `KeepMinimumWindowSize` y `ApplyUiScale`), porque lo usa `Draw`.
- **Verificación:** `Client` compila sin avisos de código. El juego no se ejecutó, porque es una ventana.
- **Pregunta 1 (R-52, pendiente desde 230):** el `Program` del cliente no registra la excepción que termina el proceso.
  El servidor ya lo hace con un manejador de `AppDomain.CurrentDomain.UnhandledException` en Fatal.
- **Pregunta 2 (pasada 3):** `OnClientSizeChanged` es un manejador. En el proyecto, `On…` nombra al método que lanza un
  evento (`OnPlayerDisconnected`, `OnRoomUpdated`), y los manejadores se llaman `Handle…`.

**Preguntas (386 y 387):**
1. La R-52 en el cliente (recomendado: A, un `ILog`, `AppDomain.CurrentDomain.UnhandledException += LogUnhandledException`
   justo después de `ConfigureLogging()`, y un `LogUnhandledException` que registra en Fatal "The game stopped because of
   an unhandled exception."; B, no).
2. `OnClientSizeChanged` → `HandleClientSizeChanged` (recomendado: A, y lo mismo con `PickerSkin.OnListItemsChanged`
   cuando se revise `Theme`; B, dejarlos).

**Respuesta del usuario (2026-11-11):** «Sí, A en ambas».
- **Aplicado:**
  - `Program` tiene `_logger`, se suscribe a `AppDomain.CurrentDomain.UnhandledException` justo después de
    `ConfigureLogging()` y tiene `LogUnhandledException`, con Fatal "The game stopped because of an unhandled
    exception.". Es la misma forma del servidor.
  - `HandleClientSizeChanged` en `BastionGame`. `PickerSkin.OnListItemsChanged` cambia al revisar `Theme`.
- **Verificación:**
  - `Client` compila sin avisos de código;
  - pasan las 136 pruebas del cliente.
  - No se forzó una caída del juego para ver el registro Fatal. La misma forma se comprobó en el servidor (230).

**Commit de la raíz del cliente:** `32cbc25` (2026-11-11), en `review-standard-v2.4-host`, sin push.

### 388 a 392. `Controls` (2026-11-11)

Archivos: `LanguagePicker`, `ModalLayer`, `NoticeBox`, `PasswordField` y `TextField`.

- **Cumple:**
  - **4.3.2 (nota pendiente de `Client.Networking`):** el `default` de `PickFill` y `PickAccent` devuelve
    `Palette.Card` y `Palette.Border` para `NoticeTone.None`. Entra en la excepción de presentación: son miembros con
    nombre, neutros y distintos de los otros casos. `PickAccent` es, letra por letra, el `SelectBorderColor` del ejemplo
    correcto del estándar. Queda resuelta la mitad de la nota «valores por omisión de `NoticeBox`».
  - **2.11.4 («Alcance»):** los `get =>` y `set =>` de `HasError`, `Title` y `Message` son accesores que reenvían.
  - **5.1.2:** `LanguagePicker` se suscribe con un grupo de método.
  - **Pasada 2 (4.4.1):** `PasswordField` y `TextField` repiten las mismas líneas, pero heredan de bases distintas de
    Gum (`PasswordBox` y `TextBox`) y la lógica común ya vive en `FieldSkin`.
  - **`Dock(Gum.Wireframe.Dock.Fill)`:** el nombre completo es obligado. Dentro de una clase que hereda de `Panel`,
    `Dock` es el método heredado y tapa al tipo. Pasa lo mismo en las cuatro pantallas que lo usan.
- **Aplicado sin preguntas (reglas decididas, sin commit):**
  - **3.3.1 (también en `05-pendientes.md`):** los dos inicializadores de una línea de `NoticeBox` (`StackPanel` y
    `Label`) pasan a varias líneas. La regla pide `new` y el tipo en una línea y la llave en la siguiente. En `src`
    solo quedan inicializadores de una línea en `Client`, en 19 archivos de `Screens`; se corrigen al revisar cada
    carpeta.
  - **R-23:** `((LabelVisual)_title.Visual).Color = accent;` y `style.ApplyTo((LabelVisual)label.Visual);` guardan
    primero el cast en `titleVisual` y `labelVisual`.
- **Verificación:** `Client` compila sin avisos de código. Pasan las 514 pruebas (136 + 158 + 220). El juego no se
  abrió.
- **Pregunta 1 (2.10.1):** `ModalLayer` llama `Shapes.CreateRounded(Palette.Overlay, 0)`. El `0` es el único radio
  literal del cliente; `NoticeBox` tiene su `Radius`.
- **Pregunta 2 (10.1.1):** `GumService.Default` se lee fuera de la raíz de composición. El estándar llama servicio
  externo a lo que «guarda estado compartido entre clases» o hace entrada o salida. Hay cuatro usos:
  - `LanguagePicker`: `LocalizationService`, que guarda el idioma actual. `LanguageService` ya lo recibe por
    constructor desde `BastionGame`.
  - `ModalLayer`: `ModalRoot`, el contenedor de los diálogos.
  - `FriendCodeFooter`: `Clipboard`, que es entrada y salida con el sistema operativo.
  - `ScreenNavigator`: `Root` y `ModalRoot`.
- **Pregunta 3 (suscripción):** `LanguagePicker` nunca se desuscribe de `CurrentLanguageChanged`, y `LocalizationService`
  vive todo el juego. Hoy `ShowLogin` solo se llama una vez, al arrancar. Después de entrar al menú, el selector
  queda suscrito y retiene la pantalla de inicio. Pero ya nada cambia el idioma, así que el manejador no vuelve a
  correr. El estándar no exige desuscribirse, solo un grupo de método si hay que hacerlo (5.1.2).

**Preguntas (388 a 392):**
1. El radio `0` de `ModalLayer`:
   - recomendado, A: `private const float OverlayCornerRadius = 0;`, como `NoticeBox.Radius`;
   - B: dejar el `0`;
   - C: `Shapes.CreateFilled(Color)` en `Theme`.
2. `GumService.Default` y la 10.1.1:
   - recomendado, A: `Root` y `ModalRoot` son el árbol visual del framework y se quedan. `LocalizationService` y
     `Clipboard` son servicios y se inyectan. Para `LanguagePicker`, `ILanguageService` ganaría un evento
     `LanguageChanged`, que `LanguageService` lanza después de cambiar el idioma de Gum. El selector lo recibiría por
     constructor, y `LoginView` también, desde `ScreenNavigator`, que ya tiene `_languages`. Toca `Localization` y
     `Login` antes de su turno, y no se puede comprobar sin abrir el juego;
   - B: inyectar todo, también las raíces. `ScreenNavigator` ya tiene 3 parámetros, así que necesitaría un DTO;
   - C: dejarlo todo y anotar `GumService.Default` como el framework, igual que el `ILog`. Se aparta de la letra de la
     10.1.1.
3. La suscripción que no se cancela:
   - recomendado, A: dejarla y anotarla para cuando haya un camino de vuelta a la pantalla de inicio (pasada 4: hoy no
     existe);
   - B: cancelarla ya. Hace falta que alguien libere la vista, y `ScreenNavigator` hoy solo libera los modelos de
     vista.

**Justificación de la pregunta 2, pedida por el usuario (2026-11-11):** ¿por qué separar las raíces de los servicios?
- **La separación no es obligatoria.** Fue un criterio propio para bajar el costo, no una estrategia con nombre.
  Medida contra las fuentes, solo la mitad se sostiene.
- **Razones que se usaron:**
  - Gum se construye sobre raíces globales. Por reflexión, `FrameworkElement.ModalRoot` y `PopupRoot` son `static`.
    La documentación del paquete (`GumCommon.xml` 2026.10.1.1) las llama «global roots», y el `ListBox` del `ComboBox`
    y el `Tooltip` de Gum usan `PopupRoot`. Inyectar `ModalRoot` en `ModalLayer` no quita el global del programa.
  - La inyección sirve para poder sustituir la dependencia. Nadie sustituye el árbol visual, y las pruebas del cliente
    solo usan modelos de vista y `Networking`, nunca controles ni vistas.
  - Costo: cuatro vistas crean `ModalLayer`, y `ScreenNavigator` ya tiene 3 parámetros.
- **Criterios con que se midió:**
  - **10.1.1:** servicio externo es lo que hace entrada o salida, guarda estado compartido entre clases o no es
    determinista.
  - **Seemann (2006):** una dependencia volátil necesita preparar el entorno, está en desarrollo, no está en todas las
    máquinas o no es determinista. Las estables, como las del framework, no hace falta aislarlas.
  - **Seemann (2019):** el Ambient Context (acceso global estático a una dependencia) pasó a ser antipatrón en la
    segunda edición del libro. Estaba en la primera porque la BCL lo usa (`CultureInfo.CurrentCulture`,
    `HttpContext.Current`).
  - **Microsoft (2026), «Recommendations»:** evitar el acceso estático a los servicios.
- **Resultado por uso:**

| Uso | 10.1.1 | Seemann (2006) | Conclusión |
| --- | --- | --- | --- |
| `Clipboard` | entrada y salida | volátil (necesita el portapapeles del sistema) | se inyecta; los criterios coinciden |
| `LocalizationService` | estado compartido (el idioma actual) | estable (en memoria y determinista) | se inyecta por la 10.1.1 y por coherencia con `LanguageService` |
| `Root` y `ModalRoot` | estado compartido | volátil (necesita `GumService.Initialize` con la ventana) | por la letra, se inyectan; dejarlas es una excepción |

- **Corrección de la opción A:** dejar las raíces no lo respalda ninguna fuente. Es una excepción, de la misma
  naturaleza que la C pero más chica, y habría que escribirla como regla con su porqué.
- **Fuentes:**
  - Microsoft. (2026). *.NET dependency injection guidelines*. Microsoft Learn.
    https://learn.microsoft.com/en-us/dotnet/core/extensions/dependency-injection-guidelines (sección
    «Recommendations»; actualizada el 2026-03-30).
  - Seemann, M. (2006, 24 de agosto). *Volatile dependencies* [Entrada de blog archivada]. Microsoft Learn.
    https://learn.microsoft.com/en-us/archive/blogs/ploeh/volatile-dependencies (párrafos 2 a 8).
  - Seemann, M. (2019, 21 de enero). *Some thoughts on anti-patterns*. ploeh blog.
    https://blog.ploeh.dk/2019/01/21/some-thoughts-on-anti-patterns/ (sección «Ambient Context»).
  - Gum. (2026). *GumCommon* (versión 2026.10.1.1) [Documentación XML del paquete NuGet FlatRedBall.GumCommon]
    (miembros `FrameworkElement.PopupRoot`, `ModalRoot` y `AdditionalPopupRootPairs`).
- **Huecos:**
  - Las secciones 1.3.1, 1.3.2 y 5.3 de Seemann y van Deursen (2019) no se ven en la vista previa de Manning.
  - La página de 2006 no muestra el nombre del autor. Se atribuye a Seemann por el blog `ploeh`, que es el suyo.

**Propuesta sin antipatrón para la pregunta 2, pedida por el usuario (2026-11-11), sin aplicar:**
- **Idea:** solo dos lugares tocan los globales de Gum: `BastionGame`, que es la raíz de composición, y dos gateways que
  adaptan Gum. Todas las demás clases reciben interfaces del proyecto por constructor.
- **Tipos nuevos (carpeta `Platform`):**
  - `IModalHost` (`OpenModal`, `CloseModal`) e `IScreenHost : IModalHost` (`ShowScreen`);
  - `GumScreenHost`, que recibe `Root` y `ModalRoot` y es el único que toca `InteractiveGue.CurrentInputReceiver`;
  - `IClipboard` (`TryCopyText`) y `GumClipboard`, que recibe el `IGumClipboard?` de Gum;
  - `ILanguageService.LanguageChanged`, que `LanguageService` lanza después de cambiar el idioma de Gum.
- **Comprobado:** `GumService.Default.Root` y `ModalRoot` son `InteractiveGue` y `Clipboard` es `IGumClipboard`
  (`SetText`, `GetText`). Gum lanza `CurrentLanguageChanged` dentro del setter de `CurrentLanguage`, así que el evento
  nuevo corre después de que Gum retraduce, en el mismo orden que hoy (prueba `gum-roots-probe` en el scratchpad).
- **Consumidores:**
  - `LanguagePicker(ILanguageService)` y `ModalLayer(IModalHost)`;
  - `FriendsPanelViewModel(session, clients, IClipboard)` con `CopyOwnCode()`; `FriendCodeFooter` solo lo llama;
  - `LoginView(LoginViewModel, ILanguageService, IModalHost)`;
  - `MainMenuView(MainMenuScreenModels, IModalHost)` y `MatchView(MatchScreenModels, IModalHost)`;
  - `ScreenNavigator(ServerConnection, LocalServices, IScreenHost)`.
- **Límite de 3 parámetros (2.2.2):** tres records con constructor explícito (R-09, R-11), como los `SocialClients` y
  `ChatClients` que ya existen:
  - `LocalServices(ILanguageService, IClipboard, TimeProvider)`;
  - `MainMenuScreenModels`, con los 3 modelos de vista del menú;
  - `MatchScreenModels`, con los 3 de la partida.
- **Lo que sigue siendo estático, y por qué no es el antipatrón:**
  - `BastionGame` lee `GumService.Default` porque es la raíz de composición (Seemann, 2011; 10.2.1);
  - `GumScreenHost` y `GumClipboard` reciben tipos concretos de Gum porque son los gateways que lo adaptan (Fowler,
    2003). Es la misma razón de la excepción de adaptadores de la 10.1.1, aplicada al cliente por analogía;
  - los controles de Gum siguen usando `PopupRoot` por dentro, pero eso es el framework, no código del proyecto.
- **Punto débil:** `LocalServices` es un objeto de parámetros. Seemann (2010) dice que eso solo mueve los parámetros, y
  que lo mejor es un Facade Service con comportamiento propio. Cumple la 2.2.2 y sigue el precedente del proyecto.
- **Alternativa P2:** en lugar de `LocalServices`, partir `ScreenNavigator` en constructores de pantalla (Facade
  Service). Se acerca más a Seemann, pero rediseña el navegador.
- **Pregunta 3:** con `GumScreenHost` reemplazando las pantallas, puede liberar la pantalla saliente si es
  `IDisposable`. `LoginView` liberaría el selector, que se desuscribe de `LanguageChanged`. Es opcional.
- **Alcance:** unos 15 archivos de `Controls`, `Localization`, `Screens` y `BastionGame`, más
  `TestFriendsPanelViewModel` y una prueba nueva de `CopyOwnCode`. Va en un solo commit, porque los constructores
  cambian en cadena. No se compiló todavía. Los diálogos y el selector solo se pueden ver abriendo el juego.
- **Fuentes nuevas:**
  - Fowler, M. (2003). *Gateway*. En *Catalog of Patterns of Enterprise Application Architecture*.
    https://martinfowler.com/eaaCatalog/gateway.html
  - Microsoft. (2024). *Ioc* [MVVM Toolkit]. Microsoft Learn.
    https://learn.microsoft.com/en-us/dotnet/communitytoolkit/mvvm/ioc (sección «What about viewmodels?»).
  - Seemann, M. (2010, 2 de febrero). *Refactoring to aggregate services*. ploeh blog.
    https://blog.ploeh.dk/2010/02/02/RefactoringtoAggregateServices/ (párrafo «I call such a type a Facade Service»).
  - Seemann, M. (2011, 28 de julio). *Composition Root*. ploeh blog. https://blog.ploeh.dk/2011/07/28/CompositionRoot/
- **Hueco:** la página de Fowler sobre *Introduce Parameter Object* solo tiene el diagrama, sin texto. Para el objeto de
  parámetros se cita la 2.2.2 del estándar.

**Propuesta D1 para la pregunta 2, más simple, pedida por el usuario (2026-11-11), sin aplicar:**
- **Técnica:** inversión de control (Fowler, 2005) y Humble Object (Fowler, 2020), con gateways (Fowler, 2003) en la
  raíz de composición (Seemann, 2011). Las pantallas declaran sus diálogos y una sola clase los muestra en Gum.
- **Piezas:**
  - `ScreenView : Panel`, clase base de las cuatro pantallas. Su constructor hace `Dock(Fill)` y tiene
    `AddDialog(content, viewModel, isOpenProperty)` y `Dialogs`. Quita los cuatro `Create…Layer` casi iguales, sus
    cuatro campos y los cuatro `Dock(Gum.Wireframe.Dock.Fill)` (4.4.1). `Panel` está exceptuado en la 2.14.3.
  - `ModalLayer` ya no toca Gum: su `IsOpen` lanza `IsOpenChanged`.
  - `IScreenHost` y `GumScreenHost` son la única clase, aparte de `BastionGame`, que toca `Root`, `ModalRoot` y
    `CurrentInputReceiver`. `ShowScreen(ScreenView)` quita la pantalla anterior, se suscribe a los diálogos de la nueva
    con grupo de método (5.1.2), coloca los que ya estén abiertos y se desuscribe al cambiar de pantalla.
  - `IClipboard` y `GumClipboard`: `FriendsPanelViewModel` recibe el portapapeles y tiene `CopyOwnCode()`. El pie solo
    reenvía el clic, que es lo que pide el Humble Object.
  - `ScreenNavigator(ServerConnection, LocalServices, IScreenHost)`. `LocalServices` (idioma, portapapeles y reloj) es
    el único objeto de parámetros.
- **`LanguagePicker`, verificado:**
  - la documentación de Gum 2026.10.1.1 dice que `ListBoxItem.UpdateToObject` no aplica localización;
  - en `main` de Gum, `ComboBox` muestra su texto con `TextNoTranslate`, y `RefreshLocalization` solo retraduce
    elementos con clave guardada;
  - los nombres de idioma son autónimos y solo están en `Strings.resx`, así que nunca cambian.
  - **L0:** si al abrir el juego los nombres siguen bien sin el refresco, se borra la suscripción y no queda ninguna
    dependencia de Gum en el selector. La pregunta 3 desaparece.
  - **L1:** si hace falta, `ILanguageService.LanguageChanged` y `LanguagePicker(ILanguageService)`.
  - El commit `4ab3f67`, que trajo el refresco, no explica por qué. Ya usaba la misma versión de Gum.
- **Alternativas:**
  - **D2:** la P1 anterior (`IModalHost` en `ModalLayer` y en las vistas, con dos DTO de modelos de vista);
  - **D3:** el navegador lanza un evento y el host se suscribe en `BastionGame`;
  - **D4:** un servicio de diálogos en los modelos de vista (sin fuente verificada: la documentación de Prism dio 404);
  - **D5:** solo Humble Object, con la API de instancia de Gum (`AddToRoot`). Esa API resuelve `IGumService.Default`
    por dentro, así que el global sigue en nuestras llamadas.
- **Fuentes nuevas:**
  - Fowler, M. (2005, 26 de junio). *Inversion of control*. martinfowler.com.
    https://martinfowler.com/bliki/InversionOfControl.html
  - Fowler, M. (2020, 29 de abril). *Humble object*. martinfowler.com. https://martinfowler.com/bliki/HumbleObject.html
  - Gum. (2026). *MonoGameGum* (versión 2026.10.1.1) [Documentación XML del paquete NuGet Gum.MonoGame] (miembro
    `ListBoxItem.UpdateToObject`).
  - vchelaru. (2026). *Gum* [Código fuente]. GitHub. https://github.com/vchelaru/Gum (rama `main`, consultada el
    2026-11-11: `MonoGameGum/Forms/Controls/ComboBox.cs`, `ListBoxItem.cs` y `GumService.cs`).
- **Huecos:**
  - la rama `main` de Gum no es la versión 2026.10.1.1; para `ListBoxItem` la confirma la documentación instalada;
  - las páginas de Fowler de *Pull Up Method* y *Extract Superclass* solo tienen diagrama. Para quitar la repetición se
    cita la 4.4.1;
  - no se compiló, y el selector y los diálogos solo se pueden ver abriendo el juego.

**Respuesta del usuario (2026-11-11):** «Sí, D1».
- **Aplicado (sin commit):**
  - `Screens/ScreenView` (base de `LoginView`, `MainMenuView`, `MatchView` y `VersusView`), `Screens/IScreenHost`,
    `Screens/IClipboard` y `Screens/LocalServices`. Las interfaces viven con quien las usa; las implementaciones de Gum,
    en `Platform/GumScreenHost` y `Platform/GumClipboard`. Así `Platform` depende de `Screens`, sin ciclo.
  - `ModalLayer` solo lanza `IsOpenChanged`.
  - `ScreenNavigator(ServerConnection, LocalServices, IScreenHost)`. Su `ShowScreen` ya no recibe un `Func`: lo tenía
    para construir la pantalla después de limpiar los diálogos (commit `2fe1026`, el diálogo de rival que abandona
    durante la cuenta atrás). Ahora `GumScreenHost` limpia primero y después coloca los diálogos que ya llegan abiertos.
    La vista vieja sale antes de liberar sus modelos de vista, como antes.
  - `FriendsPanelViewModel` recibe `IClipboard` y `MarkCodeCopied` pasa a `CopyOwnCode`, con el Warn que tenía el pie.
  - **L0:** `LanguagePicker` ya no se suscribe al cambio de idioma (−23 líneas).
  - `BastionGame` crea `GumClipboard`, `LocalServices` y `GumScreenHost`. Fuera de él, el único acceso estático a Gum es
    `InteractiveGue.CurrentInputReceiver`, dentro de `GumScreenHost`.
  - Pruebas: `FakeClipboard` y dos pruebas de `CopyOwnCode` (portapapeles disponible y sin portapapeles).
- **Verificación:**
  - `Client` compila sin avisos de código;
  - pasan las 516 pruebas (138 + 158 + 220);
  - los archivos nuevos quedaron en LF.
- **Falta comprobar en el juego (antes del commit):**
  - L0: cambiar de idioma en el inicio de sesión y ver que el selector y su lista siguen mostrando «English (US)» y
    «Español (MX)». Si falla, se aplica L1;
  - que se abran y cierren el diálogo del inicio de sesión, el de quitar amigo, el de presencia y el del rival que
    abandona, incluido el caso del abandono durante la cuenta atrás;
  - copiar el código de amigo.
- **Siguen abiertas:** la pregunta 1 (radio `0`). La pregunta 3 se resuelve con L0 si la comprobación pasa.

**Comprobación en el juego (2026-11-11, el usuario: «Hazlo tú»):**
- **Cómo:** el servidor estaba apagado y no se arrancó, porque escribe en la base. Se abrió el cliente compilado con
  computer use y se comparó con una copia de `HEAD` compilada aparte en el scratchpad (`git archive`). La preferencia
  `%APPDATA%\Bastion\language.txt` era `es-MX` y se dejó igual. Las copias se borraron al terminar.
- **L0 falla:** con D1 sin el refresco, el selector arranca con «Selected Item», la interfaz sale en inglés y la
  preferencia se guarda como `en-US`. Con D1 y el refresco de antes, todo sale como en `HEAD`. El refresco sí hace
  falta, y la documentación de Gum no lo anticipaba.
- **Se aplicó L1 (sin commit):**
  - `ILanguageService.LanguageChanged`, que `LanguageService.ApplyLanguage` lanza después de cambiar el idioma de Gum;
  - `LanguagePicker(ILanguageService, width, height)` se suscribe con grupo de método y conserva `RefreshListItems`;
  - `LoginView(LoginViewModel, ILanguageService)` guarda `_languages`; `CreateHeader` y `CreateLanguagePicker` dejan de
    ser estáticos;
  - `ScreenNavigator.ShowLogin` le pasa `_languages`.
- **Resultado con D1 y L1, igual que `HEAD`:**
  - arranca en español, con «Español (MX)» en el selector y `es-MX` guardado;
  - al elegir inglés, la interfaz y el selector cambian a «English (US)», y la lista muestra los dos nombres;
  - al volver a español, todo regresa y se guarda `es-MX`;
  - con los campos vacíos, los dos campos se marcan en rojo (`HasError`);
  - con datos inventados y el servidor apagado, se abre el diálogo «No pudimos conectar con el servidor» sobre la
    capa oscura. «Aceptar» lo cierra, se vuelve a abrir y a cerrar, y mientras está abierto «Mostrar» no hace nada,
    así que bloquea lo de atrás.
- **Defecto que ya existía (también en `HEAD`):** la primera vez que se abre la lista del selector, los dos elementos
  dicen «ListBox Item», hasta el primer cambio de idioma. Hipótesis sin comprobar: `PickerSkin.StyleListItem` pone
  `LocalizeText = false` después de `UpdateToObject`, y Gum vuelve a escribir el texto por defecto. Se revisa con
  `Theme`.
- **No se pudo comprobar sin servidor:** los diálogos de quitar amigo, de presencia y de rival que abandona, y copiar
  el código de amigo.
- **Pregunta 3:** sigue abierta. Con L1, el selector se suscribe a `LanguageService`, que vive todo el juego, y no se
  desuscribe, igual que antes con el servicio de Gum.
- **Verificación final:** `Client` compila sin avisos de código, pasan las 516 pruebas y todo queda en LF.

**Respuesta del usuario (2026-11-11):** «Sí, A en ambas» (preguntas 1 y 3).
- **Pregunta 1, aplicada:** `ModalLayer` tiene `private const float OverlayCornerRadius = 0;`.
- **Pregunta 3, anotada:** la suscripción del selector a `LanguageService` no se cancela. Se revisa cuando exista un
  camino de vuelta a la pantalla de inicio.
- **Verificación:** `Client` compila sin avisos de código y pasan las 516 pruebas.
- **Notas para lo que sigue:**
  - el defecto «ListBox Item» del selector, al revisar `PickerSkin` en `Theme`;
  - la R-27 de `ILanguageService`, que ahora también tiene `LanguageChanged`, al cerrar la capa;
  - quedan inicializadores de una línea en 19 archivos de `Screens` (3.3.1).

**Commit de `Controls`:** `eb9d572` (2026-11-11), en `review-standard-v2.4-host`, sin push.

### 393 a 398. `Localization` (2026-11-11)

Archivos: `ILanguagePreferenceStore`, `ILanguageService`, `LanguagePreferenceStore`, `LanguageService`,
`SupportedLanguage` y `SupportedLanguages`. `Strings.Designer.cs` se genera solo y no se revisa.

- **Cumple:**
  - **R-35:** el sufijo `Store` es para datos locales del cliente, como `LanguagePreferenceStore`.
  - **10.1.1:** `LanguageService` recibe la preferencia y la base de textos de Gum por constructor.
    `LanguagePreferenceStore` es el que hace la entrada y salida con el disco, y se recibe por su interfaz.
  - **9.1.2:** los dos `catch` de cada método (`UnauthorizedAccessException` e `IOException`) no se heredan uno del
    otro, así que el orden no importa.
  - **Pasada 2:** cada par de `catch` repite una línea, que ya está extraída (`LogReadFailure`, `LogSaveFailure`). Juntarlos
    pediría atrapar `Exception` (9.3.1).
  - **9.3.2, 9.4.2 y 11.3.1:** `IndexOf` lanza `ArgumentException`, los `??` tienen alternativa válida, y la bitácora
    dice acción y contexto.
- **Aplicado sin preguntas (reglas decididas, sin commit):**
  - **R-27:** `ILanguageService` queda documentada (summary de la interfaz y de cada miembro, `param` y las dos
    excepciones de `ChangeLanguage`), y `LanguageService` lleva `<inheritdoc/>` en la clase y en sus cinco miembros.
    `GenerateDocumentationFile` se activa al cerrar la capa.
  - **R-11:** `SupportedLanguage` pasa a constructor explícito con `ThrowIfNull` y propiedades `{ get; }`. No se copia
    con `with`.
  - **R-04:** `return File.ReadAllText(_filePath).Trim();` guarda primero `savedText`.
  - **R-23:** `keys.Add((string)entry.Key);` guarda primero `string key`. IDE0008 pide el tipo explícito con los tipos
    del lenguaje (R-51).
  - **R-47:** los privados de `LanguageService` siguen el orden de `LoadInitialLanguage`: `LoadTextDatabase`,
    `ReadKeys`, `Translate`, `ResolveInitialLanguage`, `ApplyLanguage` e `IndexOf`.
  - **2.11.4:** `Languages => SupportedLanguages.All` pasa a `{ get; }`, asignada en el constructor, y
    `Default => English` pasa a `{ get; } = English`. Las dos reenviaban otra propiedad: no son catálogo de diccionario
    ni exponen un campo (R-26).
- **Verificación:** `Client` compila sin avisos de código y pasan las 516 pruebas. El juego no se abrió; el
  comportamiento no cambia.
- **Pregunta 1 (2.4.1 y 2.1.2):** `SupportedLanguages` es una clase con nombre en plural, que la 2.4.1 pone como
  ejemplo incorrecto (`BoardTiles`). Además, su colección `All` no es un sustantivo en plural. Precedente:
  `ServiceEndpoints` (298) se dio por bueno en plural sin discutirlo. Usos: 5 en `LanguageService` y 1 en
  `LoginViewModel`.
- **Pregunta 2 (2.11.4):** `Spanish` y `English` guardan en `{ get; } =` un `SupportedLanguage` que lleva el texto del
  recurso (`Strings.LanguageNameSpanish`). La regla prohíbe guardar una entrada del diccionario en una propiedad
  autoimplementada, porque no se actualiza al cambiar de idioma. Aquí los nombres son autónimos y solo están en
  `Strings.resx`, así que nunca cambian.
- **Pregunta 3 (pasada 3 y lectura):** `Translate(key)` no traduce un texto: devuelve las traducciones de una clave
  en cada idioma. Además, `GetResourceSet(CultureInfo.InvariantCulture, true, true)` no dice qué significan los dos
  `true`.

**Preguntas (393 a 398):**
1. El nombre de `SupportedLanguages` y de `All`:
   - recomendado, A: `LanguageCatalog`, con `Languages` en lugar de `All` (singular y colección en plural);
   - B: dejar la clase como `ServiceEndpoints` y renombrar solo `All` (por ejemplo `AllLanguages`);
   - C: dejar los dos.
2. Los nombres guardados de `Spanish` y `English`:
   - recomendado, A: dejarlos y anotar por qué no aplica la razón de la 2.11.4 (autónimos que no cambian);
   - B: que `SupportedLanguage` guarde la clave del recurso y lea el nombre en cada acceso;
   - C: constantes en el código, con lo que el texto de la interfaz sale de `Strings.resx`.
3. Los nombres en la carga de textos:
   - recomendado, A: `Translate` → `ReadTranslations`, que hace pareja con `ReadKeys`, y argumentos con nombre
     `createIfNotExists: true, tryParents: true`;
   - B: dejarlos.

**Respuesta del usuario (2026-11-11):** «Sí, A en todas».
- **Pregunta 1, aplicada:** `SupportedLanguages` pasa a `LanguageCatalog` (`git mv`) y `All` a `Languages`. Cambian sus
  usos en `LanguageService` y `LoginViewModel`.
- **Pregunta 2, anotada:** `Spanish` y `English` guardan su nombre una sola vez. Es correcto porque los nombres son
  autónimos («English (US)», «Español (MX)») y solo existen en `Strings.resx`, así que no cambian con el idioma, que es
  la razón de la 2.11.4. Si algún día se traducen, el nombre debe leerse en cada acceso.
- **Pregunta 3, aplicada:** `Translate` pasa a `ReadTranslations`, y `GetResourceSet` recibe
  `createIfNotExists: true, tryParents: true`, un argumento por línea (3.5.1).
- **Arreglos:** `new[] { Spanish, English }` se queda en una línea, igual que los arreglos de `RoomPolicy` y
  `FriendRequestService` en su revisión. La 3.3.1 se aplicó a inicializadores de objeto.
- **Verificación:** `Client` compila sin avisos de código y pasan las 516 pruebas.

**Commit de `Localization`:** `e3f891a` (2026-11-11), en `review-standard-v2.4-host`, sin push.

### 399 a 404. Raíz de `Screens` (2026-11-11)

Archivos: `IEscapeKeyReceiver`, `INavigator`, `NoticeTone`, `ScreenNavigator`, `UiThread` y `ViewFactory`, más los
cuatro que trajo D1 (`IClipboard`, `IScreenHost`, `LocalServices` y `ScreenView`), que ya se escribieron con el
estándar.

- **Cumple:**
  - `IEscapeKeyReceiver`, `INavigator` y `NoticeTone` (2.5.1, 2.15.1; `None` es el primer valor y no es `[Flags]`);
  - `UiThread.Run`: el `_` de la lambda no se usa (2.7.2), y no es un reenvío que pida grupo de método (5.2.1), porque
    la firma de `Post` es otra;
  - `ScreenNavigator`: 5.3.1 en `DisposeViewModelsExcept`. La condición de tres `||` de `HandleCountdownFinished`
    no mezcla `&&` (R-24);
  - `ViewFactory`: 3.7.1 (`CreateVersionLabel` asigna `X` e `Y` después de `Anchor`, y los controles que devuelve
    una fábrica se ajustan después). La cadena de `version` es una asignación de varios pasos sin cast, que la R-23
    deja.
- **Aplicado sin preguntas (reglas decididas, sin commit):**
  - **9.4.1:** `CreateLabel` (`textKey` y `style`), `CreateButton` (`textKey`) y `CenterVertically` (`element`) no
    comprobaban sus parámetros. `CreateBoundLabel` y `CreateBoundUntranslatedLabel` comprueban `style` ellos mismos,
    en lugar del privado `CreateFixedWidthLabel`.
  - **R-23:** los cuatro casts a `LabelVisual` van primero en `labelVisual`.
  - **2.10.1:** `element.Y = 0` pasa a `MiddleOffsetY`, como el radio de `ModalLayer` (pregunta 1 de `Controls`).
  - **4.2.1 y 4.7.1:** `ReceiveEscapeKey` descarta con `is not IEscapeKeyReceiver receiver` y `return`.
- **Pasada 2, para `Theme`:**
  - el par `var labelVisual = (LabelVisual)label.Visual; style.ApplyTo(labelVisual);` se repite en `ViewFactory` (2)
    y `NoticeBox`;
  - `LocalizeText = false` se repite en `ViewFactory` (2), `FriendCodeFooter` y `PickerSkin`.
  - Un `TextStyle.ApplyTo(Label)` lo resolvería; se pregunta al revisar `Theme`.
- **Verificación:** `Client` compila sin avisos de código y pasan las 516 pruebas.
- **Pregunta 1 (pasada 3, pendiente en `05-pendientes.md`):** `UiThread.Run(uiContext, action)` publica la acción en
  el contexto de la interfaz, o la corre en el acto si no hay contexto (las pruebas). `revisor-estandar` sugirió
  `RunOnContext`. Se usa en 8 lugares.

**Pregunta (399 a 404):**
1. El nombre de `UiThread.Run`:
   - recomendado, A: dejarlo; con la clase se lee «correr en el hilo de la interfaz», que es lo que pide quien llama;
   - B: `RunOnContext`, que nombra el parámetro y no el propósito;
   - C: `Post`, que dice que se encola, pero sin contexto corre en el acto, así que engañaría en las pruebas.

**Respuesta del usuario (2026-11-11):** «Sí, A». `UiThread.Run` se queda con su nombre, y la nota de
`05-pendientes.md` queda resuelta.

**Commit de la raíz de `Screens`:** `12338cd` (2026-11-11), en `review-standard-v2.4-host`, sin push.

### Pruebas de interfaz de la carga de idioma (2026-11-11, pedidas por el usuario)

Con el cliente de `12338cd` (después de `Localization`), con computer use y el servidor apagado (no se arranca porque
escribe en la base). El sistema está en `en-US`; la preferencia guardada al empezar era `es-MX` y quedó en `es-MX`.

| Caso | Resultado |
| --- | --- |
| Arranque con `es-MX` guardado | Interfaz en español, «Español (MX)» en el selector, «Bastión 0.1.0» abajo |
| Cambio a inglés | Interfaz y selector en inglés; la lista muestra los dos nombres; se guarda `en-US` |
| Reinicio con `en-US` guardado | Arranca en inglés; el diálogo sale entero en inglés («Try again», «OK») |
| Sin archivo de preferencia | Arranca en inglés (idioma del sistema) y no crea el archivo hasta que se elige uno |
| Cultura desconocida guardada (`xx-XX`) | Arranca en inglés (idioma del sistema) y no toca el archivo |
| Vuelta a español | Interfaz en español y se guarda `es-MX` |

- **Defecto que ya existía (también en `32cbc25`, antes de D1):** si cambias de idioma con la pantalla abierta, el
  diálogo del inicio de sesión sale después con el título y el mensaje en el idioma nuevo, pero con los botones en el
  anterior («Reintentar», «Aceptar»).
  - Causa: Gum solo retraduce lo que está en `Root`, `PopupRoot` y `ModalRoot`, y un diálogo cerrado no está en
    ninguno.
  - El título y el mensaje se salvan porque se enlazan al abrir.
  - Arreglo posible, de una línea en `GumScreenHost.PlaceDialog`: llamar `dialog.Visual.RefreshLocalization()` antes
    de meterlo en `ModalRoot`. Según la documentación de Gum, retraduce el elemento y sus descendientes.
- **Defecto conocido, se repite:** la lista del selector dice «ListBox Item» hasta el primer cambio de idioma (para
  `Theme`).
- **Escape** no cierra la lista del selector en la pantalla de inicio de sesión, igual que antes: ninguna vista de esa
  pantalla atiende la tecla.
- **No se pudo probar sin servidor:**
  - `LoginViewModel.ApplyPreferredLanguage`, que aplica el idioma de la cuenta al iniciar sesión;
  - las demás pantallas.
- **No se puede probar en la interfaz sin cambiar el idioma de Windows:** el respaldo por idioma parecido (por ejemplo,
  sistema `es-ES` → «Español (MX)»). Una prueba unitaria de `LanguageCatalog.FindClosest` lo cubriría.

**Arreglo y prueba con servidor y base (2026-11-11, el usuario: «arréglalo, y también prueba con servidor y base de
datos»):**
- **Arreglo (sin commit):** `GumScreenHost.PlaceDialog` llama `dialog.Visual.RefreshLocalization()` antes de meter el
  diálogo en `ModalRoot`. En el juego, con el servidor apagado, el diálogo sale con «Try again»/«OK» después de pasar a
  inglés, y con «Reintentar»/«Aceptar» después de volver a español. Pasan las 516 pruebas.
- **No es defecto:** cambiar de idioma borra la contraseña a propósito (`LoginViewModel.SelectedLanguage`).
- **Servidor:** `dotnet run --project src/Bastion.Server.Host` desde esta rama. Arrancó en el puerto 8000, y
  `RoomCleanupService` cerró 0 salas.
  - Los clientes son copias en `scratchpad/client-a` y `client-b`, con `BASTION_SERVER_THUMBPRINT`, que es la huella
    SHA-256 de 64 caracteres; con 40 caracteres, el cliente rechaza el certificado.
  - Las contraseñas semilla pasan por el portapapeles con `scratchpad/tools/seed_password_to_clipboard.ps1`, que no
    las imprime, y luego se vacía el portapapeles.
  - **Incidente:** al leer el bloque de comentarios del script semilla, la máscara no las tapó y salieron en la salida
    de una herramienta. No se repitieron en los mensajes.
- **Resultados:**
  - **`sofia_salto` (idioma `en`), con la interfaz en español:** al iniciar sesión el menú pasa a inglés. Es la ruta del
    idioma parecido (`en` → «English (US)»), que sin servidor no se podía probar.
  - **Copiar el código de amigo:** el botón pasa a «Copied» y el portapapeles queda con el código (`SF-5T2Z`).
  - **Diálogo de quitar amigo:** se abre como modal y «Cancel» lo cierra sin quitar a nadie.
  - **`pedro_peon` (`es-MX`), con el cliente arrancado en inglés:** el menú pasa a español.
  - **Partida clasificatoria `pedro_peon` contra `marta_muros`:** se emparejan al instante, pasan por la cuenta atrás y
    llegan al tablero 3D. Pedro sale de la partida. Marta ve el diálogo modal «Partida terminada… Ganaste.», y «Volver
    al menú» la regresa. Queda en la base una partida FINISHED por abandono.
- **Defecto que ya existía (también en `32cbc25`):** cuando el idioma de la cuenta se aplica al iniciar sesión, los
  textos que el código arma con `Strings` y `CultureInfo.CurrentCulture` en un clic o en un temporizador salen en el
  idioma anterior. Los de Gum salen bien. Casos:
  - el título y el mensaje de «¿Eliminar a…?» en español con `sofia_salto`;
  - «Your turn» y «10 walls» en inglés con `pedro_peon`.
  - Causa probable: `ApplyLanguage` corre dentro del flujo `async` de `RequestSession`, y en .NET `CurrentCulture` y
    `CurrentUICulture` viajan con el flujo asíncrono. Al terminar, el hilo de la interfaz vuelve a su cultura
    anterior.
  - **Comprobado con una prueba aparte** (`scratchpad/gum-roots-probe`): un método `async` que pone
    `CurrentUICulture = en-US` después de un `await` la ve en `en-US`, pero quien lo llamó sigue en `es-MX` al volver.
    Fijar solo `DefaultThreadCurrentUICulture` no basta: los hilos que ya tienen una cultura propia la conservan.
  - **Arreglo propuesto, sin aplicar:** que `LanguageService.ApplyLanguage` fije también `Strings.Culture`. Las
    búsquedas en el archivo de recursos dejan de depender del hilo. Los formatos de número y fecha seguirían el hilo.
  - Alternativa: aplicar el idioma de la cuenta fuera del flujo `async` (publicarlo en el contexto de la interfaz).
    Depende de cómo Gum corre lo publicado, y no está comprobado.
- **Diálogo de presencia:** el servidor lo pide a los 15 minutos de búsqueda (`MatchmakingPolicy.PresenceCheckMinutes`).
  Marta quedó buscando para probarlo; el resultado se anota aparte.
- **Commit del arreglo del diálogo:** `05219b2` («Translate a dialog again when it opens»).

**Push y PR pedidos por el usuario (2026-11-11):**
- `origin/main` sigue en `2eb1167`. PR #16 (`review-standard-v2.4-repositories`, `e8d9d4c`) sigue abierto. Esta rama
  lleva 27 commits sobre él y 43 sobre `main`, todos de poijn y sin líneas de atribución.
- **La frontera rechazó el pre-push**, simulado a mano porque los hooks no están instalados:
  ```
  pre-push rechazado (context/01-regla-sin-rastro-de-ia.md):
    - src/Bastion.Client.Networking/Notifications/NotificationCallback.cs:16: [7.1.1] documentación XML fuera de un servicio (solo I*Service y su implementación la llevan)
    - src/Bastion.Client.Networking/Notifications/NotificationCallback.cs:46: [7.1.1] documentación XML fuera de un servicio (solo I*Service y su implementación la llevan)
  ```
- **Falso positivo:** `NotificationCallback` implementa `INotificationCallback`, que es un `[ServiceContract]`. La tabla R5
  de la regla admite `<inheritdoc/>` en la clase que implementa el servicio, y la 7.1.2 lo pide. El patrón `SERVICIO` de
  `frontera.py` solo reconoce clases que implementan `I*Service`.
- **No se hizo el push.** La regla dice que el control no se salta y que solo el usuario decide si se ajusta
  `frontera.py` o hace él la operación.
- **Ajuste propuesto** (`context/herramientas/frontera.py`, fuera del repositorio): que `SERVICIO` también reconozca
  `class … : … I*Callback`.
- **Respuesta del usuario:** «Sí, ajústalo».
  - `SERVICIO` ahora reconoce `class … : … I*Service` e `I*Callback`. Sigue rechazando las vistas y los modelos de vista
    (comprobado con cuatro casos).
  - El pre-push pasa (exit 0), y el texto del PR pasa la revisión de mensajes de la frontera.
- **Push:** `review-standard-v2.4-host` subió a `origin` en `05219b2`, con seguimiento.
- **PR #17:** https://github.com/Arclyne/bastion/pull/17
  - Título: «Review the host, contracts and client code against the coding standard v2.4».
  - Base `main` y 43 commits: incluye los de #16 hasta que ese se fusione.
  - Estado: abierto y `mergeable_state: clean`. Sin CI. Autor: poijn23.
  - Se abrió con la API REST y el token de Git Credential Manager (`scratchpad/tools/open_pull_request.py`), que no se
    imprimió.
  - El cuerpo, en inglés y sin rastro de IA, tiene Summary, Server host, Contracts, Client networking, Client,
    Verification y Known issues (el idioma tras el inicio de sesión y «ListBox Item»).
  - No se pudo vincular a la sesión, porque la sesión no trabaja en el checkout.

**Arreglo del idioma después de iniciar sesión (2026-11-11, el usuario: «Sí, arréglalo»):**
- **Prueba primero (roja):** `TestLanguageService.ChangeLanguage_InsideAsyncFlow_KeepsTextsInNewLanguageAfterward`.
  - Arranca `LanguageService` con `es-MX` guardado y la base de textos de Gum (`LocalizationService`).
  - Cambia a inglés dentro de un método `async`, después de un `await`, y al volver compara `Strings.LoginTagline`.
  - Sin el arreglo falla: espera «Maze of walls» y obtiene «Laberinto de muros».
  - Va en la colección `GlobalCultureCollection`, sin paralelismo, porque toca estado global. `Dispose` deja
    `Strings.Culture` y las culturas por defecto en `null`. La preferencia la da un `FakeLanguagePreferenceStore`.
- **Arreglo:** `LanguageService.ApplyLanguage` también fija `Strings.Culture = culture`. La clase de recursos usa esa
  cultura en todos los hilos y flujos, en lugar de `CurrentUICulture`.
- **Verificación:**
  - pasan las 517 pruebas (139 + 158 + 220) y `Client` compila sin avisos;
  - la frontera pasa `pre-commit` y `commit-msg`;
  - en el juego, cliente C con el arreglo: `sofia_salto` (idioma `en`) entra con la interfaz en español, y «Remove
    marta_muros?» sale con título y mensaje en inglés (antes salía «¿Eliminar a…?»). Se canceló sin quitar a nadie.
  - No se repitió el caso de «Your turn» de pedro, porque necesitaba otra partida y marta estaba esperando la
    presencia.
- **Formatos:** los números y las fechas con `CultureInfo.CurrentCulture` siguen la cultura del hilo. Para los textos de
  hoy no cambia nada visible.
- **Commit:** `a6b56e5` («Keep the chosen language for resource texts after the login»).
- **Diálogo de presencia, primer intento:** el aviso llegó a los 15 minutos, pero se miró a los 15:08, después de los 60
  segundos de respuesta. La búsqueda mostraba «Se canceló la búsqueda porque no respondiste a tiempo». Se lanzó otra
  búsqueda para verlo a tiempo.
