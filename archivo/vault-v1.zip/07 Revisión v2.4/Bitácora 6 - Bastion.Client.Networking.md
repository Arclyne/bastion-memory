---
tags: [revision-v2-4]
---
# Bitácora 6 - Bastion.Client.Networking
Volver a [[Índice de la revisión v2.4]]

Son 85 archivos (301 a 385), en orden de carpeta. El primer conteo decía 87; se corrigió al revisar `Chat`:

| Carpeta | Archivos |
| --- | --- |
| `Accounts` | 301–310 |
| `Channels` | 311–317 |
| `Chat` | 318–327 |
| `Friends` | 328–341 |
| `Matches` | 342–344 |
| `Matchmaking` | 345–349 |
| `Notifications` | 350–366 |
| `PrivateChat` | 367–373 |
| `Rooms` | 374–383 |
| `ServerConnection` | 384 |
| `Sessions` | 385 |

Datos generales:
- **Composición:** `BastionGame` crea `ServerConnection`, y este crea los ocho clientes. `ServerConnection` hace de clase
  de registro de los servicios del cliente (10.2.1).
- **Canales:** cada cliente de petición y respuesta crea su propio `ServiceChannel<T>` con `new`. `NotificationClient`
  crea su `DuplexChannelFactory` (pregunta 3 de 301–310).

### 301 a 310. `Accounts` (2026-11-11)

Los archivos son:
- `AccountClient`, `IAccountClient`, `LoginCredentials` y `SignedInSession`;
- `AccountRestriction` y `AccountRestrictedException`;
- `ConnectionLostException`, `InvalidCredentialsException`, `ServerErrorException` y `ServerUnreachableException`.

Revisión:
- **Cumple:**
  - 2.x, 3.x, 4.3.2 (`ToRestriction` con `default` que lanza) y 9.1.2 (los `catch` van del más derivado al menos
    derivado);
  - 9.4.1;
  - 9.6.1: las excepciones sin datos tienen los tres constructores de CA1032; `AccountRestrictedException` tiene datos,
    y su único constructor los recibe.
  - `IAccountClient` no es `I…Service` ni `[ServiceContract]`, así que no lleva documentación (R-39, R5).
- **Se aplican sin preguntar, al cerrar el grupo:**
  - **R-10:** `SignedInSession` → `LoggedInSession`, con `git mv`, y `ToSignedInSession` → `ToLoggedInSession`. Cambian
    unos 20 archivos de `Client` y tres pruebas, entre ellos el campo `_signedInSession` de `ScreenNavigator`.
  - **R-41:** "The account cannot sign in." → "The account cannot log in.", igual que en el servidor.
  - **R-14:** `ToSignedInSession` lleva `??` en sus tres argumentos, que pasan a variables antes del `return new`.
- **Pregunta 1 (6.4):** `ConnectionLostException`, `ServerErrorException` y `ServerUnreachableException` están en
  `Accounts`.
  - Son fallas de red de todos los clientes: aparecen en 16 a 19 archivos.
  - Las crea `Channels/ServiceFailureTranslator`.
  - La 6.4 pide que el espacio de nombres refleje la responsabilidad del archivo.
- **Pregunta 2 (pasada 2):** `AccountClient.LogIn` repite en sus `catch` la traducción general de
  `ServiceFailureTranslator` (`EndpointNotFoundException` → `ServerUnreachable`, `FaultException` → `ServerError`,
  comunicación y tiempo → `ConnectionLost`).
  - Los otros seis clientes usan un `Call` privado que atrapa `CommunicationException` y `TimeoutException`, y un
    `ToClientException` con sus fallas propias, que al final llama a `ServiceFailureTranslator`.
  - La única diferencia sería una `FaultException<InvalidSessionFault>`, que `LogIn` no puede recibir.
- **Pregunta 3 (10.1.1 y 10.2.1):** los siete clientes de petición y respuesta crean su `ServiceChannel<T>` con `new`
  en un campo. `ServiceChannel` hace E/S de red, así que es un servicio externo (10.1.1), y se construye fuera de la
  raíz de composición. Es el "código incorrecto" de la regla.
  - Ninguna excepción lo cubre: la de `Adapters` permite recibir el tipo del framework, no crearlo.
  - Hoy ningún cliente se puede probar con un canal falso.

**Preguntas (301 a 310):**
1. Las tres fallas de red generales (recomendado: A, pasarlas a `Channels` junto a `ServiceFailureTranslator`, con
   `git mv`, su espacio de nombres y los `using`; B, una carpeta nueva solo para ellas; C, dejarlas).
2. `AccountClient` con `Call` y `ToClientException`, como los otros clientes (recomendado: sí).
3. Canales recibidos por constructor. Recomendado: A.
   - **A:** un `IServiceChannel<TContract>` con las dos `Call`, que implementa `ServiceChannel<TContract>`.
     - Cada cliente lo recibe por constructor y deja de ser `IDisposable`.
     - `ServerConnection` crea los siete canales, se los pasa a los clientes y los libera (9.5.1: el dueño libera).
     - Va en un commit aparte que toca los siete clientes, `ServerConnection` y la interfaz nueva.
     - Se prueba con una sonda de canal falso.
     - `NotificationClient` tiene otra forma (dúplex, con estado de sesión) y se pregunta en su carpeta.
   - **B:** dejarlo así.

**Respuesta del usuario (2026-11-11):** «Sí, A en todas».

**Commit 1, `e83e6d3` (`Accounts`):**
- **R-10:** `SignedInSession` → `LoggedInSession`, con `git mv`, en 19 archivos. Incluye el campo `_loggedInSession` de
  `ScreenNavigator` y tres pruebas.
- **R-41:** "The account cannot log in. Restriction=…".
- **R-14:** `ToLoggedInSession` guarda `token`, `nickname` y `preferredLanguage` en variables.
- **Pregunta 1:** `ConnectionLostException`, `ServerErrorException` y `ServerUnreachableException` pasan a `Channels`,
  con `git mv` y su espacio de nombres.
  - 17 archivos reciben `using Bastion.Client.Networking.Channels;` en orden, y seis pierden el `using …Accounts;` que
    ya no usan.
  - Un script en `scratchpad/tools/move_network_exceptions.py` lo hizo solo donde se usan los tipos.
- **Pregunta 2:** `AccountClient` tiene `Call`, `ToClientException` (sus dos fallas y luego `ServiceFailureTranslator`),
  `ToRestriction` y `ToLoggedInSession`, en el orden de la cadena (R-47).
- **Sonda `client-probes/account-mapping`:** compara la traducción de `HEAD` con la nueva en 11 casos.
  - Son iguales 10: el tipo, el mensaje, la excepción interna, la restricción y los minutos.
  - La única diferencia es la esperada: una `FaultException<InvalidSessionFault>`, que `LogIn` no puede recibir, ahora
    da `InvalidSessionException` en lugar de `ServerErrorException`.

**Commit 2, `c54aba2` (pregunta 3):**
- `Channels/IServiceChannel<TContract>` tiene las dos `Call`, y `ServiceChannel<TContract>` la implementa.
- Los siete clientes reciben `IServiceChannel<…>` por constructor (después, el `INotificationClient` donde lo había),
  y dejan de ser `IDisposable`. Pierden el `using Bastion.Contracts;`, que solo servía para `ServiceEndpoints`.
- `ServerConnection` crea los siete canales en campos y se los pasa a los clientes desde sus propiedades.
  - Libera primero `NotificationClient` y luego los canales, en el mismo orden de antes.
  - Ya no guarda campos de los clientes.
- **Sonda `client-probes/channel-injection`:** los siete clientes con un canal falso.
  - Con éxito, cada uno devuelve el valor traducido.
  - El endpoint caído, la sesión inválida, la falla del servidor y el tiempo agotado dan `ServerUnreachable`,
    `InvalidSession`, `ServerError` y `ConnectionLost`, con la excepción original adentro.
  - El canal falso recibió las 35 llamadas.
  - `ServerConnection` real se crea y se libera sin errores.

**Verificación de los dos commits:**
- `Client` compila sin avisos de código en una compilación completa (solo NU1902/NU1903);
- pasan 514 pruebas.

### 311 a 317. `Channels` (2026-11-11)

Los archivos son `ChannelCloser`, `ChannelSettings`, `DeviceIdentity`, `ServerAddress`, `ServiceChannel`,
`ServiceFailureTranslator` y `ThumbprintCertificateValidator`. `IServiceChannel` y las tres excepciones movidas ya se
vieron en 301–310.
- **Cumple:**
  - **9.5.2:** `ChannelCloser` aborta si el canal no está abierto, cierra con `Close` y aborta si falla.
    `ServiceChannel` cierra cada canal al terminar y lo aborta ante una falla de comunicación o de tiempo, con `throw;`.
  - **4.3.2:** `ServiceFailureTranslator` tiene un `default` que lanza `ArgumentOutOfRangeException`. Los casos van del
    tipo más derivado al menos derivado.
  - **9.3.2 y 1.3.1:** `ThumbprintCertificateValidator` lanza `SecurityTokenValidationException` (predefinida) y rechaza
    todo si no hay huella configurada.
  - **10.1.1:** `DeviceIdentity` y `ServerAddress` son estáticas y leen el equipo y las variables de entorno. Su resultado
    es fijo en cada máquina, y desde `c54aba2` se usan al crear los canales en la raíz de composición.
  - 2.3.2, 2.10.1 (cada texto y cada número están en constantes), 9.4.1 y 11.1.1/11.3.1 (`ChannelCloser` registra en
    Warn con `Channel=`).
- **Aplicado sin preguntas (reglas decididas):**
  - **R-14:** `ChannelSettings.CreateAddress` guarda `address` e `identity` antes del `return new EndpointAddress(…)`.
  - **R-04 y R-02:** `DeviceIdentity.GetFingerprint` ya no anida tres llamadas en el `return`. Ahora usa
    `byte[] encodedSource`, luego `byte[] hash` y al final `return Convert.ToHexString(hash)`.
  - **R-28:** `ServerAddress.GetCertificateThumbprint` guarda la variable de entorno en `thumbprint` y devuelve
    `thumbprint?.Trim() ?? string.Empty`.
  - **R-04:** `GetHost` y `GetPort` devolvían un `?:`. Pasan a una guarda con `return` anticipado, como `FindRoomOf`
    (169) y `GetPartnerId` (12).
- **Sonda `client-probes/server-address`:** compara antes y después, y da el mismo resultado:
  - 10 valores del puerto, 4 del host y 3 de la huella;
  - la huella del equipo (64 caracteres) y la versión;
  - la dirección completa de `ChannelSettings`.
- **Pregunta 1 (falla encontrada por la sonda):** `GetPort` solo rechaza los puertos menores o iguales a 0.
  - Con `BASTION_SERVER_PORT=65536` o `70000`, `UriBuilder` lanza `ArgumentOutOfRangeException` cuando
    `ServerConnection` crea los canales. Como `BastionGame` crea `ServerConnection` en un campo, el cliente se cae al
    arrancar en lugar de usar el puerto por defecto.
  - El servidor ya valida el rango con `IPEndPoint.MinPort` e `IPEndPoint.MaxPort` (R-52, 230).
  - Además, la variable `text` se lee mejor como `portText`.
- **Pregunta 2 (2.14.3):** `ThumbprintCertificateValidator` hereda de `X509CertificateValidator`, pero no termina con el
  nombre completo de esa clase. La regla solo exceptúa las bases cuyo nombre no agrega información (`Game`, `Panel`) y
  los controles. Solo la usa `ChannelSettings`.

**Preguntas (311 a 317):**
1. Rango del puerto (recomendado: A, `IPEndPoint.MinPort < port && port <= IPEndPoint.MaxPort`, con `portText`, y si no
   cae en el rango se usa `DefaultPort`; B, dejarlo).
2. `ThumbprintCertificateValidator` → `ThumbprintX509CertificateValidator` (recomendado: A, por la letra de la regla;
   B, dejarlo, porque "CertificateValidator" ya muestra la relación con la base).

**Respuesta del usuario (2026-11-11):** «Sí, A en las dos». En los puertos pidió además rechazar los reservados, que no se
deben usar bajo ningún motivo.
- Se le preguntó qué rangos cuentan como reservados. IANA (RFC 6335) define tres: del sistema (0–1023), registrados
  (1024–49151) y dinámicos (49152–65535). Windows y Linux usan los dinámicos como puertos efímeros de salida.
- **Eligió solo 1024–49151, en el cliente y en el servidor.** Queda como regla R-58.

**Aplicado:**
- **`ServiceEndpoints`** (`Contracts`): `FirstRegisteredPort = 1024`, `LastRegisteredPort = 49151` (los dos límites de
  la pareja quedan públicos, R-25) y `IsRegisteredPort(int port)`. Es una sola definición (4.4.2).
- **`ServerAddress.GetPort`:** `portText`, `bool isNumber = int.TryParse(…)`, y
  `if (!isNumber || !ServiceEndpoints.IsRegisteredPort(port))` devuelve `DefaultPort`.
- **`Program.GetNetTcpPort`** (servidor):
  - usa `ServiceEndpoints.IsRegisteredPort`, en lugar de `IPEndPoint.MinPort/MaxPort` (sale `using System.Net`);
  - el mensaje es "The net.tcp port is missing or is not a registered port. Key=…; Port=…; FirstPort=1024;
    LastPort=49151".
  - Cambia la R-52 de 230 en este punto.
- **Pregunta 2:** `ThumbprintX509CertificateValidator`, con `git mv` y su uso en `ChannelSettings`.

**Verificación:**
- **Compilación:** `Host` y `Client` compilan sin avisos de código en una compilación completa (solo NU1902/NU1903).
- **Pruebas:** pasan 514.
- **Sonda `server-address`:** con 15 valores del puerto, solo 1024, 8000 y 49151 quedan en la dirección. Los demás usan
  8000: sin valor, vacío, texto, 0, −5, 80, 1023, 49152, 65535, 65536, 70000 y " 8100". Antes, 65536 y 70000 hacían caer
  al cliente.
- **Servidor:** el ejecutable de `host-build` con `--Server:NetTcpPort=` 80, 1023, 49152 y 70000 se detiene con el mensaje
  nuevo, antes del certificado y de la base. No se probó con un puerto válido, porque eso arranca el servidor real.

**Commit de `Channels`:** `5382eac` (2026-11-11), en `review-standard-v2.4-host`, sin push.

**Justificación de la R-58 (2026-11-11, a pedido del usuario):** el usuario preguntó si la validación hace falta, si hay
un ataque que la exija y qué técnica la respalda.
- **Seguridad:**
  - Ningún ataque realista usa el puerto para entrar. Quien puede cambiarlo controla la máquina del servidor o el
    entorno del jugador, y un servidor falso usaría un puerto válido.
  - Contra la suplantación protegen TLS (`SecurityMode.Transport`) y la huella del certificado, no el puerto.
  - La materia pide "prácticas seguras de escritura de código" y "seguridad en la BD", no proteger el puerto.
  - La validación es robustez de la configuración, no seguridad.
- **Técnica: fallar pronto.** Shore (2004), IEEE Software 21(5), pp. 21–25, leído del PDF:
  - el ejemplo de la propiedad de configuración mal escrita, en pp. 21–22, "Immediate and visible failure";
  - con usuarios finales, un manejador global en lugar de una caída, en pp. 24–25, "Robust failure".
- **Práctica de .NET:** Microsoft Learn, *Options pattern*, sección "Options validation".
  - Muestra `[Range]` y `ValidateOnStart`, y su ejemplo `ServerOptions` limita `Port` con `[Range(1, 65535)]`.
  - En Bastión el puerto se necesita antes de `Build()`, así que la revisión explícita en `GetNetTcpPort` cumple esa
    función.
- **El rango:**
  - RFC 6335, sección 6: los tres rangos. Sección 8.1.2: un puerto dinámico "MUST NOT be used as a service identifier",
    y no hay que suponer que esté libre.
  - Microsoft (artículo del rango dinámico y artículo del agotamiento de puertos): Windows usa 49152–65535 para las
    conexiones de salida.
  - Excluir 0–1023 es decisión del proyecto: el RFC los asigna a servicios conocidos, pero no lo prohíbe.
- **Corregido:** el permiso de administrador en Linux y los bloques reservados por Hyper-V/WSL no salen en estas fuentes,
  así que no se usan como argumento.
- **Decisión del usuario:** «Sí, mantenla». La R-58 se queda como está.
- **Pendiente para la revisión de `Client`:** hoy el cliente vuelve al 8000 sin avisar, que es el "valor por defecto" que
  Shore desaconseja. Se propondrá que registre el problema y le diga al jugador qué variable está mal.

### 318 a 327. `Chat` (2026-11-11)

Los archivos son:
- `ChatAuthor`, `ChatMessage`, `ChatMute` y `LobbyChatTranscript`;
- `ChatClient`, `IChatClient` y `ChatContractTranslator`;
- `ChatChannelForbiddenException`, `ChatMessageRejectedException` y `ChatRejection`.

Revisión:
- **Cumple:**
  - 2.x, 4.3.2 (`ToRejection`, con 6 casos y `default`), 9.6.1 (las dos excepciones) y 9.4.1 en los públicos;
  - R-47 en el traductor;
  - **2.11.4:** los `add =>` y `remove =>` del evento de `ChatClient` son accesores que solo reenvían. La sección
    "Alcance" de la regla los excluye de forma expresa.
  - **Pasada 3:** `ChatMute.EndsAt` repite el nombre del `ChatMute` de `Application`.
- **Aplicado sin preguntas (reglas decididas):**
  - **R-11:** `ChatAuthor`, `ChatMessage` y `LobbyChatTranscript` pasan a constructor explícito con `ThrowIfNull` y
    propiedades `{ get; }`. Ninguno se copia con `with`, ni se deconstruye ni se crea con argumentos con nombre.
    `ChatMute (bool, DateTime?)` se queda posicional por la R-16.
  - **R-14 y 5.3.1** en `ChatContractTranslator.ToTranscript`:
    - antes: `messages.Select(ToChatMessage).ToList()` y un `new ChatMute(…)` dentro del `return`;
    - ahora: `IEnumerable<ChatMessage> chatMessages`, luego `var messageList = new List<ChatMessage>(chatMessages)`,
      luego `var mute`, y al final `return new LobbyChatTranscript(messageList, …, mute)`.
  - **R-14:** el `??` del texto va en su variable en `ToChatMessage(LobbyChatMessage)` y en `ToReceivedMessage`.
  - **R-14:** en `ChatClient.ToClientException`, `ChatRejection rejection` va antes del `new ChatMessageRejectedException`.
  - **R-47:** en `ChatClient`, `Call` va antes de `ToClientException`, en el orden de la cadena, como en `AccountClient`.
- **Verificación:**
  - `Client` compila sin avisos de código en una compilación completa;
  - pasan las 136 pruebas del cliente, 12 de ellas sobre `ChatContractTranslator`.

**Commit de `Chat`:** `542c757` (2026-11-11), en `review-standard-v2.4-host`, sin push.

### 328 a 341. `Friends` (2026-11-11)

Los archivos son:
- seis registros: `FoundPlayer`, `FriendListing`, `FriendRequestListing`, `ListedFriend`, `PendingFriendRequest` y
  `PlayerTag`;
- cuatro enumeraciones: `FriendPresence`, `FriendRelationship`, `FriendRequestOutcome` y `FriendshipRejection`;
- `FriendshipRejectedException`, `IFriendClient`, `FriendClient` y `FriendContractTranslator`.

Revisión:
- **Cumple:**
  - 2.x y 2.15.1;
  - 4.3.2: los cuatro `switch` tienen `default`, y `ToRejection` tiene 8 casos, con complejidad 9;
  - 9.6.1 y 9.4.1;
  - pasada 4: cada valor se usa.
  - `FriendRelationship.None` no es una enumeración de indicadores. La 2.15.2 solo exige `None` en esas, y no lo prohíbe
    en las demás; dentro de `FriendRelationship` se lee como "sin relación".
- **Aplicado sin preguntas (reglas decididas, sin commit):**
  - **R-11:** los seis registros pasan a constructor explícito con `ThrowIfNull` y propiedades `{ get; }`.
    - Ninguno usa `with`, deconstrucción ni argumentos con nombre.
    - El de `FriendRequestListing` va con un parámetro por línea.
    - Se generaron con `scratchpad/tools/explicit_records.py` (sesión `0da7ac4a`).
  - **R-14 y 5.3.1 en `FriendContractTranslator`:**
    - `ToFriendListing`, `ToFoundPlayers` y `ToPendingRequests` guardan la consulta en un `IEnumerable<T>` con nombre y
      la materializan con `new List<T>(…)`;
    - `ToFriendRequestListing` guarda `receivedRequests` y `sentRequests` en variables;
    - `ToListedFriend` (las dos) y `ToFoundPlayer` guardan `presence` y `relationship` antes del `return new`;
    - `ToPlayerTag` guarda sus dos textos en variables.
  - **R-47 en el traductor:** los privados van por cadenas:
    - `ToListedFriend` y luego `ToPresence`;
    - `ToFoundPlayer` y luego `ToRelationship`;
    - `ToPendingRequests` y luego `ToPendingRequest`.
  - **5.1.1 y R-45 en `FriendClient`:** `Call(Action)` tenía una lambda de cuatro líneas. Ahora es
    `Func<IFriendshipService, bool> operationAsFunction = service => CompleteOperation(operation, service);`, con un
    privado `CompleteOperation`, como en los servicios del servidor.
  - **R-14:** en `ToClientException`, `FriendshipRejection rejection` va antes del `new`.
  - **R-47 en `FriendClient`:** `Call<TResult>`, luego `ToClientException`, luego `Call(Action)` y luego
    `CompleteOperation`.
  - **`ConversationClient` tiene la misma lambda de varias líneas.** Se corrige en `PrivateChat`.
- **Verificación:**
  - `Client` compila sin avisos de código;
  - pasan las 136 pruebas del cliente;
  - la sonda `channel-injection` pasó `FriendClient.AcceptFriendRequest`, que usa `Call(Action)`, y `SearchPlayers`
    por el canal falso: con éxito y con las cuatro fallas, cada una con la excepción original adentro.
- **Pregunta 1 (4.4.1):** el traductor repite seis veces
  `new PlayerTag(nombre ?? string.Empty, código ?? string.Empty)`, una por cada tipo de contrato que trae un jugador.

**Pregunta (328 a 341):**
1. Un privado `ToPlayerTag(string? nickname, string? friendCode)` para las seis (recomendado: A). Lo usan casi todos, así
   que va al final, como `GetUtcNow` (R-47). El público `ToPlayerTag(FriendshipStartedNotification)` lo llamaría.
   B: dejarlo.

**Respuesta del usuario (2026-11-11):** «Sí, sácalo».
- **Aplicado:**
  - el privado `ToPlayerTag(string? nickname, string? friendCode)` va al final, con `tagNickname` y `tagFriendCode`
    antes del `return new`;
  - los seis lugares lo llaman con `PlayerTag x = ToPlayerTag(…)`, con tipo explícito por la R-51 (llamada sin
    calificar dentro de la clase);
  - el público `ToPlayerTag(FriendshipStartedNotification)` devuelve la llamada.
- **Verificación:**
  - `Client` compila sin avisos de código;
  - pasan 514 pruebas, 8 de ellas sobre `FriendContractTranslator`.

**Commit de `Friends`:** `bae09c1` (2026-11-11), en `review-standard-v2.4-host`, sin push.

### 342 a 344. `Matches` (2026-11-11)

Los archivos son `IMatchClient`, `MatchClient` y `MatchNotJoinedException`. Cumplen y no cambian.
- **`MatchClient`:**
  - tiene una sola operación, `AbandonMatch`, con su `try`, sus dos `catch` y `ToClientException`, que termina en
    `ServiceFailureTranslator`. No repite la traducción general (la pregunta 2 de 301–310 no aplica);
  - la lambda es de una línea y usa `IServiceChannel.Call(Action)`;
  - los accesores del evento cumplen por el "Alcance" de la 2.11.4.
- **`MatchNotJoinedException`:** cumple la 9.6.1, porque no lleva datos y tiene los tres constructores estándar.
- **`IMatchClient`:** cumple; no lleva documentación (R5).
- No hay commit.

### 345 a 349. `Matchmaking` (2026-11-11)

Los archivos son `IMatchmakingClient`, `MatchmakingClient`, `SearchEndReason`, `SearchRejectedException` y
`SearchRejection`.
- **Cumple:**
  - las dos enumeraciones y `SearchRejectedException` (9.6.1, con datos);
  - `ToRejection`, con 3 casos y `default`;
  - los accesores de los cuatro eventos (2.11.4, "Alcance");
  - `Call(Action)` con sus dos `catch`, sin lambda de varias líneas;
  - pasada 4: `SearchEndReason` lo usa `SearchEndedEventArgs`.
- **Aplicado sin preguntas:**
  - **R-14:** `SearchRejection rejection = ToRejection(…)` va antes del `new SearchRejectedException`.
  - **R-47:** el orden es `Call`, luego `ToClientException`, luego `ToRejection`.
- **Verificación:**
  - `Client` compila sin avisos de código;
  - pasan las 136 pruebas del cliente;
  - la sonda `channel-injection` pasó `StartSearch` por el canal falso, con éxito y con las cuatro fallas.

**Commit de `Matchmaking`:** `19ac951` (2026-11-11), en `review-standard-v2.4-host`, sin push.

### 350 a 366. `Notifications` (2026-11-11)

Son 17 archivos: 13 `…EventArgs`, `FoundMatchFormat`, `FoundMatchParticipant`, `INotificationClient`,
`NotificationCallback` y `NotificationClient`.
- **Cumple:**
  - **Los `…EventArgs`:** 2.14.1, sellados, con constructor que comprueba sus referencias y propiedades `{ get; }`.
  - **Los dos registros:** `FoundMatchFormat (byte ×3)` se queda posicional por la R-16, y `FoundMatchParticipant` ya
    tiene constructor explícito.
  - **`NotificationClient`:** cumple en lo demás:
    - 5.1.2: se suscribe a `Faulted` con un grupo de método y se desuscribe en `Disconnect`;
    - 10.4.1: el `TimeProvider` se inyecta y crea el temporizador;
    - el temporizador atrapa la comunicación, el tiempo y `ObjectDisposedException`;
    - 11.1.1 en Warn;
    - R-47: los privados forman cadenas que usa `Connect`.
- **Aplicado sin preguntas (reglas decididas, sin commit):**
  - **R-48 en `NotificationCallback`:** había ocho sobrecargas `ToEventArgs`, cada una con un tipo de salida distinto.
    Ahora cada método dice qué arma: `ToChatMessageReceivedEventArgs`, `ToMatchChatMessageReceivedEventArgs`,
    `ToMatchAbandonedEventArgs`, `ToMatchFoundEventArgs`, `ToPresenceRequestedEventArgs`, `ToSearchEndedEventArgs`,
    `ToPrivateMessageReceivedEventArgs` y `ToFriendPresenceChangedEventArgs`.
  - **R-14:** cada `To…EventArgs` y `ToFoundMatchParticipant` guarda en variables las llamadas, los `??` y la resta
    `Deadline - OccurredAt` antes del `return new`. El tipo es explícito o `var` según la R-51.
  - **5.3.1:** los participantes pasan de `.Select(…).ToArray()` a un `IEnumerable<FoundMatchParticipant>` con
    nombre, materializado con `new List<…>(…)`.
  - **R-47:** los privados van por la cadena de cada `TryDispatch…`: el despachador, luego su `To…EventArgs`, luego
    su `On…`. `ToReason` va debajo de `ToSearchEndedEventArgs`.
  - **R-23 en `NotificationClient`:** `((ICommunicationObject)channel).Faulted += …` y `((ICommunicationObject)channel).Abort()`
    pasan a `var communicationObject = (ICommunicationObject)channel;` y luego la línea que lo usa.
- **Sonda `client-probes/notification-callback`** (sesión `0da7ac4a`): compara el `NotificationCallback` de `HEAD` con
  el nuevo.
  - Son 21 notificaciones, con campos vacíos, un `SearchEndedReason` desconocido, una sala nula y una notificación nula.
  - Las 21 dan el mismo evento con los mismos datos, o la misma excepción.
  - Pasan `TestNotificationCallback` y `TestRoomNotifications`.
- **Pregunta 1 (10.1.1, pendiente desde 301–310):** `NotificationClient` crea con `new` su
  `DuplexChannelFactory<ISessionService>` (E/S de red) y el `NotificationCallback`.
- **Pregunta 2 (9.4.1 y R-50):** `ReceiveNotification(Notification notification)` es un método público sin
  `ThrowIfNull`.
  - Es una operación de un solo sentido de WCF que atiende el cliente. Hoy una notificación nula, o de un tipo que
    ningún despachador conoce, se ignora sin dejar rastro.
  - Un `ThrowIfNull` lanzaría dentro del despacho de WCF y podría dañar el canal dúplex.
  - La R-50 resolvió el caso de los servidores de un solo sentido con una guarda que registra en Warn.
- **Pregunta 3 (pasada 2):** nueve ramas despachan con `OnX(ToXEventArgs(y))`. Cuatro arman el argumento dentro de la
  rama: la solicitud de amistad, la amistad nueva, la sala actualizada y la sala cerrada; esta última con `??` en el
  argumento.

**Preguntas (350 a 366):**
1. El canal dúplex por constructor. Recomendado: A.
   - **A:**
     - `Channels/ISessionChannelFactory` (`ISessionService CreateChannel()`);
     - `Channels/SessionChannelFactory : ISessionChannelFactory, IDisposable`, que envuelve el `DuplexChannelFactory`
       con `ChannelSettings` y se libera con `ChannelCloser`;
     - `ServerConnection` crea el `NotificationCallback`, la fábrica y
       `NotificationClient(callback, sessionChannelFactory, timeProvider)`, y libera la fábrica después del cliente.
     - `NotificationClient` sigue siendo `IDisposable` por su canal y su temporizador.
   - **B:** dejarlo.
2. La notificación nula. Recomendado: A.
   - **A:** la forma de la R-50: un `ILog`, `if (notification is null)` con Warn y `return`, y Warn cuando ningún
     despachador conoce el tipo.
   - **B:** `ThrowIfNull`, por la letra de la 9.4.1, con el riesgo de dañar el canal.
   - **C:** dejarlo.
3. Las cuatro ramas por su `To…EventArgs`. Recomendado: A.
   - **A:** `ToFriendRequestReceivedEventArgs`, `ToFriendshipStartedEventArgs`, `ToRoomUpdatedEventArgs` y
     `ToRoomClosedEventArgs`, para que cada rama se lea igual.
   - **B:** dejarlo.

**Respuesta del usuario (2026-11-11):** «Sí, A en todas».

**Aplicado:**
- **Pregunta 1:**
  - `Channels/ISessionChannelFactory` (`ISessionService CreateChannel()`);
  - `Channels/SessionChannelFactory : ISessionChannelFactory, IDisposable`, que recibe el `INotificationCallback`, arma
    el `DuplexChannelFactory` con `ChannelSettings` y se libera con `ChannelCloser`;
  - `NotificationClient(NotificationCallback, ISessionChannelFactory, TimeProvider)`, con un parámetro por línea.
    `Dispose` solo desconecta, porque la fábrica ya no es suya. Sale `using Bastion.Contracts;`.
  - `ServerConnection` crea `var notificationCallback = new NotificationCallback();`, la fábrica y el cliente. Libera el
    cliente, luego la fábrica y luego los siete canales: el mismo orden de antes.
  - `NotificationCallback` sigue siendo concreto: no es un servicio externo, solo lanza eventos.
- **Pregunta 2:**
  - `NotificationCallback` tiene su `ILog`, y `ReceiveNotification(Notification? notification)` sale con Warn si llega
    nula. El parámetro también es anulable en `INotificationCallback`, como en `LogIn` (9.4.1).
  - Una sala actualizada sin sala registra Warn. Antes caía hasta el final sin rastro.
  - `DispatchMatchmakingNotification` pasa a `TryDispatchMatchmakingNotification`, que devuelve `bool` y entra en la
    cadena de `||`. Si nadie conoce el tipo, se registra "A notification of an unknown type was ignored. Type=…".
- **Pregunta 3:** `ToFriendRequestReceivedEventArgs`, `ToFriendshipStartedEventArgs`, `ToRoomUpdatedEventArgs(RoomState)`
  y `ToRoomClosedEventArgs`, cada uno junto a su `On…` (R-47). Cada rama queda como `OnX(ToXEventArgs(y))`.

**Verificación:**
- `Host` y `Client` compilan sin avisos de código en una compilación completa, CA1502 incluida. Pasan 514 pruebas.
- **Sonda `notification-callback`:** con 22 notificaciones, contando un tipo desconocido, los eventos y sus datos son
  iguales a los de `HEAD`. Solo se agregan los tres Warn nuevos: la nula, la sala sin sala y el tipo desconocido.
- **Sonda `notification-client`,** con una fábrica y un temporizador falsos:
  - al conectar, `Subscribe(token)`, el manejador de `Faulted` y un temporizador de 60 s;
  - el tick envía `KeepAlive`;
  - una falla del canal detiene el temporizador y avisa `Disconnected` una sola vez;
  - al desconectar quita el manejador y cierra el canal;
  - si `Subscribe` falla, aborta el canal y lanza `ConnectionLostException` o `ServerUnreachableException`;
  - si `KeepAlive` agota el tiempo, avisa `Disconnected`;
  - `Dispose` desconecta;
  - el `ServerConnection` real se crea y se libera sin errores.

**Commit de `Notifications`:** `fb4c3ec` (2026-11-11), en `review-standard-v2.4-host`, sin push.

### 367 a 373. `PrivateChat` (2026-11-11)

Los archivos son:
- `ConversationClient`, `IConversationClient` y `ConversationContractTranslator`;
- los registros `ConversationContact`, `ConversationPreview`, `ConversationTranscript` y `PrivateMessage`.

Revisión:
- **Cumple:**
  - 2.x y 9.4.1 en los públicos;
  - el `?:` de `lastMessage` en `ToPreview`: elige entre dos valores sin efectos secundarios (4.5.1) y no es un `return`.
- **Aplicado sin preguntas (reglas decididas, sin commit):**
  - **R-11:** los cuatro registros pasan a constructor explícito con `ThrowIfNull`.
    - `PrivateMessage` se copia con `with { SentAt = … }` en `PrivateConversationViewModel`, así que solo `SentAt` lleva
      `{ get; init; }`, como `WallsPerPlayer` en `MatchFormat`.
  - **R-14 y 5.3.1 en el traductor:**
    - `ToPreviews` y `ToTranscript` guardan la consulta en un `IEnumerable<T>` con nombre y la materializan con
      `new List<T>(…)`;
    - `ToTranscript` guarda el `ChatMute` en una variable;
    - `ToSender` y los dos `ToPrivateMessage` guardan los `??` en variables antes del `return new`.
  - **5.1.1 y R-45 en `ConversationClient`:** `MarkConversationRead` tenía una lambda de cuatro líneas que devolvía
    `true`.
    - Ahora es `Call(service => service.MarkConversationRead(…))`, con un `Call(Action)` y un `CompleteOperation`, como
      en `FriendClient`.
    - **R-14:** `ChatRejection rejection` va en su variable.
    - **R-47:** el orden es `Call<TResult>`, luego `ToClientException`, luego `Call(Action)` y luego `CompleteOperation`.
- **Verificación:**
  - `Client` compila sin avisos de código;
  - pasan las 136 pruebas del cliente;
  - la sonda `channel-injection` pasó `ListConversations` y `MarkConversationRead` (`Call(Action)`) por el canal falso,
    con éxito y con las cuatro fallas.
- **Nota para `Client`:** `PrivateConversationViewModel` crea el mensaje con `DateTime.UtcNow`, y la 10.4.1 pide usar el
  `TimeProvider` inyectado.
- **Pregunta 1 (4.4.1, repetición entre clases):**
  - el traductor arma `new PlayerTag(nombre ?? string.Empty, código ?? string.Empty)` tres veces más (el compañero de
    `ToTranscript`, `ToSender` y el compañero de `ToPreview`). Es lo mismo que el privado `ToPlayerTag` que se acaba de
    crear en `FriendContractTranslator` (328–341).
  - `ConversationClient.ToClientException` y `ChatClient.ToClientException` repiten las mismas tres líneas que convierten
    `FaultException<ChatMessageRejectedFault>` en `ChatMessageRejectedException`.

**Pregunta (367 a 373):**
1. Compartir esas dos piezas entre las clases. Recomendado: A.
   - **A:**
     - `FriendContractTranslator.ToPlayerTag(string? nickname, string? friendCode)` pasa a público, y
       `ConversationContractTranslator` lo usa en sus tres lugares;
     - un `ChatContractTranslator.ToMessageRejectedException(FaultException<ChatMessageRejectedFault> fault)` público
       que usan `ChatClient` y `ConversationClient`.
   - **B:** solo el `ToPlayerTag`.
   - **C:** dejarlo.

**Respuesta del usuario (2026-11-11):** «Sí, las dos».
- **Aplicado:**
  - `FriendContractTranslator.ToPlayerTag(string?, string?)` es público y va junto al otro `ToPlayerTag`.
  - `ConversationContractTranslator` lo usa en `ToTranscript`, `ToSender` y `ToPreview`, con
    `var partner = FriendContractTranslator.ToPlayerTag(…)` (R-51). Solo queda un `new PlayerTag(` en el cliente, dentro
    de ese método.
  - `ChatContractTranslator.ToMessageRejectedException(FaultException<ChatMessageRejectedFault> fault)` es público, con
    `ThrowIfNull` y `ChatRejection rejection` en su variable. `ChatClient` y `ConversationClient` lo devuelven desde su
    `ToClientException`.
- **Verificación:**
  - `Client` compila sin avisos de código;
  - pasan 514 pruebas;
  - la sonda `channel-injection` agregó la falla `ChatMessageRejectedFault` (`Muted`, con fecha). Los dos clientes del
    chat la dan como `ChatMessageRejectedException`, con el motivo y la fecha; los demás, como `ServerErrorException`,
    igual que antes.

**Commit de `PrivateChat`:** `4bfb855` (2026-11-11), en `review-standard-v2.4-host`, sin push.

### 374 a 383. `Rooms` (2026-11-11)

Los archivos son:
- `IRoomClient`, `RoomClient` y `RoomContractTranslator`;
- `PrivateRoom`, `PrivateRoomMember` y `PrivateRoomOptions`;
- `PrivateRoomGameMode`, `RoomCloseReason`, `RoomRejection` y `RoomRejectedException`.

Revisión:
- **Pasada 4 (dato):** la interfaz del juego todavía no usa el cliente de salas. `IRoomClient`, `PrivateRoom` y sus eventos
  solo los usan `ServerConnection` y `TestRoomNotifications`. Nadie lee `PrivateRoom.SeatCount`. Se queda, porque la
  pantalla de salas (CU-10, CU-11, Must) está por hacerse y el servidor ya lo implementa.
- **Cumple:**
  - `PrivateRoomOptions (enum, byte, byte)` se queda posicional por la R-16;
  - `RoomRejectedException` cumple la 9.6.1 (con datos);
  - los accesores de los eventos cumplen la 2.11.4;
  - `ToCloseReason` y los dos `switch` de modo tienen `default`.
- **Aplicado sin preguntas (reglas decididas, sin commit):**
  - **R-54:** `ToRejection` partía 14 casos en dos `switch`, con un `default` que delegaba en `ToPlacementRejection`.
    - Ahora es una tabla `_rejectionsByReason` (`IReadOnlyDictionary`) con `TryGetValue`, y
      `ArgumentOutOfRangeException` si falta el valor.
    - Sale `ToPlacementRejection`.
  - **R-48:** `ToContract(PrivateRoomOptions)` y `ToContract(PrivateRoomGameMode)` eran sobrecargas con salidas distintas.
    Pasan a `ToRoomOptions` y `ToRoomGameMode`, y `ToGameMode` pasa a `ToPrivateRoomGameMode` para que haga pareja.
    `RoomClient` usa `var contractOptions = RoomContractTranslator.ToRoomOptions(…)` (R-51, IDE0007).
  - **R-14 y 5.3.1:**
    - `ToRoomOptions` guarda el modo en una variable;
    - `ToPrivateRoom` guarda el código, las opciones y los miembros en variables;
    - los miembros pasan de `.Select(…).OrderBy(…).ToList()` en una línea a un `IEnumerable<PrivateRoomMember>` con un
      operador por línea, materializado con `new List<…>(…)`;
    - `ToMember` guarda su `??` en una variable.
  - **R-14 en `RoomClient.ToClientException`:** `RoomRejection rejection` y `var retryDelay = TimeSpan.FromSeconds(…)`.
  - **R-04:** `CallForRoom` guarda `RoomState state` antes de traducir, y `FindOwnRoom` cambia el `?:` del `return` por
    una guarda.
  - **R-45:** `Call(Action)` repetía los dos `catch` de `Call<TResult>`. Ahora los adapta con `CompleteOperation`, como
    `FriendClient`.
  - **R-47:** el orden es `CallForRoom`, `Call<TResult>`, `ToClientException`, `Call(Action)` y `CompleteOperation`.
    En el traductor: `ToRoomGameMode`, `ToPrivateRoomGameMode` y `ToMember`.
- **Verificación:**
  - `Client` compila sin avisos de código;
  - pasan las 136 pruebas del cliente.
  - **Sonda `client-probes/room-client`** (sesión `0da7ac4a`):
    - el traductor de `HEAD` frente al nuevo da 23 resultados iguales: los 14 rechazos y uno desconocido, los 3 modos y
      uno inválido, la sala completa, desordenada y con un apodo vacío, la vacía y la de modo inválido, y `HostLeft`;
    - `RoomClient` con un canal falso cuyo `Call(Action)` falla si se usa: `CreateRoom`, `FindOwnRoom` (con sala y sin
      sala) y `StartMatch` funcionan;
    - el rechazo da `TooManyAttempts` con 30 s de espera, y el endpoint caído y el tiempo agotado se traducen.
- **Pregunta 1 (pendiente de 291–297):** el cliente dice "options" (`PrivateRoomOptions`, `ChangeOptions`), pero su
  enumeración sigue con `RoomRejection.InvalidSettings`. Solo lo usa la tabla del traductor.
- **Pregunta 2 (2.2.2 y R-09):** `PrivateRoom (string, PrivateRoomOptions, int, IReadOnlyList<PrivateRoomMember>)` y
  `PrivateRoomMember (string, int, bool, bool)` son registros posicionales de cuatro parámetros. Solo los crea el
  traductor.
  - La R-09 permite agrupar los campos en otro registro o pasar a propiedades `init` con inicializador de objeto.
  - En el servidor, `RoomMemberSnapshot` usa propiedades `required … { get; init; }`.

**Preguntas (374 a 383):**
1. `RoomRejection.InvalidSettings` → `InvalidOptions` en el cliente, con su entrada en la tabla (recomendado: A; B,
   dejarlo).
2. Los dos registros de cuatro campos. Recomendado: A.
   - **A:** propiedades `required … { get; init; }` e inicializador de objeto en el traductor, como `RoomMemberSnapshot`.
   - **B:** agrupar `SeatCount` y `Members` en un registro `PrivateRoomSeating`, y buscar otra forma para el miembro.
   - **C:** dejarlos.

**Respuesta del usuario (2026-11-11):** «Sí, A en las dos».
- **Aplicado:**
  - `RoomRejection.InvalidOptions` en el cliente, con su entrada en `_rejectionsByReason`;
  - `PrivateRoom` y `PrivateRoomMember` con propiedades `required … { get; init; }`, y el traductor los crea con un
    inicializador de objeto (R-14: cada asignación es una variable o una propiedad).
- **Verificación:**
  - `Client` compila sin avisos de código;
  - pasan 514 pruebas;
  - la sonda `room-client` dio las mismas 42 líneas que antes del cambio. Las únicas diferencias son las tres esperadas:
    el rechazo se llama `InvalidOptions`. La sala y sus miembros se serializan igual.

**Commit de `Rooms`:** `84e8f0d` (2026-11-11), en `review-standard-v2.4-host`, sin push.

### 384 y 385. `ServerConnection` y `Sessions/InvalidSessionException` (2026-11-11)

- **`InvalidSessionException` (385):** cumple la 9.6.1, porque no lleva datos y tiene los tres constructores estándar.
- **`ServerConnection` (384):**
  - **Cumple:** es la clase de registro de los servicios del cliente (10.2.1). Crea los canales, la fábrica dúplex y
    los ocho clientes, y libera lo suyo en el orden de antes.
  - **D-06 (aplicado sin preguntas):** los siete canales se creaban en la declaración de sus campos (desde `c54aba2`),
    y el resto, en el constructor. Ahora todo se crea en el constructor, en el mismo orden, después de comprobar el
    `TimeProvider`.
  - **Verificación:**
    - `Client` compila sin avisos de código;
    - pasan las 136 pruebas del cliente;
    - la sonda `notification-client` crea y libera el `ServerConnection` real sin errores.
- **Commit:** `031592a` (2026-11-11), sin push.

### Cierre de la capa `Bastion.Client.Networking` (2026-11-11)

- **Archivos:** los 85 están revisados (301–385).
- **Commits locales en `review-standard-v2.4-host`:** `e83e6d3`, `c54aba2`, `5382eac`, `542c757`, `bae09c1`, `19ac951`,
  `fb4c3ec`, `4bfb855`, `84e8f0d` y `031592a`. Con `Contracts` y `Host`, la rama lleva 22 commits sobre la punta del
  PR #16.
- **R-27 no aplica:** la capa no tiene interfaces `I…Service`. `NotificationCallback` hereda la documentación del
  contrato con `<inheritdoc/>`.
- **Reglas nuevas o ampliadas en la capa:**
  - R-58 (puertos registrados);
  - R-50 en el callback del cliente (guarda con Warn);
  - la forma `CompleteOperation` (R-45) en los clientes con `Call(Action)`.
- **Notas para la revisión de `Client`:**
  - los campos `_received` y `_sent` de `FriendRequestsViewModel` (2.1.2);
  - avisar al jugador cuando el puerto configurado no sirve (Shore, 2004);
  - `DateTime.UtcNow` en `PrivateConversationViewModel` (10.4.1);
  - la pantalla de salas todavía no existe;
  - R-41 en los textos;
  - la R-52 en el `Program` del cliente;
  - los valores por omisión de `NoticeBox` y `AddFriendViewModel`.
- **Sigue `Client`.**
