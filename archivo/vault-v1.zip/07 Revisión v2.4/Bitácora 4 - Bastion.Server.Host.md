---
tags: [revision-v2-4]
---
# Bitácora 4 - Bastion.Server.Host
Volver a [[Índice de la revisión v2.4]]

Son 25 archivos (215 a 239), en orden de carpeta. Datos generales:
- **6.3:** solo `AccountService` y `LoginTranslator` tenían los `using` de terceros antes que los de `Bastion`.
- **Nulos:** todos los servicios convierten un argumento nulo en una falla tipada (`if (x is null) throw …Translator.ToFault(…)`).
- **Cliente:** cualquier `FaultException` genérica se convierte en `ServerErrorException`, sin usar su texto.
- **Cruzados, se preguntan al terminar el grupo que los tiene:**
  - los pares de `catch` de la base, al terminar los servicios;
  - el `new FaultException<T>(detalle, new FaultReason(mensaje))` que se repite en cada traductor, al terminar los
    traductores.

### 215 a 217. `AccountService`, `LoginTranslator` y `CallerAddress` (2026-11-10)

- **6.3 (incumplimiento, corregido):** `AccountService` y `LoginTranslator`.
- **7.1.2 (incumplimiento, corregido):** `AccountService` implementa el contrato `IAccountService` y no tenía
  `<inheritdoc/>`. Ahora lo lleva en la clase y en `LogIn`. El `<summary>` de `IAccountService` se escribe al revisar
  `Contracts`.
- **10.3.1:** `IServiceScopeFactory` y `GetRequiredService` dentro de un ámbito por llamada. Es justo la excepción de la
  frontera de red. Cumple.
- **9.2.1:** bitácora y `throw new FaultException(ServerFailureReason)` sin la excepción interna, igual que el ejemplo
  correcto de frontera de red. Cumple.
- **R-14 (incumplimiento, corregido), en `LoginTranslator`:**
  - `ToConnection` y `ToAttempt` llevaban `??` y `Trim()` en los argumentos;
  - los dos `ToFault` creaban `new …Fault()` y `new FaultReason(…)` dentro del `return`.
  - Ahora cada paso va en su variable.
- **`CallerAddress`:** cumple.
  - La condición de tres `||` con `TryGetValue` y `is not` no mezcla `&&` (R-24 no aplica).
  - `"0.0.0.0"` está en una constante.
- **Lectura L-20 (9.4.1 en la frontera de red, se pregunta):** `LogIn` no usa `ThrowIfNull`. Si `credentials` o `device`
  llegan nulos, lanza la falla de credenciales inválidas. Todos los servicios siguen esta forma.
- **R-10 en los textos (se pregunta):**
  - `ServerFailureReason = "The server could not complete the sign-in."` y la bitácora "The sign-in could not be saved".
  - La R-10 renombra los nombres con `SignIn`, pero no dice nada de los textos.
  - Hay textos con "sign-in" en `Host` (2), `Client` (3 en la bitácora) y `Client.Networking` (1 excepción). La interfaz
    (`Strings.resx`) usa "Sign in".
- **Compilación:** sin avisos de código. Ninguna prueba cubre `Host`.

**Preguntas (215 a 217):**
1. L-20 (recomendado: aceptar la falla tipada como forma de la 9.4.1 en una operación de servicio).
2. R-10 en los textos (recomendado: "log in" en la bitácora, las excepciones y las fallas; la interfaz sigue con "Sign in").

**Decisiones del usuario (215 a 217): A en las dos.**
- **R-40:** en una operación de servicio WCF, un argumento nulo se convierte en la falla tipada que corresponde.
- **R-41:** los textos del programa usan "login".
- `AccountService` ya dice "The server could not complete the login." y "The login could not be saved.". Los textos de
  `Client` y `Client.Networking` cambian al revisar sus archivos.
- Commit `81757eb`, sin push.

### 218 y 219. `ChatService` y `ChatTranslator` (2026-11-10)

- **Cumplen:**
  - **6.3:** `using` en orden.
  - **7.1.2:** `<inheritdoc/>` en la clase y en los tres miembros.
  - **10.3.1:** ámbito por llamada.
  - **R-40:** `RequireSessionToken` y `RequireText` convierten un nulo en falla tipada.
  - **R-28:** `return x ?? throw …`.
  - **4.3.2:** `default` con `ArgumentOutOfRangeException`.
  - **§11:** la bitácora sigue el formato "acción. Clave=valor".
- **Lectura L-21 (R-04 en el cuerpo de una lambda, se pregunta):**
  - `chat => ChatTranslator.ToReceipt(chat.SendMessage(token, checkedText, GetUtcNow()))` anida tres llamadas en una
    línea. El mismo patrón está en los servicios con un `Run` privado.
  - Se comprobó en un proyecto aparte que el compilador infiere `Run(nombre, (IServicio s) => s.Hacer(…), Traductor.ToX)`
    sin escribir los tipos.
- **Pasada 3:** `checkedText` → `messageText`. Va dentro de la pregunta 1.
- **5.3.1 y R-14 en los arreglos de los contratos (se pregunta para todos los traductores):**
  - `Messages = history.Entries.Select(ToMessage).ToArray()` dentro del `return`.
  - Hay 9 casos en 6 traductores. Los contratos usan arreglos (`LobbyChatMessage[]?`).
- **R-14 en las fallas (se pregunta para todos los traductores):** `new FaultException<T>(new …Fault(), new
  FaultReason(rejection.Message))` se repite en cada `ToFault`. En `LoginTranslator` ya se corrigió con variables.
- **Pasada 3 (se pregunta):** `entry.Line.Line.Sender.Nickname`. `ChatHistoryEntry.Line` es un `PostedChatLine`, y
  `PostedChatLine.Line` es un `ChatLine`. Aparece en 4 lugares.

**Preguntas (218 y 219):**
1. L-21 (recomendado: que `Run` reciba la llamada y la traducción por separado).
2. Arreglos de contrato (recomendado: un ayudante `ContractArray.ConvertAll(origen, convertidor)` en `Host`).
3. Fallas (recomendado: `FaultExceptionFactory.Create(detalle, rechazo)` en `Host`).
4. `Line.Line` (recomendado: `ChatHistoryEntry.Line` → `PostedLine` y variables en `ToMessage`).

**Respuesta del usuario:** acepta la A en las preguntas 2, 3 y 4. **Rechaza la A de la 1:**
- `return Run(nameof(…), (ILobbyChatService chat) => …, ChatTranslator.ToReceipt);` viola varias reglas: un `return`
  con una lambda y un grupo de método como argumentos no es "una sola llamada con argumentos simples" (R-04, R-14).
- Además se lee mal.
- `Run` es un nombre demasiado genérico.
- La forma actual (`return Run<…>(nameof(…), chat => …)`) tiene el mismo problema.

**Aplicado, sin commit:**
- **R-42:** `Host/Common/ContractArray.ConvertAll(IReadOnlyList<TSource>, Func<TSource, TItem>)`, hecho con un `for`.
  `ChatTranslator.ToChatLog` lo usa. Los otros 8 casos cambian al revisar su archivo.
- **R-43:** `Host/Common/FaultExceptionFactory.Create(detalle, rechazo)`. Lo usan `ChatTranslator` y `LoginTranslator`.
- **`ChatHistoryEntry.Line` → `PostedLine`:**
  - el registro de `Application`;
  - `LobbyChatService`, donde la lambda ahora se llama `postedLine`;
  - `TestLobbyChatService`;
  - `ChatTranslator.ToMessage`, con las variables `postedLine` y `line`.
- Compila sin avisos de código y pasan 158 + 220 + 136 pruebas.

**Opciones nuevas para la pregunta 1** (en todas, el `return` es una variable o una sola llamada con argumentos simples):
1. Un traductor de fallas por servicio (`TranslateChatFailures`), con un método privado por operación que abre su
   ámbito (`…InRequestScope`). **Recomendada.**
2. Una variable con la llamada (`Func<IServicio, Resultado>`), un ayudante con nombre (`CallInRequestScope`) y la
   traducción del resultado aparte.
3. Un escudo de fallas con `IErrorHandler` y sin `try`/`catch` en los servicios. Es lo que mejor se lee, pero es un cambio
   grande y hay que probarlo de punta a punta.
4. **Descartadas:** una clase por operación, y solo renombrar `Run`.

**El usuario pidió una variante de la opción 1** con un auxiliar que evite repetir el ámbito en cada operación.
- **Propuesta:** `Host/Common/RequestScope<TService> : IDisposable`.
  - Crea el ámbito en su constructor, resuelve `TService` en la propiedad `Service` y libera el ámbito en `Dispose`.
  - Cada operación abre `using var lobbyChat = new RequestScope<ILobbyChatService>(_scopeFactory);`.
  - Un método no sirve, porque el ámbito se cerraría al devolver el servicio.
- **Lo que no cubre:** la parte común de los `TranslateXFailures` entre servicios (sesión inválida y base de datos) se
  pregunta al terminar los servicios.

**El usuario pidió investigar** con los mismos criterios y una propuesta parecida que quite la repetición.
- **Experimento** en el scratchpad (`corewcf-probe`), con las mismas versiones del proyecto: CoreWCF 1.9.1 en el
  servidor y System.ServiceModel 10.0.652802 en el cliente, sobre net.tcp en el puerto 18765.
  - El servicio es `PerCall` y está registrado `Transient`, como los de `Host`. Recibe una dependencia `Scoped` en el
    constructor.
  - El contenedor usa `ValidateScopes = true`.
- **Resultados:**
  1. **CoreWCF crea un ámbito por llamada:** tres llamadas dieron tres instancias distintas, y cada una se liberó al
     terminar (liberadas: 0, 1, 2). Esto contradice la premisa de la excepción de la 10.3.1 ("el framework no permite
     inyectar dependencias con un ámbito por llamada"), por lo menos para los servicios `PerCall`.
  2. **`IErrorHandler` funciona:**
     - el cliente recibió `FaultException<ProbeFault>` con su detalle y su razón;
     - una excepción inesperada llegó como falla genérica;
     - el canal siguió `Opened` en los dos casos y aceptó la llamada siguiente.
  3. **Una sola línea registra el escudo:** `services.AddSingleton<IServiceBehavior, …>()` lo aplica a todos los
     servicios.
- Los ocho servicios de `Host` son `PerCall`. Hoy abren el ámbito a mano en 13 lugares (o con un `Run`).
  `FriendPresenceReporter` es un singleton fuera de WCF (es la L-08) y queda aparte.
- **Propuesta:** inyección por constructor de los servicios de aplicación, más un escudo de fallas (`FaultShield` +
  `ServiceErrorHandler` + `FaultTranslatorRegistry`) registrado una vez en `ServiceRegistration`.
  - Los servicios quedan sin `IServiceScopeFactory`, sin `Run`, sin `try`/`catch` y sin bitácora propia.
  - **Variantes parciales:** solo la inyección (los `try`/`catch` siguen en cada servicio), o solo el escudo (el ámbito
    a mano sigue).

**El usuario preguntó si se pueden evitar las fallas genéricas y escribir los errores en la bitácora.** Segundo
experimento:
- **Falla de servidor tipada:** con `ServerFailureFault { Kind, ErrorId }` y su `[FaultContract]` en la operación, el
  cliente recibió `FaultException<ServerFailureFault>`:
  - `Kind=DatabaseUnavailable` para una `DbException`;
  - `Kind=Unexpected` para cualquier otra excepción.
- **Sin el `[FaultContract]`:** el cliente recibió una falla sin tipo. Por eso cada operación tiene que declararla.
- **Bitácora:** el manejador tiene `OperationContext` en `ProvideFault` y en `HandleError`. Escribió la acción, la
  dirección de quien llama, el `ErrorId` (el mismo que recibió el cliente), el tipo de falla y el de la excepción.
- El canal siguió `Opened`.
- **11.1.1:** un rechazo es una excepción manejada, así que va como mínimo en **Warn**. Una falla del servidor va en
  **Error**, con la excepción como segundo parámetro.
- **Datos:** hoy el código ya manda fallas sin tipo (`FaultException(ServerFailureReason)`). Los contratos tienen 30
  operaciones y 44 `[FaultContract]`. El cliente convierte cualquier `FaultException` en `ServerErrorException`.
- **Propuesta ajustada:**
  - `ServerFailureFault` + `ServerFailureKind` en `Contracts`, con su `[FaultContract]` en las 30 operaciones;
  - el escudo convierte los rechazos en su falla tipada (Warn) y cualquier otra excepción en `ServerFailureFault`
    (Error con `ErrorId`);
  - los servicios lanzan la excepción del rechazo, por ejemplo `?? throw new InvalidSessionException()`, en lugar de
    llamar al traductor;
  - el cliente atrapa `FaultException<ServerFailureFault>` al revisar `Client.Networking`.

**El usuario prefiere**, antes que una falla tipada nueva, la propagación y las fallas propias del lenguaje y del
framework. Tercer experimento:
- Para las fallas del servidor, el manejador usa la `FaultException` de WCF con
  `FaultCode.CreateReceiverFaultCode(new FaultCode("DatabaseUnavailable" | "Unexpected"))` y la razón
  `"The server could not complete the request. ErrorId=…"`.
- El cliente recibió `IsReceiverFault=True`, el `SubCode` y el `ErrorId` en todas las operaciones, también en la que no
  declara ningún `[FaultContract]`. El canal siguió `Opened`.
- **Propuesta (propagación):**
  - adentro, las excepciones se propagan; se usan las predefinidas (9.3.2) y las propias solo para los rechazos que
    cruzan el contrato (ya existen) y para la R-38;
  - los servicios no atrapan nada, y la R-40 lanza la excepción del rechazo;
  - el escudo es el único punto donde termina la propagación y donde se escribe en la bitácora (11.1.1). Un rechazo
    registrado se convierte en su falla tipada de hoy y va en Warn. Cualquier otra excepción se convierte en una falla
    *receiver* con subcódigo y `ErrorId` y va en Error, con la excepción;
  - los contratos no cambian. Los nombres de los subcódigos van en una sola clase de constantes en `Contracts`, que
    comparten el servidor y el cliente (2.10.1, 4.4.2).

**El usuario pidió que el contrato sí declare las fallas del servidor.** Cuarto experimento, con el tipo propio de WCF
`System.ServiceModel.ExceptionDetail`:
- **Contrato:** `[FaultContract(typeof(ExceptionDetail))]` en la operación.
- **Servidor:** `new FaultException<ExceptionDetail>(detalle, razón, código receiver)`. El detalle se arma con
  `new ExceptionDetail(new InvalidOperationException("The server could not complete the request. ErrorId=…"))`, que es
  una excepción limpia y no la real.
- **Cliente:** recibió `FaultException<ExceptionDetail>` con `IsReceiverFault=True`, el `SubCode`,
  `Detail.Type=System.InvalidOperationException` y `Detail.Message` con el `ErrorId`. **Sin la traza ni la excepción
  interna.**
- La operación que **no** lo declara también lo recibió tipado, porque el cliente de WCF ya conoce `ExceptionDetail`.
  Declararlo deja escrito en el contrato lo que puede pasar, y una prueba por reflexión puede exigirlo en las 30
  operaciones.
- El canal siguió `Opened`.

**El usuario pidió una sola propuesta, basada en una técnica válida para el proyecto, que reúna todo lo que pidió:**
1. Cada `return` es una variable o una sola llamada con argumentos simples (R-04, R-14) y se lee bien (D-06).
2. Sin nombres genéricos como `Run`.
3. Sin repetición: ni el ámbito, ni los `Run`, ni los `catch`.
4. Sin fallas genéricas, y con cada error en la bitácora.
5. Propagación y excepciones propias del lenguaje antes que fallas tipadas.
6. El contrato declara las fallas del servidor.
7. Sin comentarios (R-39).
8. Dentro del estándar.

**Técnica propuesta: barrera de fallas** (*Fault Barrier*, Barry Ruzek, *Effective Java Exceptions*, Oracle, 2007),
que distingue entre *contingencias* y *fallas*. En .NET y WCF se implementa como el patrón *Exception Shielding*
(Microsoft patterns & practices), con `IErrorHandler`.
- **Contingencias:** los rechazos de negocio de hoy. Se convierten en las fallas tipadas que ya existen.
- **Fallas:** las excepciones predefinidas y las de la R-38. Se propagan sin atraparse hasta la barrera, que las
  registra una vez en Error y responde con `FaultException<ExceptionDetail>` (código receiver, subcódigo y `ErrorId`).
- Los servicios reciben sus dependencias por constructor, porque CoreWCF da un ámbito por llamada.
- Los contratos declaran `ExceptionDetail` en sus 30 operaciones, y una prueba por reflexión lo exige.
- **Límite:** los servicios en segundo plano (`MatchmakingBackgroundService`, `RoomBackgroundService` y
  `FriendPresenceReporter`) no pasan por WCF, así que necesitan su propia barrera. Se revisan en su archivo.

**El usuario no acepta cuatro contras** y pidió investigar a fondo cómo evitarlos:
1. usar `ExceptionDetail` como error público;
2. que el `ErrorId` viaje dentro del mensaje;
3. que un rechazo nuevo sin registrar salga como falla del servidor;
4. que los servicios en segundo plano necesiten su propia barrera con `catch` de tipos conocidos.

**Investigación:**
- **9.3.1:** no tiene excepción para manejadores de nivel superior; todo `catch` es del tipo específico.
- **9.6.1:** pide heredar de `Exception` y ser `sealed`, pero no impide implementar una interfaz.
- **Microsoft Learn**, "Specifying and Handling Faults in Contracts and Services":
  - para los errores que el cliente maneja, recomienda fallas **declaradas** con `[FaultContract]` y un tipo de detalle
    propio;
  - `ExceptionDetail` / `IncludeExceptionDetailInFaults` son solo para depurar y pueden exponer información interna.
- **Microsoft Learn**, "Unhandled exceptions from a BackgroundService" (.NET 6): la excepción se registra en el
  `ILogger` y el host se detiene. El valor por defecto es `StopHost`; la única alternativa es `Ignore`.
- La página sobre `IErrorHandler` dio 404 y no se reintentó.
- **Excepciones del servidor:** hay 11 propias. Nueve son rechazos y cada uno tiene exactamente una falla tipada en
  `Contracts`. Las otras dos son fallas (`MatchRepositoryException`, `RoomRepositoryException`).
- **Experimento `barrier-check`:**
  - con un rechazo marcado y sin traductor, el arranque se detuvo con la lista de los que faltaban;
  - con el catálogo completo, arrancó;
  - en un `BackgroundService`, la misma barrera atrapó la `DbException`, la registró con `ErrorId` y el ciclo siguió;
  - un error de programación lo registró .NET y el host se detuvo.
- **Propuesta resultante:**
  - `ServerFailureFault { Kind, ErrorId }` declarada en las 30 operaciones;
  - la interfaz marcadora `IContractRejection` en los 9 rechazos;
  - una guarda de arranque en las dos direcciones: cada rechazo marcado tiene traductor, y cada falla declarada en
    `Contracts` tiene quien la produce;
  - una prueba que clasifica cada excepción propia como rechazo o como falla;
  - una sola clase `FaultBarrier`, que usan el manejador de WCF y los servicios en segundo plano
    (`ContainBackgroundFailures`).
- **Lo que no se puede quitar sin cambiar el estándar:** que un error de programación en segundo plano detenga el host.
  Se registra, pero mantener vivo el ciclo pediría `catch (Exception)`, que la 9.3.1 prohíbe.

**El usuario no quedó convencido con ninguna** (2026-11-11). Pidió revisar si las repeticiones originales se pueden
sacar a un método privado y luego hacer de ese método su propia clase.
- **Repeticiones en los ocho servicios WCF (código de hoy):**
  - `catch` en las operaciones con respuesta:
    - `InvalidSessionException`: 8;
    - `DbException`: 8;
    - `DbUpdateException`: 3;
    - `MatchRepositoryException`: 4;
    - `RoomRepositoryException`: 1;
    - en total, 24 bloques.
  - Ámbito con `CreateScope` y `GetRequiredService`: 9 lugares.
  - `RequireSessionToken`: 4 métodos y 3 `if` en línea.
  - `GetUtcNow`: 5 métodos y 3 expresiones en línea.
  - `ServerFailureReason` y `_logger`: uno por servicio.
  - **No son la misma repetición:**
    - las operaciones de un solo sentido registran y no lanzan (`RunOneWay` y `LeaveRoom`);
    - los `catch` de los servicios en segundo plano tienen su contexto propio.
- **Propuesta:**
  - **Técnicas:** *Extract Method* seguido de *Extract Class* (Fowler, *Refactoring*, 2.ª ed., 2018), con el `try`/`catch`
    como *Execute Around Method* (Beck, *Smalltalk Best Practice Patterns*, 1997).
  - **`Host/Common/RequestFailureTranslator`:** clase estática con `TranslateSessionAndDatabaseFailures(nombre, operación)`,
    con una sobrecarga para `Func<TResult>` y otra para `Action`.
    - Atrapa los cinco tipos comunes.
    - En los cuatro de base de datos registra Error con `Operation=` y lanza `FaultException(ServerFailureReason)`.
  - **Cada servicio conserva un método privado (`TranslateChatFailures`)** solo con sus propios rechazos, alrededor de
    la llamada a la clase.
  - **Piezas de apoyo:**
    - `RequestScope<TService> : IDisposable` para el ámbito;
    - `SessionTranslator.RequireSessionToken`;
    - `OperationWithoutResult.ToFunction(Action)` para las operaciones `void`.
  - Cada operación es un `Func`/`Action` en variable y un `…InRequestScope` privado.
- **Comprobado en el scratchpad** (`extract-class`, copia de `src` del servidor):
  - **Compilación:** `ChatService`, `FriendshipService` (con operaciones con resultado y `void`), `MatchService` y
    `SessionService` compilan sin avisos de código, incluida la CA1502.
  - **Ejecución:** con servicios de aplicación falsos que lanzan, los nueve casos dieron lo mismo que hoy:
    - la sesión inválida, el rechazo del chat y el rechazo de amistad llegaron como su falla tipada;
    - la base de datos y el repositorio llegaron como falla sin tipo, con su registro Error;
    - el error de programación se propagó sin cambios;
    - se crearon 8 ámbitos y se liberaron 8.
- **Mejora de paso:** `RoomService.FindOwnRoom` hoy solo atrapa la sesión inválida, así que una falla de base de datos
  sale sin registro. Con la clase queda registrada.
- **Preguntas:**
  1. la forma (dos capas);
  2. los nombres;
  3. un texto de falla del servidor o uno por servicio;
  4. el contexto de la bitácora (`MatchId`, `IpAddress`);
  5. `RequestScope`;
  6. `RequireSessionToken`;
  7. las operaciones de un solo sentido;
  8. `GetUtcNow`.

**Decisión del usuario (218 y 219, pregunta 1):** la **opción 1 tal como se propuso al principio**, sin la clase
compartida ni `RequestScope`. Pidió ver de nuevo las opciones originales y eligió esa.
- **R-44:** cada operación de un servicio WCF:
  - deja su llamada en una variable `Func<…>` que apunta a un método privado `…InRequestScope`;
  - devuelve `Translate…Failures(nameof(…), variable)`.
- **`…InRequestScope`:** abre el ámbito, pide el servicio de aplicación, llama y traduce el resultado. Cada línea es un
  paso.
- **`Translate…Failures`:** solo convierte excepciones en fallas, con los `catch` de hoy sin cambios.
- **Aplicado en `ChatService`:**
  - `checkedText` → `messageText`;
  - en `SendMatchChatMessage`, el texto va en su variable antes del `MatchChatSubmission`;
  - `ServerFailureReason`, `_logger` y los textos de la bitácora siguen igual.
- **Verificación:**
  - `Host` compila sin avisos de código;
  - pasan 158 + 220 + 136 pruebas;
  - la sonda del scratchpad dio los mismos cinco resultados del chat que antes, con la bitácora de `ChatService`.
- **Queda para cuando se revisen los otros servicios:** la repetición del ámbito y de los `catch` comunes entre
  servicios (lo que cubrían `RequestScope` y `RequestFailureTranslator`).

**Commit de `Chat`:** `83ee729` (2026-11-11), sin push.

### 220 a 222. `FriendPresenceReporter`, `FriendshipService` y `FriendshipTranslator` (2026-11-11)

- **`FriendshipTranslator` (222), aplicado con reglas ya decididas:**
  - **R-42:** los cuatro `Select(…).ToArray()` pasan a `ContractArray.ConvertAll`, en variables: `friends`,
    `entries`, `receivedRequests` y `sentRequests`.
  - **R-43:** `ToFault` usa `FaultExceptionFactory.Create`.
  - **R-14:** `ToNotification`, `ToSearchEntry` y `ToEntry` llamaban a un convertidor dentro del `return new …`. Ahora
    va antes, en `presence` o `relationship`.
  - **6.3:** sale `System.Linq` y entra `Bastion.Server.Host.Common`.
  - **Verificado:** con datos de prueba, el traductor viejo (de `HEAD`) y el nuevo dan el mismo JSON en `ToFriendList`,
    `ToFriendRequestList`, `ToSearchEntries`, `ToNotification` y en el detalle y la razón de `ToFault`.
  - **Cumple:** 4.3.2 (`default` con `ArgumentOutOfRangeException`), complejidad (`ToReason` = 9) y pasada 4 (los ocho
    públicos se usan, en el servicio o en `NotificationChannelRegistry`).
- **`FriendshipService` (221):**
  - **7.1.2 (incumplimiento, corregido):** no tenía `<inheritdoc/>`; ahora lo lleva en la clase y en las ocho
    operaciones.
  - **R-44 (pendiente de la pregunta 1):** `Run(…, services => { …; return true; })` y `RunResponse` usan lambdas de
    varias líneas (5.1.1) y `GetRequiredService` encadenado.
    - Cuatro operaciones son `void`, y la R-44 no dice cómo pasa una `Action` por `Translate…Failures`.
  - **Repetición:** la guarda del código de amigo aparece en tres formas:
    - `RequireRequestCode` (×3, `RequestNotFound`);
    - un `if` en `SendFriendRequest` (`PlayerNotFound`);
    - un `if` en `RemoveFriend` (`NotFriends`).
  - **Pasada 3:** `code` no dice de quién es el código; `requestService` puede ser cualquier servicio.
- **`FriendPresenceReporter` (220):**
  - **L-08 (10.3.1):** es un singleton que crea el contenedor, no CoreWCF.
    - La excepción de la 10.3.1 habla de la frontera de red.
    - Necesita un ámbito por operación porque `IFriendPresenceService` es `Scoped` (usa el `DbContext`).
  - **`Run`:** el mismo nombre genérico que se quitó con la R-44.
    - Recibe la llamada como lambda en línea (`presenceService => …`).
    - No traduce nada: registra y sigue.
  - **Cumple:** 11.1.1 (`DbException` en Error y `ObjectDisposedException` en Warn, sin relanzar), 11.3.1, 9.1.1 y
    10.4.1.
- **Pasada 3, `FriendshipTranslator`:**
  - `ToEntry` (junto a `ToRequestEntry` y `ToSearchEntry`);
  - `ToState` (devuelve `PresenceState`);
  - `ToNotification` (junto a `ToRequestNotification` y `ToFriendshipStartedNotification`);
  - `ToResult` (devuelve `FriendRequestResult`).
- **6.2:** los privados de `FriendshipTranslator` no siguen el orden de los públicos (lo que se decidió en
  `RoomRepository`).
- **Prototipo en el scratchpad** (`friends-proposal`):
  - la propuesta de `FriendshipService` y la de `FriendPresenceReporter` compilan sin avisos de código;
  - la sonda dio:
    - `ListFriends` devuelve lo mismo y, con una `DbUpdateException`, la falla del servidor con su Error;
    - `AcceptFriendRequest` (`void`) da las fallas tipadas de rechazo y de sesión, y la del servidor con Error en la
      base;
    - los nulos (`RemoveFriend`, `SendFriendRequest` y `CancelFriendRequest`) dan su falla sin llegar al servicio de
      aplicación.

**Preguntas (220 a 222):**
1. Operaciones `void` con la R-44 (recomendado: una sobrecarga con `Action` que pasa a `Func<bool>` con
   `CompleteOperation`).
2. Guarda del código de amigo (recomendado: un `RequireFriendCode(friendCode, rejectionWhenMissing)`).
3. Nombres (recomendado: renombrar en el servicio y en el traductor).
4. Orden de los privados del traductor (recomendado: el de los públicos).
5. L-08 (recomendado: leer la excepción de la 10.3.1 como válida también para un singleton que necesita un servicio
   `Scoped` por operación).
6. Forma de `FriendPresenceReporter` (recomendado: la de la R-44, con `…InOwnScope` y `LogPresenceFailures`).

**Decisiones del usuario (220 a 222): A en las seis.**
- **R-45:** las operaciones `void` usan la sobrecarga con `Action` y `CompleteOperation`.
- **Guarda:** `RequireFriendCode(friendCode, rejectionWhenMissing)` reemplaza a `RequireRequestCode` y a los dos `if`.
- **Nombres:**
  - en el servicio: `requesterCode`, `recipientCode`, `removedFriendCode`, `friendRequests` y `friendList`;
  - en el traductor: `ToFriendListEntry`, `ToPresenceState`, `ToPresenceNotification` (también en
    `NotificationChannelRegistry`) y `ToFriendRequestResult`.
- **R-47:** los privados del traductor siguen el orden de los públicos.
- **R-46:** `FriendPresenceReporter` queda con `…InOwnScope` y `LogPresenceFailures`.
- **No respondido:** si `ChatTranslator.ToNotification` pasa a `ToLobbyChatNotification`. Se pregunta de nuevo.
- **Verificación:**
  - `Host` compila sin avisos de código;
  - la sonda dio 19 resultados iguales a los de antes:
    - el traductor da el mismo JSON que en `HEAD`;
    - los cuatro casos de las operaciones `void` y los tres nulos dan la misma falla;
    - en `FriendPresenceReporter`, la `DbException` va en Error, el proveedor liberado en Warn, ninguna se relanza y el
      error de programación sigue de largo.


**Commit de `Friends`:** `0f43b0f` (2026-11-11), sin push.
- **`ChatTranslator.ToNotification` → `ToLobbyChatNotification`** (aprobado el 2026-11-11): commit `b2e3e79`, sin push.

### 223 y 224. `MatchService` y `MatchTranslator` (2026-11-11)

- **`MatchTranslator` (224):**
  - **R-43, aplicado:** `ToFault` usa `FaultExceptionFactory.Create` con el detalle en una variable.
  - **Cumple:** 6.3, 2.2.2 (`ToAbandonedNotification` tiene tres parámetros) y la pasada 4 (cada método tiene un uso).
  - **Pasada 3:** el parámetro de `ToFault` se llama `exception`. En los demás traductores y en `FaultExceptionFactory`
    se llama `rejection`.
- **`MatchService` (223):**
  - **Cumple:** 7.1.2, 6.3 y 11.1.1.
  - **R-44 (pendiente):** la única operación abre el ámbito y atrapa todo dentro del método público.
    - Es `void`, y el servicio no tiene ninguna operación con resultado.
    - Con la R-45 al pie de la letra quedaría una sobrecarga `Func<TResult>` que solo usaría el adaptador.
  - **Bitácora:** hoy registra el `MatchId`. La forma de la R-44 solo pasa `nameof(…)`.
  - **Texto:** `ServerFailureReason = "The server could not close the match."`. Desde las partidas de cuatro, abandonar
    no siempre cierra la partida (`AbandonmentNotice.IsMatchOver`).
  - **Para la revisión de `Contracts`:** el `<summary>` de `IMatchService.AbandonMatch` dice "that player loses and the
    rival wins". Tampoco vale para cuatro jugadores.
- **Comprobado:**
  - `Host` compila sin avisos;
  - la propuesta compila aparte;
  - una sonda comparó el servicio de `HEAD` con la propuesta en siete casos: con éxito, token nulo, sesión inválida, no
    juega la partida, repositorio, base de datos y error de programación;
  - todos dan lo mismo, salvo los dos textos que se preguntan (la bitácora y la razón de la falla).

**Preguntas (223 y 224):**
1. Servicio con solo operaciones `void` (recomendado: un solo `TranslateMatchFailures(…, Action)` con los `catch`, sin
   sobrecarga `Func` ni `CompleteOperation`; la R-45 se precisa así).
2. `MatchId` en la bitácora (recomendado: `TranslateMatchFailures(nameof(AbandonMatch), matchId, abandonMatch)` y los
   textos de `ChatService` con `Operation=…; MatchId=…`).
3. Razón de la falla (recomendado: "The server could not record the match abandonment.").
4. `exception` → `rejection` en `MatchTranslator.ToFault` (recomendado: sí).

**Decisiones del usuario (223 y 224): A en las cuatro.**
- **R-45 precisada:** `MatchService` tiene un solo `TranslateMatchFailures(string, int, Action)` con los `catch`, sin
  sobrecarga `Func` ni `CompleteOperation`.
- **Bitácora:** el envoltorio recibe `operationName` y `matchId`; los textos son los de `ChatService` con
  `Operation=AbandonMatch; MatchId=…`.
- **Razón de la falla:** "The server could not record the match abandonment."
- **Nombre:** el parámetro de `MatchTranslator.ToFault` se llama `rejection`.
- **Verificación:**
  - `Host` compila sin avisos de código (solo NU1902/NU1903 de NuGet);
  - la sonda volvió a dar los siete casos: cinco iguales y los dos de falla del servidor con los textos nuevos, como se
    decidió.

**Commit de `Matches`:** `e03286a` (2026-11-11), sin push.

### 225 a 227. `MatchmakingBackgroundService`, `MatchmakingService` y `MatchmakingTranslator` (2026-11-11)

- **`MatchmakingTranslator` (227), aplicado por D-07:**
  - **R-43:** `ToFault` usa `FaultExceptionFactory.Create`.
  - **R-42:** los participantes van con `ContractArray.ConvertAll` en la variable `participants`; sale `System.Linq` y
    entra `Bastion.Server.Host.Common`.
  - **R-14:** `searchEndedReason` va en una variable antes del `return`. El `Reason = ToReason(…)` de la falla se queda
    como en `FriendshipTranslator`, porque es una asignación y no un `return`.
  - **R-47:** `ToReason(SearchRejection)` sube antes de `ToMatchFoundParticipant`, porque `ToFault` es el primer público.
  - **Cumple:** 4.3.2 (los dos `switch` con `default`) y la pasada 4 (cada método tiene un uso).
  - **Pasada 3 (pregunta 3):** tres sobrecargas `ToNotification` devuelven tres notificaciones distintas. Quien llama
    (`NotificationChannelRegistry`) solo sabe cuál arma por el tipo del argumento.
- **`MatchmakingService` (226):**
  - **Cumple:** 7.1.2, 6.2, 6.3, 9.1.2, 10.4.1 y 11.3.1.
  - **R-44 y R-45 (forma decidida, propuesta en la copia aparte):** `StartSearch` deja su llamada en `startSearch` hacia
    `StartSearchInRequestScope` y pasa por `TranslateMatchmakingFailures(nameof(StartSearch), startSearch)`. Las tres
    operaciones son `void`, así que hay un solo envoltorio con `Action`, sin `CompleteOperation` (R-45 precisada).
  - **Bitácora de `StartSearch`:** pasa a `Operation=StartSearch` como en los demás servicios. Se conserva el verbo de hoy,
    «could not be read», porque `StartSearch` solo lee el repositorio de partidas.
  - **Operaciones de un sentido (pregunta 1):** `CancelSearch` y `ConfirmPresence` son `IsOneWay`. Una falla no llega al
    cliente, así que hoy no traducen: registran y siguen, por `RunOneWay` y `RunInRequestScope`. La R-44 quitó los
    `Run`, y falta decidir la forma de estas. `RoomService.LeaveRoom` tiene el mismo caso.
  - **Pasada 3 (pregunta 2):** `IMatchSearchService searchService`. En la solución también existe la búsqueda de jugadores
    (`FriendshipService.SearchPlayers`).
  - **Para `Contracts`:** el `<exception cref="FaultException">` de `StartSearch` dice solo "could not reach the
    database"; también sale cuando falla el repositorio de partidas.
- **`MatchmakingBackgroundService` (225):**
  - **Cumple:** 2.3.1, 2.3.2 (`ReviewIntervalSeconds` es `const`; el `TimeSpan` es `static readonly` porque no puede ser
    `const`), 2.14.3, 3.4.1 (`using var timer = new …`), 10.4.1 y R-23 (la llamada con `GetUtcNow()` como argumento se
    deja).
  - **10.1.1 (pregunta 4):** recibe la clase concreta `MatchmakingDispatcher`. La regla define servicio externo como el
    colaborador que hace E/S, guarda estado compartido o no es determinista, y el despachador revisa la cola compartida,
    crea partidas en la base y avisa por la red. `RoomBackgroundService` recibe `IRoomKeeper`.
  - **Fallas:** las conocidas se atrapan abajo (`RankedMatchCreator` atrapa `MatchRepositoryException`;
    `NotificationChannelRegistry.NotifyPlayer` atrapa `CommunicationException` y `TimeoutException`). Un error de
    programación detiene el host, que es lo que hace .NET por omisión. Sin cambio: el usuario descartó las barreras.
- **Comprobado:**
  - `Host` del repositorio (con el traductor) y `Host` de la propuesta compilan sin avisos de código (solo NU1902/NU1903);
  - una sonda comparó `HEAD` con la propuesta:
    - traductor: 11 resultados iguales (las tres fallas, las tres razones de fin, la presencia y la partida encontrada);
    - servicio: 21 casos iguales (siete por operación: con éxito, token nulo, sesión inválida, rechazo, repositorio,
      base de datos y error de programación), también en cuántas veces llega al servicio de aplicación;
    - bitácora: iguales en las operaciones de un sentido; en `StartSearch` cambia solo el texto, como se dijo arriba.

**Preguntas (225 a 227):**
1. Forma de las operaciones de un sentido (recomendado: A, `LogOneWayFailures(nameof(…), sessionToken, operación)`, que
   tiene la guarda del token nulo y los `catch`, y cada operación pasa su `…InRequestScope` como grupo de método en una
   variable `Action<string>`). Pasaría a regla para `RoomService.LeaveRoom`.
2. `searchService` → `matchSearch` (recomendado: sí, como `lobbyChat`, `friendRequests` y `friendList`).
3. `ToNotification` ×3 → `ToMatchFoundNotification`, `ToPresenceRequestedNotification` y `ToSearchEndedNotification`,
   con sus tres llamadas en `NotificationChannelRegistry` (recomendado: sí, y como regla para `PrivateChatTranslator`).
4. 10.1.1 en `MatchmakingBackgroundService` (recomendado: A, `IMatchmakingDispatcher` en `Application`, registrado como
   `AddSingleton<IMatchmakingDispatcher, MatchmakingDispatcher>()`).

**Decisiones del usuario (225 a 227): acepta la 2, la 3 y la 4.** Sobre la 1 preguntó si la forma A enmascara los
errores y si no usa la propagación.
- **2:** `matchSearch` (en la propuesta del servicio).
- **3 (R-48):** `ToMatchFoundNotification`, `ToPresenceRequestedNotification` y `ToSearchEndedNotification`, con sus tres
  llamadas en `NotificationChannelRegistry`.
- **4 (R-49):** `IMatchmakingDispatcher` (nuevo, en `Application/Matchmaking`), `MatchmakingDispatcher` lo implementa,
  `ServiceRegistration` registra `AddSingleton<IMatchmakingDispatcher, MatchmakingDispatcher>()` y el servicio en segundo
  plano recibe la interfaz.
- **Verificación:** `Host` compila; pasan las 220 pruebas de aplicación. Queda un aviso nuevo, IDE0007, en
  `NotificationChannelRegistry.cs:105` (ver la pregunta 5).

**Prueba de CoreWCF sobre la pregunta 1** (`oneway-experiment` en el scratchpad): servidor CoreWCF 1.9.1 y cliente
`System.ServiceModel` 10.0.652802, net.tcp con `SecurityMode.None` y el extremo configurado en código. Una operación
`IsOneWay` que atrapa y registra, otra que deja salir un `InvalidOperationException` y otra que lanza `FaultException`.
- **Canal por llamada, como `ServiceChannel` del cliente (llamar y `Close`):** en los tres casos el cliente no recibe nada.
  No hay excepción ni en la llamada ni en el `Close`.
- **Mismo canal usado otra vez:** después de la excepción que se escapa, la llamada siguiente falla con
  `CommunicationException` y el canal queda `Faulted`. Con la `FaultException` o con la falla atrapada, el canal sigue y
  responde.
- **Bitácora del servidor:** con CoreWCF en `Trace` (370 líneas), no hay ningún registro de las dos excepciones que se
  escapan.
- **Lectura:** en una operación de un sentido, dejar que la excepción se propague fuera del servicio la pierde: no llega
  al cliente ni a la bitácora. La excepción sí se propaga sin `catch` desde `Application` hasta `Host`. `Host` es el último
  lugar que puede registrarla (11.1.1: se registra donde se maneja al final). `LogOneWayFailures` atrapa solo dos tipos
  conocidos (9.3.1); lo demás (un error de programación) sigue de largo y CoreWCF lo pierde, hoy y con A o B.
- **Del cliente:** `MatchSearchViewModel.CancelSearch` termina la búsqueda en pantalla en cuanto envía el mensaje; no espera
  respuesta.

**Pregunta 5 (L-01, 3.4.1):** `MatchFoundNotification notification = MatchmakingTranslator.ToMatchFoundNotification(…)`.
IDE0007 pide `var` porque el nombre del método contiene el tipo. La letra de la 3.4.1 da tres casos (`new`, un cast, un
método estático que devuelve el tipo que lo declara). También dice que el tipo va explícito en «llamadas a métodos cuyo
tipo de retorno no aparece en la expresión», y que la definición coincide con la de IDE0007. Precedente sin revisar:
`var friend = FriendContractTranslator.ToPlayerTag(…)` en `NotificationCallback` (cliente).

**Decisión del usuario sobre la pregunta 1 (después de la prueba de CoreWCF): A (R-50).**
- `CancelSearch` y `ConfirmPresence` guardan su `…InRequestScope` en una variable `Action<string>` (grupo de método) y
  llaman `LogOneWayFailures(nameof(…), sessionToken, operación)`, que tiene la guarda del token nulo (Warn) y los dos
  `catch` de hoy, sin relanzar. Los textos de la bitácora no cambian.
- `MatchmakingService` pasó al repositorio con la R-44 en `StartSearch`, `matchSearch` y el orden de Chat y Friends.
- **Verificación con el código final:**
  - `Host` compila sin errores;
  - la sonda dio los 11 resultados del traductor y los 21 casos del servicio iguales a `HEAD`;
  - en la bitácora solo cambia el texto de `StartSearch` (`Operation=StartSearch`).
- **Sin commit:** falta la pregunta 5; el aviso IDE0007 de `NotificationChannelRegistry.cs:105` sigue en una compilación
  completa (`--no-incremental`).

**Decisión del usuario sobre la pregunta 5: `var` (R-51).** `var notification = MatchmakingTranslator.ToMatchFoundNotification(…)`.
`Host` compila sin avisos de código en una compilación completa (solo NU1902/NU1903); pasan 220 pruebas de aplicación y
158 de dominio.

**Commit de `Matchmaking`:** `8a231a1` (2026-11-11), sin push.

### 228 y 229. `ConversationService` y `PrivateChatTranslator` (2026-11-11)

- **`ConversationService` (228), aplicado por D-07:**
  - **7.1.2:** `<inheritdoc/>` en la clase y en las cuatro operaciones.
  - **R-44 y R-45:** sale `Run`. Cada operación deja su llamada en una variable hacia su `…InRequestScope` y pasa por
    `TranslateConversationFailures`. `MarkConversationRead` es `void` y el servicio tiene operaciones con resultado: usa la
    sobrecarga con `Action` y `CompleteOperation`. Así sale también la lambda de varias líneas con `return true;` (5.1.1).
  - **R-04:** cada `…InRequestScope` guarda el resultado de `Application` en una variable (`summaries`, `conversation`,
    `message`) antes de traducirlo.
  - **R-28, R-40:** el `if (text is null)` pasa a `RequireText`, igual al de `ChatService`.
  - **Nombre nuevo:** la variable del servicio se llama `privateChat`, como `lobbyChat` y `matchChat` en `ChatService`.
  - **Cumple:** 2.2.2 (`SendPrivateMessage` tiene tres parámetros), 6.2, 6.3, 9.1.2, 10.4.1 y 11.3.1.
- **`PrivateChatTranslator` (229), aplicado por D-07:**
  - **R-42 ×2:** `entries` y `messages` con `ContractArray.ConvertAll`; sale `System.Linq` y entra `Host.Common`.
  - **R-14 ×2:** `lastMessage` y `sentAt` en variables antes del `return new`.
  - **R-48:** `ToNotification` → `ToPrivateMessageNotification`, con su llamada en `NotificationChannelRegistry`.
  - **3.4.1:** `var sentAt = DateTime.SpecifyKind(…)`. Es el tercer caso de la regla (un método estático que devuelve el
    tipo que lo declara), como `var clockTime = TimeSpan.FromMinutes(…)`.
  - **Cumple:** R-47 (`ToConversationEntry` y `ToChatMessage` en el orden de uso) y la pasada 4.
- **Pasada 2:** `RequireText` y `RequireSessionToken` son iguales a los de `ChatService`. Se preguntan con la repetición
  entre servicios, al terminar `Host`.
- **Notas para después:**
  - **`Contracts` (R-27):** `IConversationService` no tiene ningún `<summary>` (7.1.1).
  - **`SpecifyKind`:** es el único de la solución. Marca como UTC las fechas que vienen de la base. Las demás fechas leídas
    de la base (por ejemplo `LastSeenAt` de amigos) salen sin `Kind`. No se cambia aquí.
- **Comprobado:**
  - `Host` compila sin avisos de código en una compilación completa (solo NU1902/NU1903);
  - una sonda comparó `HEAD` con el código nuevo: 4 resultados del traductor (con una fecha de la base sin `Kind` y otra
    en UTC) y 33 casos del servicio (con éxito, sesión inválida, rechazo, sin guardar, base de datos, error de
    programación, token nulo, código nulo, texto nulo), todos iguales, también la bitácora y cuántas veces llega a
    `Application`.

**Preguntas (228 y 229):**
1. `code` → `partnerCode` en `OpenConversation` y `MarkConversationRead`, y `recipientCode` en `SendPrivateMessage`
   (recomendado: sí, como `requesterCode` y `recipientCode` en `FriendshipService`).
2. `ToChatMessage` → `ToPrivateChatMessage`, porque devuelve `PrivateChatMessage` (recomendado: sí; por la R-51,
   `lastMessage` pasaría a `var`).
3. Texto de `DbUpdateException`: "The private message could not be saved." sale también en `OpenConversation` y en
   `MarkConversationRead`, que guardan las marcas de leído (recomendado: "The conversation could not be saved.").

**Decisiones del usuario (228 y 229): A en las tres.**
- **Nombres:** `partnerCode` en `OpenConversation` y `MarkConversationRead` (y en sus `…InRequestScope`), `recipientCode`
  en `SendPrivateMessage`.
- **`ToChatMessage` → `ToPrivateChatMessage`.** Lo que dije de `lastMessage` resultó falso: con `var`, IDE0008 pide el tipo
  explícito, porque la llamada no está calificada. Se queda `PrivateChatMessage lastMessage`, y la R-51 se corrigió para
  decirlo.
- **Texto:** "The conversation could not be saved. Operation=…".
- **Verificación:**
  - `Host` compila sin avisos de código en una compilación completa;
  - la sonda volvió a dar los 37 resultados iguales a `HEAD`;
  - en la bitácora solo cambia el texto de `DbUpdateException`.

**Commit de `PrivateChat`:** `c5c0a5e` (2026-11-11), sin push.

### 230. `Program` (2026-11-11)

- **Cumple:**
  - 2.3.1 y 2.3.2 (cuatro `const` en PascalCase);
  - 2.6.1 (`_logger`);
  - 3.4.1 (`var` con `new` y con `ServerCertificate.Load`, que devuelve su propio tipo);
  - 4.2.1 (guardas en `GetConnectionString` y `GetNetTcpPort`);
  - 5.2.1 (`certificate.ConfigureServices` como grupo de método);
  - 6.2, 6.3 y 9.3.2 (`InvalidOperationException` para la configuración que falta);
  - 10.2.1 (es la raíz de composición);
  - 11.3.1;
  - R-23 (la llamada anidada de `XmlConfigurator.Configure` se deja).
- **Pasada 4:** cada miembro se usa.
- **11.1.1 (pregunta 1):** una falla del arranque termina el proceso y debe ir en Fatal. Hoy no queda en la bitácora:
  - si falta la cadena de conexión, el puerto o el certificado, la excepción sale de `Main`;
  - lo mismo si no se puede abrir el puerto.
- **11.3.1 (pregunta 2):** "Game server started" se registra antes de `app.Run()`, que es lo que abre el puerto. Si el
  puerto está ocupado, la bitácora dice que arrancó y luego falla.
- **9.4.1 (pregunta 3):** `Main(string[] args)` es `public` y `args` es de referencia no anulable. La regla pide
  `ArgumentNullException.ThrowIfNull` en todo miembro `public`.
- **2.10.1 (pregunta 4):** `netTcpPort <= 0` usa un literal con significado (el valor que da `GetValue<int>` cuando falta
  la clave), y no hay tope: un puerto mayor que 65535 llega hasta `UseNetTcp`.
- **Prueba (`startup-crash-experiment` en el scratchpad):** con el `log4net.config` del servidor, un `Main` que lanza
  `InvalidOperationException` después de configurar log4net.
  - **Sin manejador:** `server.log` solo tiene la línea Info anterior.
  - **Con `AppDomain.CurrentDomain.UnhandledException`:** queda `FATAL … The game server stopped because of an unhandled
    exception.` con la excepción completa.
  - **En los dos casos:** el proceso termina igual, con el código de excepción no controlada.
  - **No se probó con el servidor real:** al arrancar, `RoomBackgroundService` cierra en la base las salas abiertas, y el
    servidor del usuario está corriendo.
- **Propuesta en la copia aparte** (compila sin avisos de código):
  - `Main` empieza con `ArgumentNullException.ThrowIfNull(args)`;
  - registra `AppDomain.CurrentDomain.UnhandledException += LogUnhandledException;` después de `ConfigureLogging()`;
  - cambia `app.Run()` por `app.Start(); _logger.Info(…); app.WaitForShutdown();`;
  - `GetNetTcpPort` compara con `IPEndPoint.MinPort` y `IPEndPoint.MaxPort`.

**Preguntas (230):**
1. Fatal en el arranque (recomendado: A, `AppDomain.CurrentDomain.UnhandledException` con un `LogUnhandledException`
   privado que registra en Fatal sin atrapar nada; B, `try` en `Main` con `catch` de tipos conocidos, Fatal y `throw;`).
2. Registrar "Game server started" después de `app.Start()` y esperar con `app.WaitForShutdown()` (recomendado: sí).
3. `ArgumentNullException.ThrowIfNull(args)` en `Main` (recomendado: sí; la otra salida, hacer `Main` privado, solo
   esquiva la regla).
4. `IPEndPoint.MinPort` y `IPEndPoint.MaxPort` en `GetNetTcpPort`, con el texto "The net.tcp port is missing or out of
   range. Key=…; Port=…" (recomendado: sí).

**Decisiones del usuario (230): A en las cuatro (R-52).** La propuesta pasó al repositorio tal cual.
- **Verificación:**
  - `Host` compila sin avisos de código en una compilación completa.
  - **Prueba con el servidor real (la compilación de la carpeta aparte):**
    - se lanzó con `--Server:NetTcpPort=70000`; antes se comprobó, contando la clave sin leer valores, que los secretos
      no definen el puerto;
    - `server.log` tiene `FATAL … The game server stopped because of an unhandled exception.` con
      `InvalidOperationException: The net.tcp port is missing or out of range. Key=Server:NetTcpPort; Port=70000`;
    - el proceso terminó antes de cargar el certificado y de tocar la base.

**Commit de `Program`:** `edd69af` (2026-11-11), sin push.

### 231 a 233. `RoomBackgroundService`, `RoomService` y `RoomTranslator` (2026-11-11)

- **`RoomTranslator` (233), aplicado por D-07 en el repositorio:**
  - R-43: `FaultExceptionFactory.Create`.
  - R-42: `members` con `ContractArray.ConvertAll`; sale `System.Linq`.
  - R-14 ×5: `gameModeCode`, `options`, `seatCount`, `state`, `gameMode`.
  - R-23: `double retryAfterSeconds = Math.Ceiling(…)` y después `(int)retryAfterSeconds`.
  - R-47: los privados en el orden de los públicos.
- **`RoomTranslator`, 4.3.2 (pregunta 5):** el `default` de `ToReason` devuelve `ToPlacementReason(rejection)`. La
  regla prohíbe usar el `default` para valores válidos, y ocho valores válidos pasan por ahí. Se partió en dos `switch`
  para no pasar de complejidad 10 (14 casos). `RoomContractTranslator` del cliente tiene el mismo caso.
- **`RoomService` (232):**
  - **Cumple:** 7.1.2, 2.2.2, 6.3, 9.1.2, 10.4.1 y 9.4.2 (`code ?? string.Empty`: el código vacío lo rechaza
    `Application` con `RoomNotFound`).
  - **Forma decidida (propuesta en la copia aparte):**
    - **R-44 y R-45:** salen `RunRequest`, `RunGuarded<TService, TResult>` y los dos `RunInRequestScope`. Quedan siete
      `…InRequestScope`, `TranslateRoomFailures` con sus dos sobrecargas y `CompleteOperation`.
    - **R-50:** `LeaveRoom` usa `LogOneWayFailures`.
    - **R-28:** `RequireSession` pasa a `RequireSessionToken` con `??`, como en los demás servicios.
    - **4.2.1:** en `FindOwnRoomInRequestScope`, una guarda `if (room is null) return null;` en lugar de
      `room is null ? null : …` en el `return`.
  - **Pregunta 1 (pasada 3):** cómo se llaman las variables de `IPrivateRoomService` y `IRoomMatchService`; hoy son los
    parámetros `roomService` y `matchService` de las lambdas.
  - **Pregunta 2:** hoy `FindOwnRoom` solo atrapa `InvalidSessionException`, así que una `DbException` (la sesión se
    verifica en la base) se escapa sin registro. Con la R-44 pasa por `TranslateRoomFailures`.
  - **Pregunta 3 (R-50):**
    - los textos de `LeaveRoom` no dicen la operación;
    - `LeaveRoom` no atrapa `DbException`, así que esa falla se pierde (lo mostró `oneway-experiment`).
  - **Pregunta 4 (11.1.1):** `LogRejection` registra en Info cada rechazo y en Warn el de `InvalidSettings`, dentro del
    `catch` que traduce y relanza. La 11.1.1 dice que ese `catch` no registra: se registra donde se maneja al final. Los
    demás servicios no registran sus rechazos.
- **`RoomBackgroundService` (231):**
  - **Cumple:** 2.6.1, 5.1.2 (se suscribe con grupo de método y se desuscribe en `StopAsync`), 9.3.1, 10.4.1 y 11.3.1
    (`AccountId` en el contexto).
  - **Pregunta 6 (pasada 3):** se llama `…BackgroundService`, pero implementa `IHostedService`, no hereda de
    `BackgroundService`. Hace dos cosas: al arrancar cierra las salas que dejó abiertas la ejecución anterior, y saca de su
    sala al jugador que se desconecta.
  - **10.1.1:** recibe la clase concreta `NotificationChannelRegistry`, por su evento `PlayerDisconnected`. Se pregunta
    con la R-49 al revisar `Sessions`.
- **Notas para `Contracts`:**
  - el `<summary>` de `FindOwnRoom` no documenta la `FaultException`;
  - el contrato dice `RoomOptions`/`ChangeOptions` y `Application` dice `RoomSettings`/`ChangeSettings`.
- **Comprobado:**
  - `Host` del repositorio (con el traductor) y de la propuesta compilan sin avisos de código;
  - la sonda comparó `HEAD` con la propuesta:
    - 96 resultados iguales:
      - el traductor con los 14 rechazos, un valor fuera del enum, los tres modos y las tres conversiones de sala;
      - siete operaciones con éxito, token nulo, sesión inválida, dos rechazos, dos repositorios, base de datos y
        error de programación;
      - las opciones nulas, el código nulo y la sala que no existe;
    - 6 diferencias, todas las de las preguntas 2 y 3: cinco de `FindOwnRoom` ahora salen como falla, y la
      `DbException` de `LeaveRoom` ahora queda en Error;
    - bitácora: salen las 5 líneas Info y la Warn de rechazos (pregunta 4); los textos de `LeaveRoom` llevan
      `Operation=` (pregunta 3).

**Preguntas (231 a 233):**
1. Variables de los servicios de `Application` (recomendado: A, `privateRoomService` y `roomMatchService`; B,
   `privateRooms` y `roomMatches`, como `friendRequests`, pero se leen como listas).
2. `FindOwnRoom` pasa por `TranslateRoomFailures` (recomendado: sí).
3. `LeaveRoom` con `Operation=` en sus textos y un `catch (DbException)` más (recomendado: sí, como `MatchmakingService`).
4. `LogRejection` (recomendado: A, quitarlo, como en los demás servicios; la Warn de opciones nulas de `RequireSettings`
   se queda porque es una guarda y no un `catch`. B: dejar solo la Warn de `InvalidSettings` con un filtro `when`. C:
   dejarlo).
5. 4.3.2 en `ToReason` (recomendado: A, una tabla `_reasonsByRejection` de `IReadOnlyDictionary` con `TryGetValue`, y
   `ArgumentOutOfRangeException` si falta el valor; B, dejar los dos `switch`).
6. `RoomBackgroundService` → `RoomCleanupService`, con su registro en `ServiceRegistration` (recomendado: sí).

**Decisiones del usuario (231 a 233): A en las seis.**
- **1:** `privateRoomService` y `roomMatchService`.
- **2:** `FindOwnRoom` pasa por `TranslateRoomFailures`.
- **3:** `LeaveRoom` con los textos de un sentido y `Operation=`, más el `catch (DbException)`.
- **4 (R-53):** sale `LogRejection`.
- **5 (R-54):** `ToReason` con la tabla `_reasonsByRejection`.
- **6:** `RoomCleanupService`, con `git mv` y su registro. El nombre del registrador de log4net cambia con la clase.
- **Verificación:**
  - `Host` compila sin avisos de código en una compilación completa;
  - la sonda volvió a dar 96 resultados iguales a `HEAD` y las 6 diferencias aprobadas (cinco de `FindOwnRoom` y la
    `DbException` de `LeaveRoom`).

**Commit de `Rooms`:** `e8d9d4c` (2026-11-11), sin push.

**Push y PR (2026-11-11, a pedido del usuario):**
- La rama `review-standard-v2.4-repositories` se subió en `e8d9d4c`, con 16 commits sobre `main` (`2eb1167`).
- Se abrió el PR #16 (https://github.com/Arclyne/bastion/pull/16), sin rastro de IA, en el formato del PR #15. Está
  abierto y se puede fusionar sin conflictos; el repositorio no tiene CI.
- **Comprobado antes de subir:**
  - autor y committer son solo la identidad del usuario, y ningún mensaje tiene trailers ni menciones;
  - la auditoría de la frontera da lo de siempre (hooks sin instalar y los 3 avisos SQL de `HEAD`);
  - pasan 514 pruebas.
- **Falta de `Host`:** `ServerCertificate`, `ServiceRegistration` y `Sessions`.

**Rama nueva (2026-11-11, a pedido del usuario):** la revisión sigue en `review-standard-v2.4-host`, creada desde
`e8d9d4c` (la punta del PR #16). Solo commits locales hasta que el usuario pida subirla.

### 234 y 235. `ServerCertificate` y `ServiceRegistration` (2026-11-11)

Se revisan juntos porque los dos listan los mismos ocho servicios WCF.
- **`ServerCertificate` (234):**
  - **R-14, aplicado:** `X509Certificate2 certificate = X509CertificateLoader.LoadPkcs12FromFile(…)` antes del
    `return new ServerCertificate(certificate)`. El tipo va explícito por la R-51: el método no está en la clase que
    devuelve.
  - **Cumple:**
    - 2.3.1, 2.6.1, 4.2.1, 5.2.1 (`ApplyCertificateTo` como grupo de método) y 6.2;
    - 9.4.1 (`Load` y `ConfigureServices` comprueban; el constructor es privado);
    - 9.5.1 (es dueña del certificado y lo libera; `Program` usa `using var`).
  - **Pregunta 1 (11.3.1, 9.4.2):** la guarda junta la ruta y la contraseña, pero el mensaje solo nombra
    `Server:CertificatePath`. Si falta la contraseña, el mensaje señala la clave equivocada.
  - **Pregunta 2 (pasada 2 y 3, 4.4.2):**
    - `ConfigureServices` agrega los ocho servicios WCF, y `ServiceRegistration.AddBastionServiceModel` los vuelve a
      listar para el contenedor;
    - para agregar un servicio hay que tocar dos archivos;
    - quien busque dónde se registran los servicios no lo encuentra en una clase llamada `ServerCertificate`.
- **`ServiceRegistration` (235):**
  - **Cumple:**
    - 6.3 y 9.4.1;
    - 10.2.1 (es raíz de composición, así que puede pedir `GetRequiredService`);
    - pasada 4 (cada registro tiene un uso).
  - **Pregunta 3 (pasada 3):** `AddBastionApplication` también registra tipos de `Host`:
    - `FriendPresenceReporter`;
    - `NotificationChannelRegistry` y sus ocho puertos;
    - los dos servicios en segundo plano.

    `AddBastionServiceModel`, en cambio, registra `TimeProvider` y los ocho servicios WCF.
  - **Pregunta 4 (4.4.1, 5.2.1, 3.5.1):** `provider => provider.GetRequiredService<NotificationChannelRegistry>()` se
    repite ocho veces, la mitad en una línea y la otra mitad en dos.
- **Pendiente para `Sessions` (R-49):** `NotificationChannelRegistry` se registra como clase concreta.
- **Propuesta en la copia aparte** (compila sin avisos de código):
  - **`ServerCertificate`:**
    - dos guardas, una con cada clave (la contraseña con `?? throw`);
    - `ApplyTo(IServiceBuilder)` en lugar de `ConfigureServices`, y sin los `using` de los servicios.
  - **`ServiceRegistration`:**
    - `AddBastionApplication` solo con tipos de `Application`;
    - `AddBastionServiceModel` pasa a `AddBastionHost`, con los tipos de `Host`;
    - un `AddBastionServices(this IServiceBuilder)` nuevo, con los ocho `AddService`, junto a los ocho `AddTransient`;
    - un privado `GetChannelRegistry` que se usa como grupo de método en los ocho puertos.
  - **`Program`:** llama `AddBastionHost` y
    `app.UseServiceModel(serviceBuilder => ConfigureServiceModel(serviceBuilder, certificate))`, con un
    `ConfigureServiceModel` privado que llama `AddBastionServices()` y `certificate.ApplyTo(serviceBuilder)`.
- **Sonda (`registration-probe`):**
  - **Contenedor:** los 49 registros son iguales como conjunto; los servicios en segundo plano siguen en el mismo
    orden; los ocho puertos resuelven la misma instancia del registro, antes y después.
  - **CoreWCF:** con el `ServiceBuilder` real de CoreWCF quedan los mismos ocho servicios, en el mismo orden, y
    `ConfigureAllServiceHostBase` se aplica sin error.
  - **`Load` con un certificado de prueba:**
    - carga bien;
    - ruta faltante, ruta en blanco, contraseña vacía o equivocada dan el mismo tipo de excepción;
    - cuando falta la contraseña, el mensaje ahora nombra `Server:CertificatePassword`.

**Preguntas (234 y 235):**
1. Separar la guarda de `Load` para que el mensaje nombre la clave que falta (recomendado: sí).
2. Pasar la lista de servicios WCF a `ServiceRegistration.AddBastionServices`, dejar en `ServerCertificate` solo
   `Load`, `ApplyTo` y `Dispose`, y componer en `Program` (recomendado: A; B, dejarla en `ServerCertificate`; C, un solo
   arreglo de tipos para las dos listas, que se lee peor).
3. Dejar `AddBastionApplication` con los tipos de `Application` y pasar los de `Host` a `AddBastionHost` (recomendado:
   sí).
4. `GetChannelRegistry` como grupo de método en los ocho puertos (recomendado: sí).

**Respuesta del usuario (2026-11-11):** «Sí, A en todas». Queda como regla R-55.

**Aplicado en el repositorio** (la propuesta de la copia aparte, sin cambios):
- **`ServerCertificate`:**
  - dos guardas, una con cada clave; la contraseña con `?? throw`;
  - `ApplyTo(IServiceBuilder)` en lugar de `ConfigureServices`, sin los `using` de los servicios.
- **`ServiceRegistration`:**
  - `AddBastionApplication` solo con tipos de `Application`;
  - `AddBastionHost` (antes `AddBastionServiceModel`) con `TimeProvider`, `FriendPresenceReporter`, el registro de
    canales y sus ocho puertos, los dos servicios en segundo plano y los ocho `AddTransient`;
  - `AddBastionServices(this IServiceBuilder)` con los ocho `AddService`;
  - `GetChannelRegistry` como grupo de método.
- **`Program`:** `AddBastionHost()` y el privado `ConfigureServiceModel`.
- **Verificación:**
  - `Host` compila sin avisos de código en una compilación completa (solo los avisos NU1902/NU1903 de
    `System.Security.Cryptography.Pkcs`, que ya estaban);
  - la sonda volvió a dar los mismos resultados sobre los archivos del repositorio;
  - pasan 514 pruebas (158 de dominio, 220 de aplicación y 136 del cliente).

**Commit de `ServerCertificate` y `ServiceRegistration`:** `08f2766` (2026-11-11), en `review-standard-v2.4-host`,
sin push.

### 236 a 239. `Sessions`: `NotificationChannelRegistry`, `PlayerDisconnectedEventArgs`, `SessionService` y `SessionTranslator` (2026-11-11)

Es la última carpeta de `Host`. También se resuelve aquí la repetición entre servicios que quedó pendiente en `Chat` y
`PrivateChat`.
- **`NotificationChannelRegistry` (236):**
  - **Cumple:**
    - 1.3.1, 2.1–2.2 (ningún método pasa de tres parámetros), 2.6, 2.12.1 y 2.12.2 (`PlayerDisconnected` con
      `EventHandler<T>`);
    - §3, §4 (el cast es directo, sin `as`), 5.1.1, 5.2.1 y §6;
    - 5.1.2: las lambdas de `Closed` y `Faulted` no se cancelan nunca, porque el canal muere con ellas;
    - 9.1, 9.3.1 (`Exception cause` es un parámetro, no un `catch`), 9.4.1, 10.4.1, 11.1.1 y 11.3.1.
    - §7, §8 y §12 no aplican: no es un servicio (R-39) y no es una prueba.
  - **R-23, aplicado:** `((ICommunicationObject)callback).Abort()` juntaba el cast con la llamada. Ahora va en
    `var callbackChannel = (ICommunicationObject)callback;` y luego `callbackChannel.Abort();`, como en `RegisterChannel`.
  - **Pasada 4:** cada miembro público tiene uso. `CountListeners` lo usa `LobbyChatRoom`, `HasNotificationChannel` lo
    usa `PlayerActivity`, `IsPlayerConnected` lo usa `FriendListService` y `PlayerDisconnected` lo usa
    `RoomCleanupService`.
- **`PlayerDisconnectedEventArgs` (237):** cumple 2.14.1, 2.11.1, R-03, 6.x y 9.4.1 (no tiene parámetros de referencia).
  Sin cambios.
- **`SessionService` (238):**
  - **R-44 y R-45, aplicados:** `Subscribe` deja su llamada en `Action subscribe = () => SubscribeInRequestScope(token);`
    y llama `TranslateSessionFailures(nameof(Subscribe), subscribe)`. Es un servicio solo con operaciones `void`, así
    que tiene un único `Translate…Failures(…, Action)`.
  - **Bitácora:** "The database could not be reached while subscribing." pasa a la forma de los demás servicios:
    "The database could not be reached. Operation=Subscribe".
  - **D-06:** en `SubscribeInRequestScope`, la hora y el canal de devolución van cada uno en su variable antes de usarlos.
  - **Cumple:** 7.1.2, 10.3.1 (la excepción de la frontera de red) y R-40. `KeepAlive` es de un solo sentido y está
    vacío: no hay nada que pueda fallar, así que no lleva la R-50.
- **`SessionTranslator` (239):** **R-43, aplicado.** `var fault = new InvalidSessionFault();` y luego
  `FaultExceptionFactory.Create(fault, rejection)`.
- **Pregunta 1 (10.1.1, R-49):** la 10.1.1 define como servicio externo todo colaborador con E/S (red, disco, base) o
  con estado compartido.
  - `NotificationChannelRegistry` hace las dos cosas: llama a los clientes y guarda los canales.
  - `FriendPresenceReporter` escribe en la base.
  - Aun así se reciben como clases concretas: `SessionService` y `RoomCleanupService` reciben el registro, y el registro
    recibe el informador. Las únicas excepciones de la regla son las de `Adapters` y el `ILog`.
- **Pregunta 2 (pasada 2, D-06):** en el registro, 5 de los 11 `Notify…` pasan el traductor como argumento
  (`NotifyPlayer(request.AccountId, MatchmakingTranslator.To…(…))`), y los otros 6 arman antes la variable
  `notification`.
- **Pregunta 3 (4.4.1):** `RegisterChannel` escribe dos veces la misma lambda
  `(_, _) => UnregisterChannel(player.AccountId, callback)`, una para `Closed` y otra para `Faulted`.
- **Pregunta 4 (pasada 3):**
  - `Broadcast(PostedChatLine line)` se lee `line.Line.Sender`. En `ChatTranslator`, en `NotifyMatchChatMessage` y en
    `LobbyChatRoom` el mismo valor se llama `postedLine`.
  - `foreach (KeyValuePair<int, INotificationCallback> subscription …)` usa `subscription.Key` y `subscription.Value`.
  - En `SessionService`, la variable se llama `verifier`; en los demás servicios, la variable lleva el nombre del rol.
  - La bitácora dice "Player left notifications.", que no es claro y no hace pareja con "Player subscribed to
    notifications.".
- **Pregunta 5 (pasada 2 entre servicios, pendiente desde 218–219 y 228–229):**
  - `RequireSessionToken`: 6 métodos privados iguales (`Chat`, `Friendship`, `Conversation`, `Room`, `Match`,
    `Matchmaking`), más el `if` en línea de `SessionService`.
  - `RequireText`: 2 iguales, en `ChatService` y `ConversationService`.
  - `GetUtcNow`: 7 privados iguales y 5 expresiones en línea (`_timeProvider.GetUtcNow().UtcDateTime`).
  - El ámbito (`CreateScope` + `GetRequiredService`) ya lo decidió la R-44, así que no se pregunta.
  - `SessionTranslator.RequireSessionToken` era una de las piezas de apoyo de la clase compartida que el usuario no
    eligió en 218–219. Aquí se propone sola, sin esa clase y sin `RequestScope`.
- **Pregunta 6 (R-47):** los privados del registro están en este orden: `GetUtcNow`, `NotifyPlayers`, `NotifyPlayer`,
  `DeliverNotification`, `AbortFailedChannel`, `UnregisterChannel` y `OnPlayerDisconnected`.
  - Salvo `GetUtcNow`, forman una cadena en la que cada uno va debajo del que lo llama.
  - Con la R-47 al pie de la letra, `UnregisterChannel` iría primero, porque lo usa `RegisterChannel`, el primer
    público. Eso rompe la cadena.
- **Propuesta en la copia aparte** (`Host` compila sin avisos de código en una compilación completa; solo
  NU1902/NU1903):
  - **Pregunta 1:**
    - `Sessions/INotificationChannelRegistry` (evento `PlayerDisconnected` y `RegisterChannel`) y
      `Friends/IFriendPresenceReporter` (`ReportConnected` y `ReportDisconnected`);
    - las tres clases reciben las interfaces;
    - `ServiceRegistration` registra `AddSingleton<IFriendPresenceReporter, FriendPresenceReporter>()` y
      `AddSingleton<INotificationChannelRegistry>(GetChannelRegistry)`;
    - el constructor de `SessionService` pasa a una línea por parámetro, como `RoomCleanupService`.
  - **Pregunta 2:** los 11 `Notify…` arman `notification` en su variable. `NotifyPrivateMessage` también guarda
    `int recipientAccountId = delivery.Message.RecipientId.GetValueOrDefault();`.
  - **Pregunta 3:** `EventHandler unregisterChannel = (_, _) => UnregisterChannel(player.AccountId, callback);` se usa en
    `Closed` y en `Faulted`.
  - **Pregunta 4:**
    - `postedLine` en `Broadcast` y en `IChatBroadcaster` (y en `FakeChatBroadcaster` de las pruebas, al aplicarlo);
    - `foreach ((int accountId, INotificationCallback callback) in _callbacksByAccountId)`, la primera deconstrucción de
      la solución;
    - `sessionVerifier`;
    - "Player unsubscribed from notifications. AccountId=…".
  - **Pregunta 5:**
    - `SessionTranslator.RequireSessionToken` y `ChatTranslator.RequireText` son públicos y estáticos; los 8 privados
      salen;
    - cada operación llama `string token = SessionTranslator.RequireSessionToken(sessionToken);`;
    - `GetUtcNow` se queda.
  - **Pregunta 6:** la cadena va junta, de arriba abajo (`NotifyPlayers` … `OnPlayerDisconnected`), y `GetUtcNow` pasa
    al final, como en `MatchmakingService`.
- **Sonda (`sessions-probe`):** compara `HEAD` (las clases `Old…`) con la propuesta: 36 casos iguales y 2 diferencias,
  que son los textos de bitácora de las preguntas 4 y de la R-44.
  - **Registro, en un mismo escenario:**
    - tres canales, la difusión sin el remitente y los 11 `Notify…` con el contenido de cada notificación;
    - `CommunicationException` y `TimeoutException` al entregar, con su `Abort`, la baja, el aviso de presencia, la cola
      y el evento;
    - `Closed` y `Faulted`, y un segundo canal del mismo jugador que el cierre del primero no borra.
    - Todo es igual. Solo cambia el texto Info de la baja (4 líneas).
  - **`Subscribe`:** el token nulo, la sesión inválida, el error de programación y la llamada fuera de WCF dan lo mismo.
    La base caída da la misma falla; solo cambia el texto Error, que ahora lleva `Operation=Subscribe`.
  - **Token nulo en las 28 operaciones de los 7 servicios, y texto nulo en las 4 que tienen un parámetro `text`:** todo
    es igual. Sale la falla de sesión, la falla de chat `InvalidMessage` en las 3 que exigen texto, o nada en las
    operaciones de un solo sentido. `SearchPlayers` no exige el texto y llega al ámbito en las dos versiones.
  - **Registro del contenedor:**
    - los 9 tipos (`INotificationChannelRegistry` y los 8 puertos) resuelven el mismo registro;
    - `IFriendPresenceReporter` es un singleton;
    - con `AddBastionAdapters` también se arman `SessionService` y los dos servicios en segundo plano.

**Preguntas (236 a 239):**
1. 10.1.1: `INotificationChannelRegistry` e `IFriendPresenceReporter` (recomendado: A, las dos interfaces; B, separar el
   registro en dos interfaces por rol; C, dejar las clases concretas).
2. Los 11 `Notify…` con su variable `notification` (recomendado: sí).
3. Una sola variable `unregisterChannel` para `Closed` y `Faulted` (recomendado: sí).
4. Los cuatro nombres y el texto de la bitácora (recomendado: sí en los cuatro).
5. `SessionTranslator.RequireSessionToken` y `ChatTranslator.RequireText` compartidos; `GetUtcNow` se queda
   (recomendado: A; B, dejar todo; C, también `GetUtcNow` con un método de extensión en `Host/Common`).
6. R-47 con cadenas: los privados que se llaman en cadena van juntos y de arriba abajo; `GetUtcNow` al final
   (recomendado: A; B, la R-47 al pie de la letra; C, dejar el orden de hoy).

**Respuesta del usuario (2026-11-11):** «Sí, A en todas». La R-49 se amplía a `Host`, la R-47 se precisa con las cadenas
y la pregunta 5 queda como R-56.

**Aplicado en el repositorio** (la propuesta de la copia aparte, sin cambios):
- `Sessions/*`, `Friends/FriendPresenceReporter` y las dos interfaces nuevas;
- `RoomCleanupService` y `ServiceRegistration`;
- los seis servicios sin sus `RequireSessionToken` y `RequireText` privados, y `ChatTranslator.RequireText`;
- `IChatBroadcaster.Broadcast(PostedChatLine postedLine)`, y el mismo nombre en `FakeChatBroadcaster` de las pruebas.
- **Verificación:**
  - `Host` compila sin avisos de código en una compilación completa (solo NU1902/NU1903);
  - la sonda dio 36 casos iguales y las 2 diferencias de texto esperadas;
  - pasan 514 pruebas (158 + 220 + 136).

**Commit de `Sessions`:** `ebb0e3b` (2026-11-11), en `review-standard-v2.4-host`, sin push.

**Cierre de la capa `Host` (2026-11-11):** los archivos 215 a 239 están revisados. En `review-standard-v2.4-host` hay
dos commits locales (`08f2766` y `ebb0e3b`). Sigue `Contracts`, con las notas que se dejaron para esa capa (R-27 en
`IConversationService` y en los demás contratos sin `<summary>`, la `FaultException` de `FindOwnRoom` y de
`StartSearch`, el `<summary>` de `AbandonMatch` y `RoomOptions` frente a `RoomSettings`).
