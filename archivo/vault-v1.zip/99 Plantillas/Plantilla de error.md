---
tags: [error]
fecha: {{date}}
---
# ERR-NNN Título
Volver a [[Índice de errores]]

**Qué pasó:**
**Por qué pasó:**
**Cómo se corrigió:**
**Regla para no repetirlo:**
**Relacionado:**
