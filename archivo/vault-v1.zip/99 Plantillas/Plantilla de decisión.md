---
tags: [decision]
estado: vigente
fecha: {{date}}
---
# DEC-NNN Título
Volver a [[Índice de decisiones]]

**Decisión:**
**Motivo:**
**Alternativas descartadas:**
**Implica:**
**Reemplaza a / reemplazada por:**
