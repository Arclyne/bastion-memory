---
tags: [bitacora]
fecha: {{date}}
---
# AAAA-MM-DD Título
Volver a [[Índice de bitácora]]

**Qué se hizo:**
**Decisiones:**
**Errores:**
**Siguiente paso:**
