---
tags: [indice]
---
# Índice de plantillas
Volver a [[00 Inicio]]

- [[Plantilla de decisión]]
- [[Plantilla de error]]
- [[Plantilla de bitácora]]
