---
tags: [indice, decision]
---
# Índice de decisiones
Volver a [[00 Inicio]] · Nueva: [[Plantilla de decisión]]

| ID | Decisión | Estado |
|---|---|---|
| [[DEC-001 Estilo visual 3D low-poly]] | Estilo 3D low-poly minimalista; peones básicos | vigente |
| [[DEC-006 Skins fuera del alcance]] | Las skins no se implementan: pasaron a deseable y ya no son requisito obligatorio | vigente |
| [[DEC-002 Cliente con MonoGame]] | El cliente se hace con MonoGame | vigente |
| [[DEC-003 Modelos 3D en Blender]] | Modelos en Blender; Higgsfield solo para imágenes de prototipos | vigente |
| [[DEC-004 Partidas de 2 o 4 jugadores]] | Una partida admite 2 o 4 jugadores, nunca 3 | vigente |
| [[DEC-005 Sin actor moderador]] | El sistema no tiene actor moderador | vigente |
| [[DEC-007 El estándar es para un juego 3D]] | El estándar v2.4 dice juego de mesa 3D, no 2D | vigente |
| [[DEC-008 Jugabilidad primero en 1 vs 1]] | La jugabilidad se hace primero para 2 jugadores, paso por paso | vigente |
| [[DEC-009 MovePawn sin resultado y rechazos como faltas]] | `MovePawn` devuelve `void`; los rechazos son faltas y la posición llega por notificación | vigente |
| [[DEC-010 Un solo canal de notificaciones para la partida]] | La partida usa el canal único `INotificationCallback` | vigente |
| [[DEC-011 El borde del tablero permite el salto diagonal]] | El borde detrás del rival permite el salto diagonal | vigente |

Restricciones que no son decisiones del equipo: [[Restricciones del profesor]].
