---
tags: [decision]
estado: vigente
---
# DEC-002 Cliente con MonoGame
Volver a [[Índice de decisiones]]

**Decisión:** el cliente del juego usa MonoGame (C#).
**Relacionado:** [[Código]], [[Restricciones del profesor]].
