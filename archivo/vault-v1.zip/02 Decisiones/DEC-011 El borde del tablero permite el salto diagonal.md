---
tags: [decision]
estado: vigente
fecha: 2026-11-12
---
# DEC-011 El borde del tablero permite el salto diagonal
Volver a [[Índice de decisiones]]

**Decisión:** cuando el peón rival está delante y detrás de él está el borde del tablero, el salto diagonal está permitido, igual que si detrás hubiera un muro (RN-03 de CU-13).
**Motivo:** aprobado con el plan del paso 1 (2026-11-12).
**Alternativas descartadas:** permitir la diagonal solo cuando detrás hay un muro.
**Implica:** `PawnMovePolicy` trata el borde como bloqueo. El servidor y el cliente usan la misma política del dominio.
**Reemplaza a / reemplazada por:** —
