---
tags: [decision]
estado: vigente
fecha: 2026-11-12
---
# DEC-008 Jugabilidad primero en 1 vs 1
Volver a [[Índice de decisiones]]

**Decisión:** la jugabilidad se construye primero para las partidas de 2 jugadores (Clásico 9×9 y Rápida 7×7). Se hace paso por paso: mover el peón (CU-13), muros (CU-14), reloj y tiempo agotado, fin de partida (CU-19), rendición (CU-17) y tablas (CU-15/16), y al final la reconexión (CU-20).
**Motivo:** el usuario lo pidió así (2026-11-12). Es el modo que ya llega a la pantalla de partida por la búsqueda clasificatoria.
**Alternativas descartadas:** hacer 2 y 4 jugadores a la vez.
**Implica:** con 4 jugadores, llegar a la meta solo pasa el turno, sin cerrar la partida, hasta que se haga su paso. [[DEC-004 Partidas de 2 o 4 jugadores]] sigue vigente.
**Reemplaza a / reemplazada por:** —
