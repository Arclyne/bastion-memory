---
tags: [decision]
estado: vigente
---
# DEC-004 Partidas de 2 o 4 jugadores
Volver a [[Índice de decisiones]]

**Decisión:** una Partida admite 2 o 4 jugadores, nunca 3.
**Relacionado:** [[Modelo de datos]].
