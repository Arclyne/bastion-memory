---
tags: [decision]
estado: vigente
---
# DEC-001 Estilo visual 3D low-poly
Volver a [[Índice de decisiones]]

**Decisión:** estilo visual 3D low-poly, minimalista abstracto. Los peones predeterminados son básicos, tipo muñequitos.
**Motivo original:** iba a haber skins y el peón base debía ser neutro. Ese motivo ya no aplica: las skins salieron del alcance ([[DEC-006 Skins fuera del alcance]]).
**Implica:** ver [[DEC-003 Modelos 3D en Blender]].
