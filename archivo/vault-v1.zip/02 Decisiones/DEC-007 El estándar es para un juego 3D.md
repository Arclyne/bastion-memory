---
tags: [decision]
estado: vigente
fecha: 2026-11-11
---
# DEC-007 El estándar es para un juego 3D
Volver a [[Índice de decisiones]]

**Decisión:** el estándar v2.4 dice "Juego de Mesa 3D". Se cambiaron la portada, la 1.1 ("en 3D") y la 1.2 ("en tres dimensiones").
**Motivo:** el juego es 3D ([[DEC-001 Estilo visual 3D low-poly]]).
**Implica:** el PDF original del estándar todavía dice 2D; solo se corrigió la copia de la bóveda.
