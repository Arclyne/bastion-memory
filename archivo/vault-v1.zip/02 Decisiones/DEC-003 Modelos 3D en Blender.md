---
tags: [decision]
estado: vigente
---
# DEC-003 Modelos 3D en Blender
Volver a [[Índice de decisiones]]

**Decisión:** los modelos 3D de las piezas se hacen en Blender, no con Higgsfield. Higgsfield sí se permite para imágenes de los prototipos de alta fidelidad.
**Relacionado:** [[DEC-001 Estilo visual 3D low-poly]].
