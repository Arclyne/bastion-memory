---
tags: [decision]
estado: vigente
fecha: 2026-11-12
---
# DEC-009 MovePawn sin resultado y rechazos como faltas
Volver a [[Índice de decisiones]]

**Decisión:** `IMatchService.MovePawn(string? sessionToken, PawnMove? move)` devuelve `void`. Los rechazos viajan como faltas tipadas: `InvalidSessionFault`, `MatchNotJoinedFault`, `NotYourTurnFault` (con el turno actual y el número de jugada esperado) e `IllegalMoveFault`. La posición nueva les llega a los dos jugadores por la notificación `PawnMovedNotification`.
**Motivo:** el documento de contratos aprobado decía `MoveRuling MovePawn(...)`, pero las reglas del profesor piden que los rechazos sean faltas ([[Restricciones del profesor]]). El usuario aprobó la recomendación al aceptar el plan (2026-11-12).
**Alternativas descartadas:** devolver un `MoveRuling` con el resultado.
**Implica:** el cliente sincroniza el turno con el detalle de `NotYourTurnFault` (FA-05). La jugada que se acepta no responde nada; el tablero se actualiza con la notificación, igual en las dos ventanas.
**Reemplaza a / reemplazada por:** —
