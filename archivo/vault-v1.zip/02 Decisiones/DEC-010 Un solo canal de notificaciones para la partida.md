---
tags: [decision]
estado: vigente
fecha: 2026-11-12
---
# DEC-010 Un solo canal de notificaciones para la partida
Volver a [[Índice de decisiones]]

**Decisión:** las notificaciones de la partida (jugadas y, después, muros, reloj y fin) usan el canal único `INotificationCallback` que se abre con `ISessionService`. No se crea un `IMatchCallback` aparte, como decía el documento de contratos.
**Motivo:** el canal único ya existe y lo usan el chat, los amigos, las salas y el abandono. El usuario aprobó la recomendación al aceptar el plan (2026-11-12).
**Alternativas descartadas:** un contrato de callback propio de la partida.
**Implica:** cada notificación nueva se registra como `KnownType` en `Notification` y se reparte en `NotificationCallback` del cliente.
**Reemplaza a / reemplazada por:** —
