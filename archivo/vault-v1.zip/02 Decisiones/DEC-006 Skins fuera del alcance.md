---
tags: [decision]
estado: vigente
---
# DEC-006 Skins fuera del alcance
Volver a [[Índice de decisiones]]

**Decisión:** no habrá skins. Hace tiempo pasaron a requisito deseable y ya no son obligatorias.
**Motivo:** no da tiempo.
**Implica:** no existe la entidad Skin en el [[Modelo de datos]], ni inventario ni skin equipada. El motivo original de [[DEC-001 Estilo visual 3D low-poly]] ya no aplica.
