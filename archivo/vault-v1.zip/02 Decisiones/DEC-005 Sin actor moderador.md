---
tags: [decision]
estado: vigente
---
# DEC-005 Sin actor moderador
Volver a [[Índice de decisiones]]

**Decisión:** Bastión no tiene actor moderador. Aplica a casos de uso y al diagrama de contexto.
**Ojo:** la moderación de chat sigue siendo requisito del profesor ([[Restricciones del profesor]]); se resuelve sin un actor humano moderador.
**Relacionado:** [[Diagramas]].
