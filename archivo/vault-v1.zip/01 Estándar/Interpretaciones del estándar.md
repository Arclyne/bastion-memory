---
tags: [estandar, decision]
---
# Interpretaciones del estándar
Volver a [[Índice del estándar]] · Fuente: [[journal-revision-v2.4]]

Decisiones de reglas del equipo, tal como están en el journal, ordenadas por número. Las decisiones de método están en [[Decisiones de método]].

## Decisiones de reglas (R)

### R-01
**Regla:** 2.9.1 (L-03) · [[Sección 02 Reglas de Nombrado|§2]] · **Fecha:** 2026-11-10

Las entidades que persiste EF Core **no** redefinen `Equals`: EF ya las identifica por su clave. Se anota como interpretación de la 2.9.1.

### R-02
**Regla:** 2.1.2 · [[Sección 02 Reglas de Nombrado|§2]] · **Fecha:** 2026-11-10

Un `byte[]` que representa un solo valor binario (hash, sal) **no** es una colección: va en singular.

### R-03
**Regla:** 2.6.3 (L-10) · [[Sección 02 Reglas de Nombrado|§2]] · **Fecha:** 2026-11-10

La 2.6.3 aplica a campos. Las propiedades autoimplementadas se inicializan en los constructores, para no repartir los valores iniciales entre declaraciones y constructores (D-06). Si dos constructores comparten valores por omisión, el público encadena `: this()` al que los fija.

### R-04
**Regla:** D-06, todos los `return` · **Fecha:** 2026-11-10

Un `return` devuelve una variable, un literal o una sola llamada con argumentos simples. Los casts, la aritmética y las llamadas anidadas van antes, en variables con nombre, un paso por línea.

### R-05
**Regla:** R-04, condiciones · **Fecha:** 2026-11-10

Un `return` puede devolver directamente una condición corta (comparación, `&&`, `is not null`): se lee como una pregunta. Ejemplo: `return PasswordHash is not null && PasswordSalt is not null;`.

### R-06
**Regla:** 4.4.1 y CS8629 · [[Sección 04 Complejidad|§4]] · **Fecha:** 2026-11-10

Cuando dos métodos necesitan la misma condición sobre un valor que puede faltar, se usa el patrón Try: un privado `TryGetX(…, out T x)` que devuelve `bool` y entrega el valor; los demás lo llaman (con `out _` si solo importa el `bool`). Sin atributos de nulabilidad ni `.Value`.

### R-07
**Regla:** 2.4.1 · [[Sección 02 Reglas de Nombrado|§2]] · **Fecha:** 2026-11-10

Las clases `*Rules` del dominio pasan a singular con el sufijo `Policy`, como `LockoutPolicy`: `AccountPolicy`, `ChatPolicy`, `FriendCodePolicy`, `FriendshipPolicy`, `MatchmakingPolicy`, `RoomPolicy`. Cada una se renombra al revisar su archivo.

### R-08
**Regla:** 4.4.2 · [[Sección 04 Complejidad|§4]] · **Fecha:** 2026-11-10

Las expresiones regulares del dominio se crean con una clase compartida (`TextPattern.Create`) que fija `CultureInvariant` y el tiempo límite en un solo lugar.

### R-09
**Regla:** 2.2.2 (L-02) · [[Sección 02 Reglas de Nombrado|§2]] · **Fecha:** 2026-11-10

El constructor primario de un record posicional **cuenta** para el límite de 3 parámetros. Un record con más campos se agrupa en otro record o pasa a propiedades `init` con inicializador de objeto.

### R-10
**Regla:** Vocabulario · **Fecha:** 2026-11-10

El inicio de sesión se nombra **Login/LogIn** en todo el proyecto. Los nombres con «SignIn» se renombran: los de `Account`, `AccountPolicy` y `LockoutPolicy` en un commit aparte (2026-11-10); `SignedInPlayer`, `SignedInSession` y `ToSignedInSession` al revisar sus archivos.

### R-11
**Regla:** 9.4.1 (L-02) · [[Sección 09 Manejo de Errores y Excepciones|§9]] · **Fecha:** 2026-11-10

Los records posicionales pasan a un **constructor explícito** con `ArgumentNullException.ThrowIfNull` para cada parámetro de referencia no anulable, y propiedades `{ get; }`. Solo los records que se copian con `with` llevan `{ get; init; }`. Cada record se cambia al revisar su archivo.

### R-12
**Regla:** R-04 y 5.3.1, LINQ · [[Sección 05 Prácticas de Programación Funcional|§5]] · **Fecha:** 2026-11-10

Una cadena LINQ que termina en un solo valor (`Any`, `Count`, `First`, `Sum`…) se guarda, un operador por línea, en una variable con nombre, y el `return` devuelve esa variable. Las lambdas de una línea se quedan en la cadena. Las cadenas que devuelven una secuencia siguen la 5.3.1 (`IEnumerable<T>` y `new List<T>(…)` aparte).

### R-13
**Regla:** 2.2.1 · [[Sección 02 Reglas de Nombrado|§2]] · **Fecha:** 2026-11-10

La convención `To<Tipo>`/`From<Tipo>` es solo para convertir a **otro tipo**. Un método que transforma un valor sin cambiar su tipo (de `string` a `string`) empieza con un verbo, como `NormalizeWords`.

### R-14
**Regla:** R-04, creación · **Fecha:** 2026-11-10

`return new X(…)` y `return new X { … }` cuentan como una sola llamada si cada argumento o asignación es una variable, una constante, una propiedad o un literal. Si alguno lleva una llamada (incluido otro `new`), una operación o un cast, va antes en una variable.

### R-15
**Regla:** Pasada 4 (L-09) · **Fecha:** 2026-11-10

`Message.MarkRead`: un miembro que solo usan las pruebas se queda cuando expresa una regla del dominio que producción aplica por otra vía (SQL) y el doble de pruebas la necesita. Las demás apariciones de la L-09 se siguen preguntando.

### R-16
**Regla:** R-11 (L-11) · **Fecha:** 2026-11-10

Un record posicional **sin** parámetros de referencia (solo tipos por valor y enumeraciones) se queda posicional: la 9.4.1 no tiene nada que comprobar. La R-11 aplica solo cuando hay al menos un parámetro de referencia no anulable.

### R-17
**Regla:** 2.11.4 · [[Sección 02 Reglas de Nombrado|§2]] · **Fecha:** 2026-11-10

En el dominio y el servidor, un valor calculado a partir de otros miembros es un método `GetX()` (`FriendRequest.GetExpirationTime()`), no una propiedad con `=>` ni con bloque `get`. Las propiedades calculadas de los modelos de vista (Gum enlaza propiedades) y los `DbSet` se preguntan en su capa.

### R-18
**Regla:** 4.4.1 · [[Sección 04 Complejidad|§4]] · **Fecha:** 2026-11-10

La guarda «el mismo jugador en los dos lados» se queda en cada entidad (`FriendRequest`, `Friendship`, `Message`) con su propio texto de dominio; no se comparte ni se cambia por `ThrowIfEqual`.

### R-19
**Regla:** 2.8.1 (L-12) · [[Sección 02 Reglas de Nombrado|§2]] · **Fecha:** 2026-11-10

Las entidades de EF son `class` aunque sean inmutables (catálogos como `GameMode`): EF las identifica por su clave (R-01), y la igualdad por valor de un `record` no aplica a una fila. La regla de `record` para valores inmutables vale para lo que no es entidad de EF.

### R-20
**Regla:** 2.11.4 (L-04) · [[Sección 02 Reglas de Nombrado|§2]] · **Fecha:** 2026-11-10

Una navegación de EF que expone un campo de respaldo (`Participations => _participations`, con `UsePropertyAccessMode.Field`) puede usar `=>`: se anota como excepción de EF. No cubre los valores calculados (R-17). Los `DbSet` de `BastionDbContext` se preguntan en su revisión.

### R-21
**Regla:** R-04, R-12 (L-13) · **Fecha:** 2026-11-10

Un `return` con **un solo** operador LINQ y una lambda de una línea (`FirstOrDefault(x => …)`, `Count(x => …)`) cuenta como una sola llamada, como en el ejemplo correcto de la 2.11.4. La R-12 aplica a cadenas de dos o más operadores.

### R-22
**Regla:** Pasada 3 · **Fecha:** 2026-11-10

Un método que hace una acción no devuelve un `bool` que no dice su nombre (`Abandon` devolvía «terminó la partida»). Pasa a `void` y quien llama pregunta por el estado.

### R-23
**Regla:** R-04 (L-14) · **Fecha:** 2026-11-10

Un cast no se combina en la misma línea con una llamada o una operación, en ningún lugar (asignaciones y argumentos incluidos): `TimeSpan clockTime = …; double clockMilliseconds = clockTime.TotalMilliseconds; RemainingClockMilliseconds = (int)clockMilliseconds;`. Las demás asignaciones de varios pasos se dejan; la R-04 completa sigue siendo para los `return`.

### R-24
**Regla:** R-05 (L-15) · **Fecha:** 2026-11-10

Una condición que mezcla `&&` y `||` (con paréntesis) no es corta: se separa en guardas, una pregunta por `if`, y el último `return` devuelve la comparación que queda. Las condiciones solo con `&&` siguen la R-05.

### R-25
**Regla:** Pasada 4 · **Fecha:** 2026-11-10

Una constante o un método públicos que solo usa su propia clase (ni otro código ni las pruebas; buscar en `src` **y** `tests`) pasan a `private` (`MatchmakingPolicy`, `RoomPolicy.FailedCodeWindowMinutes`, `WaitingRoom.HasMember`). Los límites que forman una pareja de una regla (mínimo y máximo) se quedan públicos juntos.

### R-26
**Regla:** 2.11.4 (L-16) · [[Sección 02 Reglas de Nombrado|§2]] · **Fecha:** 2026-11-10

Una propiedad que solo expone un campo como solo lectura (`Members => _members`) puede usar `=>`, dentro y fuera de EF (amplía la R-20). Los valores calculados siguen la R-17.

### R-27
**Regla:** 7.1–7.3 · [[Sección 07 Documentación XML|§7]] · **Fecha:** 2026-11-10

Cada interfaz `I…Service` se documenta (summary, param, returns, exception) al revisar su archivo, y su implementación lleva `<inheritdoc/>`. `GenerateDocumentationFile` y CS1591 como error en `I*Service.cs` (apagado en lo demás) se activan al **terminar cada capa** que tenga servicios: Application, Contracts y Client.

### R-28
**Regla:** R-04, 9.4.2 (L-17) · [[Sección 09 Manejo de Errores y Excepciones|§9]] · **Fecha:** 2026-11-10

`return x ?? throw new X();` se admite si lo de la izquierda es una variable o una sola llamada: es la llamada y su alternativa en una expresión (9.4.2).

### R-29
**Regla:** 3.4.1 (L-01) · [[Sección 03 Estilo de Codificación|§3]] · **Fecha:** 2026-11-10

En LINQ a objetos, un diccionario o un conjunto que se arma desde una lista se crea con `var x = new Dictionary<K, V>(fuente.Count);` (o `new HashSet<T>(…)`) y se llena con un `foreach`, en lugar de `ToDictionary`/`ToHashSet`. Así el `var` cumple la 3.4.1 (caso `new`) y el compilador no avisa (IDE0007). Las consultas de EF sobre `IQueryable` se ven en su revisión.

### R-30
**Regla:** 2.2.2 con 10.1.1 · [[Sección 02 Reglas de Nombrado|§2]] · [[Sección 10 Inyección de Dependencias|§10]] · **Fecha:** 2026-11-10

Si inyectar una dependencia lleva un constructor a más de tres parámetros, las dependencias que van juntas se agrupan en un record (como `PrivateChatChannel`), que la raíz de composición registra para que el contenedor lo arme por su constructor.

### R-31
**Regla:** 2.11.4 · [[Sección 02 Reglas de Nombrado|§2]] · **Fecha:** 2026-11-10

Los `DbSet<T> X => Set<T>();` del `DbContext` se quedan con `=>`, como patrón de EF con nulos activados (amplía la R-20).

### R-32
**Regla:** R-04, 5.3.1 (L-18) · [[Sección 05 Prácticas de Programación Funcional|§5]] · **Fecha:** 2026-11-10

Una consulta de EF sigue la forma de la 5.3.1: va en un `IQueryable<T>` con nombre en plural y se materializa con `new List<T>(consulta)` (o `new Dictionary<K, V>(consulta)` sobre `KeyValuePair<K, V>`). Las de valor único devuelven `consulta.FirstOrDefault()` (o `Any()`), o lo guardan en una variable si lo usan después. Un método privado que arma una consulta la guarda en una variable y la devuelve, o devuelve una sola llamada (`a.Concat(b)`).

### R-33
**Regla:** 5.1.1, 5.1.2 (L-19) · [[Sección 05 Prácticas de Programación Funcional|§5]] · **Fecha:** 2026-11-10

Las consultas de EF se parten en pasos simples: un `.Where` por condición `&&`; los dos sentidos de una pareja con `Concat` o con dos búsquedas unidas con `??`; `GroupBy(clave, elemento)` en lugar de una lambda anidada; el selector de `SetProperty` en un campo `Expression<…>`; y las proyecciones anidadas se arman en memoria con un método usado como grupo de método.

### R-34
**Regla:** 4.4.1, 10.1.1 · [[Sección 04 Complejidad|§4]] · [[Sección 10 Inyección de Dependencias|§10]] · **Fecha:** 2026-11-10

Un mapeo que se repite de una entidad a un tipo de `Application` es una fábrica estática en ese tipo (`PlayerIdentity.FromAccount`), que es la capa más interna que conoce los dos. No se inyecta ni va en un ensamblado propio mientras sea una función pura; se inyectaría si llegara a necesitar un servicio externo (10.1.1).

### R-35
**Regla:** 2.14.2 · [[Sección 02 Reglas de Nombrado|§2]] · **Fecha:** 2026-11-10

El sufijo `Store` es solo para los datos locales del cliente (`LanguagePreferenceStore`). Lo que guarda en la base desde el servidor se llama `Repository`, también si abre su propio contexto por operación (`MatchRepository`, `RoomRepository`).

### R-36
**Regla:** 4.4.1 · [[Sección 04 Complejidad|§4]] · **Fecha:** 2026-11-10

Los errores de EF (`DbUpdateException`, `DbException`) se traducen en un solo lugar, `DatabaseFailureTranslator<TFailure>`, que recibe cómo crear la excepción de quien lo usa. Los repositorios que abren un contexto por operación usan `NewContextRunner<TFailure>`, que a su vez usa el traductor. `UnitOfWork` puede usar el traductor (211).

### R-37
**Regla:** 9.2.1 · [[Sección 09 Manejo de Errores y Excepciones|§9]] · **Fecha:** 2026-11-10

El contexto de EF usa `NonRetryingExecutionStrategy`. La estrategia por defecto de SQL Server envuelve los errores transitorios en `InvalidOperationException`, que escapa de la traducción. Si algún día se activan reintentos, hay que traducir también `RetryLimitExceededException`.

### R-38
**Regla:** 9.2.1 · [[Sección 09 Manejo de Errores y Excepciones|§9]] · **Fecha:** 2026-11-10

Se traduce un error de la base a una excepción de `Application` solo donde un componente de adentro reacciona a ella (`MatchRepositoryException`, `RoomRepositoryException`). La unidad de trabajo no traduce: sus fallas suben hasta `Host`, que es el borde y atrapa `DbException`/`DbUpdateException`. `DatabaseFailureTranslator` queda aparte para cuando haga falta en otro lugar.

### R-39
**Regla:** 8.1.1 · [[Sección 08 Comentarios Internos|§8]] · **Fecha:** 2026-11-10

**Sin comentarios en el código**, ni siquiera los `//` de "por qué" que admite la 8.1.1. El porqué se lee en los nombres: un método extraído que diga la garantía, una variable explicativa o un nombre que revele la intención. La documentación XML de las interfaces de servicio (§7) se queda.

### R-40
**Regla:** 9.4.1 (L-20) · [[Sección 09 Manejo de Errores y Excepciones|§9]] · **Fecha:** 2026-11-10

En una operación de servicio WCF, el argumento que llega por la red se comprueba al inicio, pero un nulo no lanza `ArgumentNullException`: lanza la falla tipada que corresponde (`InvalidCredentialsFault`, sesión inválida, el rechazo del caso). Así el cliente sabe qué pasó y el canal con sesión no se daña. En los constructores y en las demás clases sigue `ThrowIfNull`.

### R-41
**Regla:** R-10, textos · **Fecha:** 2026-11-10

La R-10 también vale para los textos del programa: bitácora, mensajes de excepción y razones de falla dicen "login"/"log in", no "sign-in". Los textos de la interfaz (`Strings.resx`) siguen con "Sign in". También vale para la documentación XML: "logged-in player", no "signed-in" (decidido en `Matches` de `Contracts`, 2026-11-11; `IMatchmakingService` e `ISessionService` se cambian al revisar su carpeta).

### R-42
**Regla:** 5.3.1, R-14 · [[Sección 05 Prácticas de Programación Funcional|§5]] · **Fecha:** 2026-11-10

Un arreglo de contrato se arma con `ContractArray.ConvertAll(origen, convertidor)` (en `Host/Common`), en una variable antes del `return`, no con `Select(…).ToArray()`.

### R-43
**Regla:** 4.4.1, R-14 · [[Sección 04 Complejidad|§4]] · **Fecha:** 2026-11-10

Una falla tipada se crea con `FaultExceptionFactory.Create(detalle, rechazo)`, que usa el mensaje del rechazo como razón. El detalle va antes en una variable.

### R-44
**Regla:** R-04, R-14 (L-21) · **Fecha:** 2026-11-11

Una operación de servicio WCF deja su llamada en una variable `Func<…>` hacia un método privado `…InRequestScope` (abre el ámbito, pide el servicio, llama y traduce el resultado) y devuelve `Translate…Failures(nameof(…), variable)`, un método privado por servicio que solo convierte excepciones en fallas. Nada de `Run`.

### R-45
**Regla:** 4.4.1, R-44 · [[Sección 04 Complejidad|§4]] · **Fecha:** 2026-11-11

Una operación `void` pasa por la R-44 con una segunda sobrecarga `Translate…Failures(string, Action)` que la convierte en `Func<bool>` con un privado `CompleteOperation` (llama y devuelve `true`). Los `catch` quedan una sola vez, en la sobrecarga con `Func<TResult>`. Vale para los servicios que tienen operaciones `void` y operaciones con resultado. Un servicio con solo operaciones `void` tiene un único `Translate…Failures(…, Action)` con los `catch`, sin la sobrecarga `Func` ni `CompleteOperation` (precisado en `MatchService`, 2026-11-11).

### R-46
**Regla:** 10.3.1 (L-08) · [[Sección 10 Inyección de Dependencias|§10]] · **Fecha:** 2026-11-11

La excepción de la 10.3.1 también vale para un singleton que necesita un servicio `Scoped` en cada operación (`FriendPresenceReporter`): recibe `IServiceScopeFactory` y abre un ámbito por operación, como el patrón de Microsoft para consumir un servicio con ámbito desde un singleton. Fuera de WCF el envoltorio no traduce: registra y sigue (`LogPresenceFailures`), con un `…InOwnScope` por operación.

### R-47
**Regla:** 6.2 · [[Sección 06 Estructura de Archivos|§6]] · **Fecha:** 2026-11-11

Los métodos privados van en el orden de los públicos que los usan (decidido en `RoomRepository` y en `FriendshipTranslator`). Los privados que se llaman en cadena van juntos y de arriba abajo, cada uno debajo del que lo llama, aunque un público anterior use un eslabón de en medio; un privado suelto que usan casi todos (`GetUtcNow`) va al final (precisado en `NotificationChannelRegistry`, 2026-11-11).

### R-48
**Regla:** Pasada 3 · **Fecha:** 2026-11-11

Un traductor no sobrecarga `ToNotification`: cada método dice qué notificación arma (`ToMatchFoundNotification`, `ToSearchEndedNotification`). Aplica a `PrivateChatTranslator.ToNotification` al revisarlo.

### R-49
**Regla:** 10.1.1 · [[Sección 10 Inyección de Dependencias|§10]] · **Fecha:** 2026-11-11

Una clase de `Application` que hace E/S por sus colaboradores o usa estado compartido se recibe por una interfaz, aunque sea interna (`IMatchmakingDispatcher`). También vale en `Host` (decidido en `Sessions`): `INotificationChannelRegistry` (el evento `PlayerDisconnected` y `RegisterChannel`) e `IFriendPresenceReporter`, junto a su clase; el registro concreto se queda en el contenedor solo para resolver los puertos.

### R-50
**Regla:** R-44, 4.4.1, 11.1.1 · [[Sección 04 Complejidad|§4]] · [[Sección 11 Bitácoras|§11]] · **Fecha:** 2026-11-11

Una operación `IsOneWay` no traduce: su falla no llega al cliente, y si se escapa, CoreWCF no la registra (comprobado en `oneway-experiment`). Guarda su `…InRequestScope` en una variable `Action<string>` y llama `Log…OneWayFailures(nameof(…), sessionToken, operación)`. Ese envoltorio tiene la guarda del token nulo (Warn) y los `catch` de tipos conocidos, que registran sin relanzar. Aplica a `RoomService.LeaveRoom`.

### R-51
**Regla:** 3.4.1 (L-01) · [[Sección 03 Estilo de Codificación|§3]] · **Fecha:** 2026-11-11

Se sigue lo que pidan IDE0007 e IDE0008, porque la 3.4.1 dice que su definición coincide con la de esos analizadores. En una llamada calificada cuyo método nombra el tipo que devuelve (`MatchmakingTranslator.ToMatchFoundNotification(…)` → `MatchFoundNotification`) va `var`. En una llamada sin calificar dentro de la misma clase (`ToPrivateChatMessage(…)`) el analizador pide el tipo explícito (comprobado en `PrivateChatTranslator`, 2026-11-11).

### R-52
**Regla:** 11.1.1, 9.3.1 · [[Sección 09 Manejo de Errores y Excepciones|§9]] · [[Sección 11 Bitácoras|§11]] · **Fecha:** 2026-11-11

Un proceso registra en Fatal la excepción que lo termina con un manejador de `AppDomain.CurrentDomain.UnhandledException` puesto justo después de configurar log4net. Solo registra, no atrapa ni sigue (`Program.LogUnhandledException`). El mensaje de arranque se registra después de `app.Start()`. También aplica al `Program` del cliente (decidido en 386–387, 2026-11-11).

### R-53
**Regla:** 11.1.1 · [[Sección 11 Bitácoras|§11]] · **Fecha:** 2026-11-11

Un `catch` de `Host` que traduce un rechazo a falla y la relanza no registra nada, ni en Info ni en Warn: se registra donde se maneja al final (el cliente). Una guarda que rechaza antes del `try` (opciones nulas en `RequireSettings`) sí puede registrar en Warn.

### R-54
**Regla:** 4.3.2, 4.6.1 · [[Sección 04 Complejidad|§4]] · **Fecha:** 2026-11-11

Una traducción de enum a enum con más casos de los que caben en complejidad 10 va en una tabla `private static readonly IReadOnlyDictionary<TOrigen, TDestino> _xByY` con `TryGetValue`, y lanza `ArgumentOutOfRangeException` si falta el valor. No se parte el `switch` con un `default` que delega. Aplica a `RoomContractTranslator` del cliente.

### R-55
**Regla:** Pasada 3, 4.4.2 · [[Sección 04 Complejidad|§4]] · **Fecha:** 2026-11-11

En la raíz de composición del servidor cada método de registro registra solo los tipos de su capa (`AddBastionAdapters`, `AddBastionApplication`, `AddBastionHost`). La lista de servicios WCF para CoreWCF (`AddBastionServices`) va en `ServiceRegistration`, junto a sus `AddTransient`, y `Program` compone. Una clase que no se llama como un registro (`ServerCertificate`) no registra servicios. Se pregunta si aplica a la raíz de composición del cliente al revisarla.

### R-56
**Regla:** 4.4.1 · [[Sección 04 Complejidad|§4]] · **Fecha:** 2026-11-11

Una guarda de argumento de red que se repite igual en varios servicios WCF es un método público estático del traductor que crea su falla: `SessionTranslator.RequireSessionToken` y `ChatTranslator.RequireText`. Las guardas propias de un servicio (`RequireFriendCode`) siguen privadas. `GetUtcNow` se queda en cada clase y el ámbito sigue la R-44.

### R-57
**Regla:** Pasada 4 · **Fecha:** 2026-11-11

El `MessageId` de los contratos se queda aunque el cliente no lo lea: es la identidad del mensaje en la red (`ChatMessageReceipt`, `LobbyChatMessage`, las tres notificaciones de mensaje y `PrivateChatMessage`). No se vuelve a preguntar en `Notifications` ni en `PrivateChat` (decidido en `Chat` de `Contracts`).

### R-58
**Regla:** 4.4.2, 2.10.1 · [[Sección 02 Reglas de Nombrado|§2]] · [[Sección 04 Complejidad|§4]] · **Fecha:** 2026-11-11

Bastión solo usa puertos registrados de IANA (RFC 6335), del 1024 al 49151. Se rechazan los del sistema (0–1023) y los dinámicos (49152–65535), que el sistema operativo usa como efímeros. La regla vive una sola vez en `ServiceEndpoints.IsRegisteredPort`, con `FirstRegisteredPort` y `LastRegisteredPort`. El cliente vuelve al puerto por defecto, y el servidor no arranca (decidido en `Channels` de `Client.Networking`).

### R-59
**Regla:** 11.1.1 · [[Sección 11 Bitácoras|§11]] · **Fecha:** 2026-11-12

Todo movimiento que el servidor rechaza (peón que no llega, muro fuera del tablero, surco ocupado, muro que encierra o jugador sin muros) se registra en **Warn**, como el "movimiento inválido" del ejemplo de la regla: el cliente ya valida antes de enviar, así que el rechazo solo llega con un estado viejo o un cliente modificado. Cuando la interfaz no permite el caso (`NoWallsLeft`), la frase lo dice ("the client may be modified"). Decidido en `MatchMoveService.EnsureWallFits`, que registraba en Info los rechazos de muro.

### R-60
**Regla:** 6.2, R-47 · [[Sección 06 Estructura de Archivos|§6]] · **Fecha:** 2026-11-12

Un privado que usan solo algunos de los demás privados es un eslabón de cadena y va justo debajo de su primer llamador, aunque otro método más abajo también lo use. Al final solo va un privado que usan casi todos los métodos de la clase (precisa la R-47). Decidido en `MatchMoveService.ListParticipantAccountIds`, que usan `NotifyPawnMoved` y `NotifyWallPlaced` y pasó debajo de `NotifyPawnMoved`.
