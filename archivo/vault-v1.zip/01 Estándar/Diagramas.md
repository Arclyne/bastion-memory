---
tags: [estandar]
---
# Estándar de diagramas
Volver a [[Índice del estándar]]

- Diagrama E-R: notación de Chen. Entidades en [[Modelo de datos]].
- Diagrama de contexto (DFD): debe seguir el SAD (`bastion_game_sad`) y `requisitos-bastion`. Sin actor moderador (ver [[DEC-005 Sin actor moderador]]).
- Modelos 3D: en Blender (ver [[DEC-003 Modelos 3D en Blender]]).
