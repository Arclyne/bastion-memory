---
tags: [indice, estandar]
---
# Índice del estándar
Volver a [[00 Inicio]]

- [[Índice del estándar v2.4]] — el estándar de codificación del proyecto, íntegro
- [[Interpretaciones del estándar]] — decisiones de reglas (R) del equipo
- [[Código]] — lo que pide el usuario además del estándar
- [[Git]] — autoría, commits y PRs
- [[Documentación]] — documentos de requisitos y casos de uso
- [[Diagramas]] — notación y fuentes de cada diagrama
