---
tags: [estandar]
---
# Estándar de código
Volver a [[Índice del estándar]]

El estándar oficial es el [[Índice del estándar v2.4|Estándar de Codificación v2.4]]. Las decisiones del equipo sobre cómo aplicarlo están en [[Interpretaciones del estándar]].

Además, el usuario pide:
- Sin rastros de que el código lo escribió una IA.
- Seguir SOLID.
- Nombres de variables declarativos en lugar de comentarios.
