---
tags: [estandar, estandar-v2-4]
seccion: 13
---
Volver a [[Índice del estándar v2.4]]

```text
13.     Declaración de Uso de Inteligencia Artificial
    Para la elaboración y revisión de este estándar se utilizaron herramientas de inteligencia
artificial generativa como apoyo en la organización del contenido, la redacción y la detección
de inconsistencias. El equipo autor verificó las reglas, los ejemplos y las fuentes, y conserva la
responsabilidad sobre la versión final del documento.
    La inteligencia artificial no sustituye la revisión técnica ni la aprobación del equipo. No se
incorporan al documento final conversaciones, instrucciones internas, cadenas de razonamiento ni
registros de interacción con dichas herramientas.
```
