---
tags: [estandar]
---
# Estándar de documentación
Volver a [[Índice del estándar]]

- Los requisitos viven en la carpeta `requisitos-bastion` (documento de casos de uso en LaTeX).
- Casos de uso en formato clásico: flujo normal, flujos alternos y flujos de excepción.
- Los entregables se evalúan con rúbricas del profesor; revisar la rúbrica antes de entregar.
- En reportes escolares usar el correo institucional zs24013324@estudiantes.uv.mx, no Gmail.
