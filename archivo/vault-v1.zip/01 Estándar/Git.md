---
tags: [estandar]
---
# Estándar de Git
Volver a [[Índice del estándar]]

- Todo el trabajo se sube y se atribuye a la cuenta **Arclyne** (github.com/Arclyne). No usar la cuenta antigua Slxugv.
- Sin rastro de Claude en commits ni PRs: nada de "Generated with Claude", ni `Co-Authored-By` ni otra atribución a IA.
